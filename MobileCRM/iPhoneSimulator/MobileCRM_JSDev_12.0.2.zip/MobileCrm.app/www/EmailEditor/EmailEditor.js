﻿/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
var EmailEditor;
(function (EmailEditor) {
    var Editor = (function () {
        function Editor(element, options) {
            this.templates = {
                "format": "<table><tr>" + "<td data-command='bold'>Bold</td>" + "<td data-command='italic'>Italic</td>" + "<td data-command='underline'>Underline</td>" + "</tr></table>"
            };
            this.element = element;
            this.element.addClass(Editor.EditorClass);
            this.element.data("emaileditor-contextmenu", this.createContextMenu());
        }
        Editor.prototype.createContextMenu = function () {
            var contextMenu = $("<div/>", {
                'id': this.element.attr('id') + "-" + Editor.EditorContextMenuClass,
                'style': "display:none"
            });

            // set editor data
            contextMenu.addClass(Editor.EditorContextMenuClass);
            contextMenu.data("emaileditor", this);

            // disable selection
            contextMenu.each(function (i, e) {
                disableSelect(e);
            });

            // set <td's> click event
            contextMenu.on("click", "td", Editor.onContextMenuClick);

            // TEST
            contextMenu.append(this.templates["format"]);

            // add ContextMenu handler
            if (!this._contextMenuHandler) {
                this._contextMenuHandler = function (eventObject) {
                    contextMenu.css("left", eventObject.pageX);
                    contextMenu.css("top", eventObject.pageY);
                    contextMenu.fadeIn(100);

                    window.setTimeout(function () {
                        $(document).on("click.emaileditor", function (event) {
                            contextMenu.fadeOut(100);
                            $(document).off("click.emaileditor");
                        });
                    }, 100);
                };
            }
            this.element.bind('contextmenu', this._contextMenuHandler);

            // add SelectionChanged handler
            if (!Editor._selectionChangedHandler) {
                Editor._selectionChangedHandler = function (eventObject) {
                    var selObj = window.getSelection();
                    if (selObj.anchorNode && selObj.getRangeAt) {
                        var selRange = selObj.getRangeAt(0);
                        var selEditor = Editor.fromNode(selRange.startContainer);
                        if (selEditor && selEditor == Editor.fromNode(selRange.endContainer))
                            selEditor.lastSelRange = selRange;
                    }
                };
                $(document).bind('selectionchange', Editor._selectionChangedHandler);
            }

            // add ContextMenu
            this.element.before(contextMenu);

            return contextMenu;
        };

        Editor.prototype.executeCommand = function (command) {
            if (this.lastSelRange) {
                var selRange = this.lastSelRange;

                switch (command) {
                    case "bold":
                    case "italic":
                    case "underline":
                        document.execCommand(command, false);
                        break;
                }
            }

            // remember the scroll position
            var pageXOffset = window.pageXOffset;
            var pageYOffset = window.pageYOffset;

            // set focus back to editor
            this.element.focus();

            // scroll window back to original position
            window.scrollBy(pageXOffset, pageYOffset);
        };

        Editor.onContextMenuClick = function (event) {
            var editor = Editor.fromNode(event.target);
            if (editor) {
                var command = $(event.target).data("command");
                if (command)
                    editor.executeCommand(command);
            }
        };

        Editor.fromNode = function (node) {
            var body = document.body;
            while (node && node != body) {
                var $node = $(node);
                if ($node.hasClass(Editor.EditorContextMenuClass) || $node.hasClass(Editor.EditorClass)) {
                    return $node.data('emaileditor');
                }
                node = node.parentNode;
            }
            return null;
        };
        Editor.EditorClass = "emaileditor";
        Editor.EditorContextMenuClass = "emaileditor-contextmenu";
        return Editor;
    })();
    EmailEditor.Editor = Editor;
})(EmailEditor || (EmailEditor = {}));

(function ($) {
    $.fn.emailEditor = function (options) {
        return this.each(function () {
            var $this = $(this);
            $this.data('emaileditor', new EmailEditor.Editor($this, options));
        });
    };
})(jQuery);

function disableSelect(el) {
    if (el.addEventListener) {
        el.addEventListener("mousedown", disabler, "false");
    } else {
        el.attachEvent("onselectstart", disabler);
    }
}

function enableSelect(el) {
    if (el.addEventListener) {
        el.removeEventListener("mousedown", disabler, "false");
    } else {
        el.detachEvent("onselectstart", disabler);
    }
}

function disabler(e) {
    if (e.preventDefault) {
        e.preventDefault();
    }
    return false;
}
