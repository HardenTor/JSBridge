/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="Localization.ts" />
/// <reference path="AttachmentDlg.ts" />
/// <reference path="Post.ts" />
/// <reference path="User.ts" />
/// <reference path="MEditor.ts" />
/// <reference path="NavBar.ts" />
/// <reference path="ChannelBrowser.ts" />
var Chatter;
(function (Chatter) {
    var Topic = (function () {
        function Topic() {
            var _this = this;
            this.postsPageLen = 32;
            this.offsetBottom = 0;
            Topic.instance = this;
            this.showChannels = ko.observable();
            this.channelName = ko.observable();
            this.channelType = ko.observable();
            this.isDirect = ko.observable();
            this.InitPhase = ko.observable(true);
            this.isLoading = ko.observable(false);
            this.showLoading = ko.observable(true);
            //this.unreadedMessages = ko.observable<number>(0);
            this.posts = ko.observableArray();
            this.users = new Array();
            this.loggedUser = ko.observable();
            this.hasOlderPosts = ko.observable();
            this.isFollowing = ko.observable();
            this.navBar = new Chatter.ChannelNavBar();
            this.channelBrowser = new Chatter.ChannelBrowser();
            this.showFollowingButton = ko.observable();
            this.isPrivate = ko.observable();
            this.welcomeMessage = ko.computed(function () {
                return Chatter.Localization.get(_this.isDirect() ? "BeginPrivateChannelMsg" : (_this.isPrivate() ? "PrivateChannelMsg" : "BeginPublicChannelMsg"));
            }, this);
            //this.unreadedMessagesText = ko.computed(() => {
            //	return this.unreadedMessages() == 1 ? Localization.get("UnreadMesage") : Localization.get("UnreadMesages").replace("?", this.unreadedMessages().toFixed(0));
            //}, this);
            this.followText = ko.computed(function () {
                return Chatter.Localization.get(_this.isFollowing() ? "UnsubscribeChannel" : "SubscribeChannel");
            }, this);
            this.finalMessage = ko.observable(Chatter.Localization.get("ThatsAllForNow"));
            this.postEditorEmpty = ko.observable(true);
        }
        /**
        * Funtion for setting up Chatter
        * @param data Initial data for set-up
        */
        Topic.prototype.init = function (data) {
            var chatWindow = document.getElementsByClassName("chatter-window")[0];
            this.windowClientHeight = chatWindow.clientHeight;
            if (typeof MutationObserver != "undefined") {
                // Listen to changes on the elements in the page that affect layout 
                var self = this;
                var observer = new MutationObserver(function () {
                    self.applyScrollPosition();
                });
                observer.observe(document.body, {
                    attributes: true,
                    childList: true,
                    characterData: true,
                    subtree: true
                });
            }
            MobileCRM.bridge.command("getNavBarConfig", null, this.navBar.applyConfig, Topic.onError, this.navBar);
            var userDef = data.user;
            if (userDef) {
                var loggedUser = new Chatter.User(userDef.id);
                loggedUser.userid = userDef.properties.resco_userid;
                this.jsUpdateUserInfo(userDef.id, loggedUser);
                this.loggedUser(loggedUser);
                this.setCurrentChannel(data.topic);
                this.isDirect(this.isDirectChannel());
                this.update(true);
            }
        };
        Topic.onError = function (errText) {
            MobileCRM.bridge.command("sayError", errText);
        };
        /**
        * Sets the posts window scroll position so that the old 'distance to bottom' is maintained.
        */
        Topic.prototype.applyScrollPosition = function () {
            var chatWindow = document.getElementsByClassName("chatter-window")[0];
            chatWindow.scrollTop = chatWindow.scrollHeight - chatWindow.clientHeight - this.offsetBottom;
        };
        /**
        * Function which scrolls approximatelly scrolls the user window to last position before resizing
        */
        /**
        * Function which scrolls approximatelly scrolls the user window to last position before resizing
        */
        Topic.prototype.onResize = function () {
            var newPostsHeight = document.getElementsByClassName("chatter-posts")[0].clientHeight;
            var newWindowClientHeight = document.getElementsByClassName("chatter-window")[0].clientHeight;
            if ((newPostsHeight != this.postsHeight) || (newWindowClientHeight != this.windowClientHeight)) {
                var position = (this.offsetHeight / (this.postsHeight - this.windowClientHeight)) * (newPostsHeight - newWindowClientHeight);
                document.getElementsByClassName("chatter-window")[0].scrollTop = position;
                this.postsHeight = newPostsHeight;
                this.windowClientHeight = newWindowClientHeight;
            }
        };
        /**
        * Function that listens to the scroll event,
        * responsible for infinite scroll(loading older posts),
        * checking whether the user scrolled to the unseen messages and playing animation at the end of the scroll
        * @param data
        * @param event
        */
        Topic.prototype.onScroll = function (data, event) {
            var chatWindow = document.getElementsByClassName("chatter-window")[0];
            this.offsetBottom = chatWindow.scrollHeight - chatWindow.clientHeight - chatWindow.scrollTop;
            this.offsetHeight = chatWindow.scrollTop;
            if (!this.isLoading()) {
                var elem = event.target;
                if (!this.InitPhase()) {
                    //Loads older posts
                    var loader = document.getElementById('chatter-header');
                    if (elem.scrollTop <= loader.clientHeight) {
                        if (this.hasOlderPosts()) {
                            this.isLoading(true);
                            this.showOlder();
                        }
                    }
                    // Transition is retarded and start too late. We cannot tell user's scroll from automatic scroll event anyway...
                    //else if ((document.getElementsByClassName("chatter-window")[0].scrollHeight - document.getElementsByClassName("chatter-window")[0].scrollTop) == document.getElementsByClassName("chatter-window")[0].clientHeight) {
                    //    this.endScrollTransition();
                    //}
                    // Checks whether the user is over the unreaded posts
                    //if (this.unreadedMessages() > 0) {
                    //	var chatterPosts = document.getElementsByClassName("chatter-post");
                    //	var lastOneHeight = chatterPosts[chatterPosts.length - 1].clientHeight;
                    //	if (elem.scrollTop > (this.postsHeight - this.windowClientHeight - (lastOneHeight / 2)))
                    //		this.unreadedMessages(0);
                    //}
                }
            }
        };
        /**
        * Function that listens to keypressed event.
        * Responsible for inserting new line element into postEditor. (Shift + Enter)
        * Responsible for sending message. (Enter)
        * @param data
        * @param event
        */
        Topic.prototype.onKeyPressed = function (data, event) {
            if (event.keyCode == 13) {
                this.submitPost();
            }
            else
                document.getElementById('postEditor').innerText += event.key;
        };
        /**
        * Functions that holds user's position while loading new posts
        */
        Topic.prototype.holdPosition = function () {
            var newPostsHeight = document.getElementsByClassName("chatter-posts")[0].clientHeight;
            if (newPostsHeight != this.postsHeight) {
                var currentPosition = newPostsHeight - this.postsHeight + this.offsetHeight;
                //document.getElementsByClassName("chatter-window")[0].scrollTop = currentPosition;
                this.postsHeight = newPostsHeight;
            }
        };
        /**
        * Transition at the end of the scroll through the posts
        */
        Topic.prototype.endScrollTransition = function () {
            $('.chatter-window').css({
                "box-shadow": "inset 0px -40px 40px -40px #0066cc",
                "-webkit-transition": "all  0.3s glow",
                "-moz-transition": "all  0.3s glow",
                "-ms-transition": "all  0.3s glow",
                "transition": "all  0.3s glow"
            });
            setTimeout(function () {
                $('.chatter-window').css({
                    "box-shadow": "none",
                    "-webkit-transition": "all  0.3s glow",
                    "-moz-transition": "all  0.3s glow",
                    "-ms-transition": "all  0.3s glow",
                    "transition": "all  0.3s glow"
                });
            }, 300);
        };
        /**
        * Function that scroll the window the the newest post
        */
        Topic.prototype.ScrollToBottom = function () {
            var chatWindow = document.getElementsByClassName("chatter-window")[0];
            chatWindow.scrollTop = chatWindow.scrollHeight;
            this.offsetHeight = chatWindow.scrollTop;
            this.offsetBottom = 0;
        };
        /**
        * Function that scroll the user to the uppermost new message
        *
        public ShowNewMessages() {
            var parent = document.getElementsByClassName("chatter-window")[0];
            var child = document.getElementsByClassName("chatter-posts")[0];
            $('.chatter-window').animate({
                scrollTop: child.scrollTop + child.clientHeight + child.scrollHeight
            }, 1000);
            this.unreadedMessages(0);
        }

        /**
        * Function that shows or hides the channel menu
        */
        Topic.prototype.toggleChannels = function () {
            if (this.showChannels())
                this.showChannels(false);
            else
                this.showChannels(true);
        };
        /**
        * Functions that open the channel menu
        */
        Topic.prototype.openChannels = function () {
            if (!this.showChannels())
                this.showChannels(true);
        };
        /**
        * Function that closes the channel menu
        */
        Topic.prototype.closeChannels = function () {
            if (this.showChannels())
                this.showChannels(false);
        };
        Topic.prototype.browseChannels = function () {
            var _this = this;
            this.channelBrowser.show(Chatter.Localization.get("Channels"), Chatter.Localization.get("SearchChannels"), this.navBar.channels(), this.navBar.otherChannels, ["Subscribed Channels", "Other Channels"], function (channel) {
                channel.visitedRecently(true);
                Topic.instance.setChannel(channel.entity, channel.id);
            }, function (newChannelName, isPrivate) {
                MobileCRM.bridge.command("createChannel", newChannelName + ":" + isPrivate, function (newChannelConfig) {
                    _this.navBar.addNewChannel(newChannelConfig);
                    _this.setChannel(newChannelConfig.entity, newChannelConfig.id);
                }, null, _this);
            });
        };
        Topic.prototype.browseUsers = function () {
            var users = this.navBar.users();
            this.channelBrowser.show(Chatter.Localization.get("DirectMessages"), Chatter.Localization.get("SearchUsers"), users, [], null, function (user) {
                user.visitedRecently(true);
                Topic.instance.setChannel(user.entity, user.id);
            }, null);
        };
        Topic.prototype.inviteUsers = function () {
            var users = this.navBar.users();
            // TODO: Exclude users that are already members of this channel
            this.channelBrowser.show(Chatter.Localization.get("InviteUsers"), Chatter.Localization.get("SearchUsers"), users, [], null, function (user) { return MobileCRM.bridge.command("InviteUser", user.id); }, null);
        };
        Topic.prototype.onHeaderChannelClick = function () {
            var id = this.currentChannel.regardingId;
            var entity = this.currentChannel.regardingEntity;
            if (id && entity) {
                MobileCRM.bridge.command('openLink', ':' + id); // Don't pass entity because it's localized
            }
        };
        Topic.prototype.postEditorFocus = function () {
            this.closeChannels();
            this.mEditor.focus();
        };
        /**
        * Function that is responsible for calling JSBridge function for saving the post and appending it to existing posts
        */
        Topic.prototype.submitPost = function () {
            if (this.isSubmitPending)
                return;
            var editor = this.mEditor;
            if (!editor.isEnabled)
                return;
            var newPostContent = editor.getText(function (node) {
                if (node.nodeName == 'SPAN') {
                    var $node = $(node);
                    return '<open entity="' + $node.attr('ename') + ',' + $node.attr('eid') + '">' + $node.text() + '</open>';
                }
                return null;
            });
            if (newPostContent) {
                this.isSubmitPending = true;
                editor.clearText();
                MobileCRM.bridge.command("submitPost", newPostContent, this.onPostSubmitted, function (errMsg) {
                    this.ScrollToBottom();
                    this.isSubmitPending = false;
                }, this);
            }
        };
        Topic.prototype.onPostSubmitted = function (newPost) {
            var post = new Chatter.Post(newPost.id, this);
            post.content(this.mEditor.EmoticonsToIcons(newPost.text));
            post.user(this.loggedUser());
            post.createdOn(new Date(Date.now()));
            post.modifiedOn(new Date(Date.now()));
            post.pending(newPost.isPending);
            post.isSending(true);
            this.posts.push(post);
            this.updatePostsPrefixVisibility(this.posts().length - 1);
            this.ScrollToBottom();
        };
        /**
        * For each post after the passed index checks whether the date header and or user header needs to be visible.
        * @param fromIndex he starting index to check.
        */
        Topic.prototype.updatePostsPrefixVisibility = function (fromIndex) {
            if (fromIndex < 0)
                fromIndex = 0;
            for (var i = fromIndex; i < this.posts().length; i++) {
                var showUser = true;
                var showDate = true;
                var prevPost = i > 0 ? this.posts()[i - 1] : null;
                var post = this.posts()[i];
                // Hide date and user name if it is the same as the previous post.
                if (prevPost) {
                    var prevDate = prevPost.modifiedOn();
                    var postDate = post.modifiedOn();
                    var notSameDay = prevDate.getFullYear() !== postDate.getFullYear() || prevDate.getMonth() !== postDate.getMonth() || prevDate.getDate() !== postDate.getDate();
                    if (prevPost.user().id === post.user().id) {
                        showUser = notSameDay;
                    }
                    showDate = notSameDay;
                }
                post.updateDateHeader(showDate);
                post.showPrefix(showUser);
            }
        };
        /**
        * Shows menu of possible attachments that can be appended to the post
        */
        Topic.prototype.showAttachmentMenu = function () {
            if (this.isSubmitPending)
                return;
            MobileCRM.bridge.command("showAttachmentMenu", "", null, null, null);
        };
        Topic.prototype.showAttachmentDialog = function (args) {
            var _this = this;
            var filePath = args[0];
            var fileUrl = args[1];
            var mimeType = args[2];
            var fileName = args[3];
            var postSubject = args[4];
            Chatter.AttachmentDlg.show(fileUrl, fileName, mimeType, postSubject, "", function (title, comment) {
                _this.isSubmitPending = true;
                MobileCRM.bridge.command("submitAttachment", JSON.stringify({
                    subject: title,
                    postText: comment,
                    filePath: filePath,
                    mimeType: mimeType
                }));
            });
        };
        /**
        * Function for finding out whether the channel is private or not
        * @return true if the channel is private, otherways false
        */
        Topic.prototype.isDirectChannel = function () {
            var privateChannelPrefix = "@private:";
            var entityName = this.currentChannel.regardingEntity;
            return entityName && entityName.length > privateChannelPrefix.length && entityName.substr(0, privateChannelPrefix.length) == privateChannelPrefix;
        };
        /**
        * Function that is responsible for appending an entity to the post editor
        * @param reference Information about the entity to append
        */
        Topic.prototype.appendEntity = function (reference) {
            var htmlText = '<span contenteditable="false" class="post-link" eid="' + reference.id + '" ename="' + reference.entityName + '">' +
                reference.primaryName + '</span>';
            this.mEditor.replaceSelection(htmlText);
        };
        /**
        * Function that is responsible for loading the chosen channel
        * @param entity
        * @param id
        * @param isFollowed
        */
        Topic.prototype.setChannel = function (entity, id) {
            var _this = this;
            if (this.navBar)
                this.navBar.updateSelectedState(id);
            MobileCRM.bridge.command("setChannel", entity + ":" + id, function (topicDef) {
                _this.setCurrentChannel(topicDef);
                _this.posts([]); // Clear all posts
                _this.isDirect(_this.isDirectChannel());
                _this.InitPhase(true);
                _this.hasOlderPosts(true);
                _this.offsetBottom = 0;
                _this.update(true);
                _this.closeChannels();
            }, function (errMsg) { }, this);
        };
        Topic.prototype.setCurrentChannel = function (channel) {
            this.currentChannel = channel;
            var name = channel.name;
            this.channelType(channel.regardingId ? (" (" + channel.regardingEntity + ")") : "");
            this.channelName(name);
            this.isFollowing(channel.subscribed);
            var loggedUser = this.loggedUser();
            if (loggedUser && channel && loggedUser.id != channel.regardingId && loggedUser.userid != channel.regardingId) {
                var entityName = channel.regardingEntity;
                this.showFollowingButton(typeof (entityName) != "string" ||
                    (entityName != "@broadcast" && (entityName.length <= 9 || entityName.substr(0, 9) != "@private:")));
                this.isPrivate(entityName == "@private:");
            }
            else
                this.showFollowingButton(false);
        };
        /**
        * Function that toggles whether the user follows or not the chosen channel
        */
        Topic.prototype.toggleFollow = function () {
            MobileCRM.bridge.command("followTopic", (this.isFollowing() ? "0" : "1"), function (data) {
                var wasFollowed = this.currentChannel.subscribed;
                this.currentChannel.subscribed = !wasFollowed;
                var id = this.currentChannel.id;
                if (wasFollowed)
                    this.navBar.removeChannel(id);
                else
                    this.navBar.appendChannel(id);
                this.setCurrentChannel(this.currentChannel); // refresh name and follow state
            }, function (errMsg) { }, this);
        };
        /**
        * Function that loads older posts
        */
        Topic.prototype.showOlder = function () {
            this.update(false);
        };
        /**
        * Function that loads demanded posts
        * @param index start index
        * @param count count of the posts to load
        * @param isScheduled sets whether it is the system or user request
        */
        Topic.prototype.update = function (reset, isScheduled) {
            var _this = this;
            var count = this.postsPageLen;
            var index = reset ? 0 : this.posts().length;
            MobileCRM.bridge.command("getPosts", reset + "," + count + "," + 0, function (posts) {
                _this.showLoading(false);
                //if (!reset)
                _this.hasOlderPosts(posts.length == count);
                _this.updatePosts(posts, index, isScheduled);
            }, function (errMsg) {
                _this.showLoading(false);
                Topic.onError(errMsg);
            }, this);
            this.posts().forEach(function (post) {
                post.modifiedOn.notifySubscribers();
            }, this);
        };
        /**
        * Function that gets the user information according to ID
        * @param id ID of the user to load
        * @param user User to update
        */
        Topic.prototype.jsUpdateUserInfo = function (id, user) {
            MobileCRM.bridge.command("getUser", id, function (newUser) {
                user.name(newUser.name);
                user.avatar(newUser.avatarData);
            }, function (errMsg) {
            }, this);
        };
        /**
        * Updates the submitted post after it has been save online or offline.
        * @param newPosts  the submitted post
        * @returns void
        */
        Topic.prototype.updateSubmittedPost = function (newPost) {
            var arr = [newPost];
            this.updatePosts(arr, 1, false);
            this.isSubmitPending = false;
        };
        /**
        * Function responsible for appending the posts
        * @param newPosts posts to append
        * @param dstPos start index
        * @param isScheduled sets whether it is the system or user request
        */
        Topic.prototype.updatePosts = function (newPosts, dstPos, isScheduled) {
            if (newPosts) {
                this.offsetHeight = document.getElementsByClassName("chatter-window")[0].scrollTop;
                for (var i = 0; i < newPosts.length; i++) {
                    var position = this.posts().length - dstPos;
                    var postDefinition = newPosts[i];
                    var post = this.getCachedPost(postDefinition.id);
                    if (!post) {
                        post = new Chatter.Post(postDefinition.id, this);
                        this.posts.splice(position, 0, post);
                    }
                    else {
                        if (this.posts()[position] != post) {
                            var oldIndex = this.posts.indexOf(post);
                            if (oldIndex >= 0) {
                                this.posts.splice(oldIndex, 1); // remove item from old position
                                if (position > oldIndex)
                                    position--; // removed item changed position
                            }
                            this.posts.splice(position, 0, post);
                        }
                    }
                    dstPos++;
                    var regarding = new Chatter.Reference(postDefinition.regarding.id, postDefinition.regarding.primaryName, postDefinition.regarding.entityName);
                    post.content(this.mEditor.EmoticonsToIcons(postDefinition.text));
                    post.user(this.getUser(postDefinition.userId));
                    post.createdOn(new Date(postDefinition.createdOn));
                    post.modifiedOn(new Date(postDefinition.modifiedOn));
                    post.regarding(regarding);
                    post.pending(postDefinition.isPending);
                    post.showDateHeader(true); // Reset in case we are changing an existing
                    post.isSending(false);
                    post.updateReactions(postDefinition.comments);
                    post.updateAttachments(postDefinition.attachments);
                    //if (postDefinition.userId != this.loggedUser().id && isScheduled) {
                    //	this.unreadedMessages(this.unreadedMessages() + 1);
                    //}
                }
                this.updatePostsPrefixVisibility(0);
                if (this.InitPhase()) {
                    if (document.getElementsByClassName("chatter-window")[0].clientHeight >= document.getElementsByClassName("chatter-posts")[0].clientHeight && document.getElementsByClassName("chatter-posts")[0].clientHeight > 0 && this.hasOlderPosts())
                        this.showOlder();
                    else {
                        this.postsHeight = document.getElementsByClassName("chatter-posts")[0].clientHeight;
                        this.ScrollToBottom();
                        this.InitPhase(false);
                    }
                }
                else {
                    if (isScheduled)
                        this.ScrollToBottom();
                    else
                        this.applyScrollPosition();
                    //this.holdPosition();
                }
                this.isLoading(false);
            }
        };
        Topic.prototype.updateLoggedUser = function () {
            var user = this.getCachedUser(this.loggedUser().id);
            if (user)
                this.jsUpdateUserInfo(this.loggedUser().id, user);
            this.jsUpdateUserInfo(this.loggedUser().id, this.loggedUser());
        };
        /**
        * Function that returns user according to ID
        * @param id ID of the user
        */
        Topic.prototype.getUser = function (id) {
            var user = this.getCachedUser(id);
            if (!user) {
                // jsGetUser is async, so if multiple calls of this method are invoked, the successcallback will be called after the loop finishes
                // we don't want to fetch single user multiple times, so store the dummy user and set its id now,and in success callback, its properties wiil be updated
                user = new Chatter.User(id);
                this.users.push(user);
                this.jsUpdateUserInfo(id, user);
            }
            return user;
        };
        /**
        * Returns already loaded post
        * @param id ID of the post
        */
        Topic.prototype.getCachedPost = function (id) {
            var posts = this.posts();
            for (var i = 0; i < posts.length; i++) {
                if (posts[i].id == id)
                    return posts[i];
            }
            return null;
        };
        /**
        * Returns already loaded user
        * @param id ID of the user
        */
        Topic.prototype.getCachedUser = function (id) {
            for (var i = 0; i < this.users.length; i++) {
                if (this.users[i].id == id)
                    return this.users[i];
            }
            return null;
        };
        return Topic;
    }());
    Chatter.Topic = Topic;
})(Chatter || (Chatter = {}));
