/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="Localization.ts" />
/// <reference path="NavBar.ts" />
/// <reference path="User.ts" />
var Chatter;
(function (Chatter) {
    var ChannelBrowser = (function () {
        function ChannelBrowser() {
            this.renderTimeout = 0;
            this.visible = ko.observable(false);
            this.filterText = ko.observable(); //.extend({ throttle: 300 });
            this.createChannelFrame = new CreateChannelFrame();
            this.itemsVisible = ko.observableArray();
            this.otherItemsVisible = ko.observableArray();
        }
        ChannelBrowser.prototype.show = function (title, placeHolder, items, otherItems, sectionTitles, callback, newChannelCallback) {
            var _this = this;
            this.title = title;
            this.placeHolder = placeHolder;
            this.sectionTitles = sectionTitles;
            this.newChannelCallback = newChannelCallback;
            this.filterText("");
            this.filterText.subscribe(this.onFilterChanged, this);
            this.visible(true);
            $(".channelSearchInput").focus();
            this.items = items.map(function (value) { return new ChannelBrowserItem(value, _this, function () {
                _this.visible(false);
                callback(value);
            }); });
            this.otherItems = otherItems.map(function (value) { return new ChannelBrowserItem(value, _this, function () {
                _this.visible(false);
                callback(value);
            }); });
            this.onFilterChanged(null);
        };
        ChannelBrowser.prototype.selectItem = function (item) {
            if (this.selectedItem)
                this.selectedItem.selected(false);
            this.selectedItem = item;
            if (item)
                item.selected(true);
        };
        ChannelBrowser.prototype.onFilterChanged = function (newText) {
            var _this = this;
            this.itemsVisible([]);
            this.otherItemsVisible([]);
            var filterText = Chatter.Localization.toLower(newText);
            var selectNextItem = true;
            if (this.selectedItem && this.selectedItem.matchesFilter(filterText))
                selectNextItem = false;
            else
                this.selectItem(null);
            var titleIndex = 0;
            var prevEntity = null;
            var applyFilter = function (item, index, items) {
                var visible = item.matchesFilter(filterText);
                item.visible(visible);
                var title = null;
                if (visible) {
                    if (selectNextItem) {
                        _this.selectItem(item);
                        selectNextItem = false;
                    }
                    var entity = item.regardingEntity;
                    if (entity != prevEntity) {
                        if (entity) {
                            if (entity != "@broadcast" && entity != "@private:")
                                title = entity;
                        }
                        else if (_this.sectionTitles)
                            title = _this.sectionTitles[titleIndex];
                        prevEntity = entity;
                    }
                }
                item.title(title);
            };
            this.items.forEach(applyFilter, this);
            titleIndex++;
            prevEntity = null;
            this.otherItems.forEach(applyFilter, this);
            this.startRendering(0, 0);
        };
        /**
         * Passes max 100 items to the DOM tree. Delays 100ms if some items are still pending
         * @param itemsIndex
         * @param otherItemsIndex
         */
        ChannelBrowser.prototype.startRendering = function (itemsIndex, otherItemsIndex) {
            var _this = this;
            if (this.renderTimeout != 0) {
                clearTimeout(this.renderTimeout);
                this.renderTimeout = 0;
            }
            var toAdd = 50;
            var visibleItems = [];
            while (itemsIndex < this.items.length) {
                var item = this.items[itemsIndex++];
                if (item.visible()) {
                    visibleItems.push(item);
                    if (--toAdd <= 0)
                        break;
                }
            }
            if (visibleItems.length > 0)
                (_a = this.itemsVisible).splice.apply(_a, [this.itemsVisible().length, 0].concat(visibleItems));
            if (toAdd > 0) {
                visibleItems = [];
                while (otherItemsIndex < this.otherItems.length) {
                    var item = this.otherItems[otherItemsIndex++];
                    if (item.visible()) {
                        visibleItems.push(item);
                        if (--toAdd <= 0)
                            break;
                    }
                }
                if (visibleItems.length > 0)
                    (_b = this.otherItemsVisible).splice.apply(_b, [this.otherItemsVisible().length, 0].concat(visibleItems));
            }
            if (itemsIndex < this.items.length || otherItemsIndex < this.otherItems.length)
                this.renderTimeout = setTimeout(function () { return _this.startRendering(itemsIndex, otherItemsIndex); }, 100);
            var _a, _b;
        };
        ChannelBrowser.prototype.onKeyPress = function (instance, event) {
            switch (event.charCode) {
                case 27:
                    this.visible(false);
                    event.preventDefault();
                    break;
                case 13:
                    if (this.selectedItem)
                        this.selectedItem.onClick();
                    event.preventDefault();
                    break;
                case 0:
                    switch (event.which) {
                        case 38:
                            var items = this.items;
                            if (this.selectedItem) {
                                var i = items.indexOf(this.selectedItem);
                                this.selectItem(i > 0 ? items[i - 1] : items[items.length - 1]);
                            }
                            event.preventDefault();
                            break;
                        case 40:
                            var items = this.items;
                            if (this.selectedItem) {
                                var i = items.indexOf(this.selectedItem);
                                this.selectItem(i < items.length - 1 ? items[i + 1] : items[0]);
                            }
                            event.preventDefault();
                            break;
                    }
                    break;
            }
            return true;
        };
        ChannelBrowser.prototype.createChannel = function () {
            var _this = this;
            this.createChannelFrame.show(this.filterText(), function (name, isPrivate) {
                if (name) {
                    _this.visible(false);
                    _this.newChannelCallback(name, isPrivate);
                }
                else
                    $(".channelSearchInput").focus();
            });
        };
        return ChannelBrowser;
    }());
    Chatter.ChannelBrowser = ChannelBrowser;
    var ChannelBrowserItem = (function () {
        function ChannelBrowserItem(channel, parent, onClick) {
            var _this = this;
            this.name = ko.observable(channel.name());
            this.regardingEntity = channel.regardingEntity;
            this.title = ko.observable();
            this.selected = ko.observable(false);
            this.visible = ko.observable(true);
            this.icon = channel.icon;
            this.onClick = function () {
                parent.selectItem(_this);
                setTimeout(onClick, 10);
            };
        }
        ChannelBrowserItem.prototype.matchesFilter = function (filterText) {
            return !filterText || Chatter.Localization.toLower(this.name()).indexOf(filterText) >= 0;
        };
        return ChannelBrowserItem;
    }());
    Chatter.ChannelBrowserItem = ChannelBrowserItem;
    var CreateChannelFrame = (function () {
        function CreateChannelFrame() {
            var _this = this;
            this.visible = ko.observable(false);
            this.name = ko.observable();
            this.isPrivate = ko.observable();
            this.title = Chatter.Localization.get("CreateChannel");
            this.isPrivateText = ko.computed(function () { return Chatter.Localization.get(_this.isPrivate() ? "Private" : "Public"); }, this);
        }
        CreateChannelFrame.prototype.show = function (preFillName, callback) {
            this.newChannelCallback = callback;
            this.name(preFillName || "");
            this.visible(true);
            $(".createChannelInput").focus();
        };
        CreateChannelFrame.prototype.onKeyPress = function (instance, event) {
            switch (event.charCode) {
                case 27:
                    this.close();
                    event.preventDefault();
                    break;
                case 13:
                    this.createChannel();
                    event.preventDefault();
                    break;
            }
            return true;
        };
        CreateChannelFrame.prototype.onPrivateBtnClick = function () {
            this.isPrivate(!this.isPrivate());
        };
        CreateChannelFrame.prototype.createChannel = function () {
            this.visible(false);
            this.newChannelCallback(this.name(), this.isPrivate());
        };
        CreateChannelFrame.prototype.close = function () {
            this.visible(false);
            this.newChannelCallback(null, false);
        };
        return CreateChannelFrame;
    }());
    Chatter.CreateChannelFrame = CreateChannelFrame;
})(Chatter || (Chatter = {}));
