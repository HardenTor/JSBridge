/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
var Chatter;
(function (Chatter) {
    var User = (function () {
        function User(id) {
            this.id = id;
            this.userid = null;
            this.name = ko.observable();
            this.avatar = ko.observable();
            this.color = ko.observable(this.generateRandomColor(id));
        }
        User.prototype.generateRandomColor = function (str) {
            var hash = 0, i, chr, len;
            for (i = 0, len = str.length; i < len; i++) {
                chr = str.charCodeAt(i);
                hash = ((hash << 5) - hash) + chr;
                hash |= 0; // Convert to 32bit integer
            }
            var mixRed = 180;
            var mixGreen = 180;
            var mixBlue = 180;
            var red = (hash >> 16) & 0xFF;
            var green = (hash >> 8) & 0xFF;
            var blue = (hash) & 0xFF;
            var red = (red + mixRed) / 2;
            var green = (green + mixGreen) / 2;
            var blue = (blue + mixBlue) / 2;
            var c = (red << 16) | (green << 8) | blue;
            var cstr = "#" + c.toString(16);
            return cstr;
        };
        return User;
    }());
    Chatter.User = User;
})(Chatter || (Chatter = {}));
