///<reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="event.ts" />
/// <reference path="appColors.ts" />
///<reference path="datePicker.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         * Event arguments with information about which item has been changed and which status is.
         */
        var SelectionChangedEventArgs = (function (_super) {
            __extends(SelectionChangedEventArgs, _super);
            function SelectionChangedEventArgs(item, status) {
                var _this = _super.call(this) || this;
                _this._item = item;
                _this._status = status;
                return _this;
            }
            Object.defineProperty(SelectionChangedEventArgs.prototype, "changedItem", {
                get: function () {
                    return this._item;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SelectionChangedEventArgs.prototype, "status", {
                get: function () {
                    return this._status;
                },
                enumerable: true,
                configurable: true
            });
            return SelectionChangedEventArgs;
        }(Resco.EventArgs));
        Controls.SelectionChangedEventArgs = SelectionChangedEventArgs;
        /**
         * Class represents one item in the ListBox component
         */
        var ListBoxItem = (function () {
            /**
             * Public constructor of the ListBoxItem with label for this item.
             * @param parent
             * @param data
             * @param label
             * @param isSelected
             */
            function ListBoxItem(parent, data, label, isSelected) {
                this._parent = parent;
                this._element = $("<div>").addClass("list-box-item");
                this._labelElement = $("<span>").addClass("text");
                this.element.append(this.labelElement);
                this.selectionChanged = new Resco.Event(this);
                this.data = data;
                this.label = label;
                this.isSelected = isSelected;
                this.element.on("click", this._listBoxItemClicked.bind(this));
            }
            Object.defineProperty(ListBoxItem.prototype, "parent", {
                //*** PROPERTIES ***//
                get: function () {
                    return this._parent;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBoxItem.prototype, "element", {
                get: function () {
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBoxItem.prototype, "labelElement", {
                get: function () {
                    return this._labelElement;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBoxItem.prototype, "data", {
                get: function () {
                    return this._data;
                },
                set: function (value) {
                    this._data = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBoxItem.prototype, "label", {
                get: function () {
                    return this._label;
                },
                set: function (value) {
                    if (this.label !== value) {
                        this._label = value;
                        this.labelElement.text(value);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBoxItem.prototype, "isSelected", {
                get: function () {
                    return this._isSelected;
                },
                set: function (value) {
                    if (value !== this.isSelected) {
                        this._isSelected = value;
                        if (value) {
                            this.element.addClass("selected");
                        }
                        else {
                            this.element.removeClass("selected");
                        }
                        this.updateColors();
                        //this.selectionChanged.raise(new SelectionChangedEventArgs(this, value), this); //JC: selectionChanged event could not be raised there, because it leads to periodical selectionChanged raising if selection of any item is changed in the selectionChanged handler. selectionChanged event is raised during click event now, to notify user interaction only.
                    }
                },
                enumerable: true,
                configurable: true
            });
            //*** METHODS ***//
            /**
             * Handles color updating based on the appColors object from parent ListBox.
             */
            ListBoxItem.prototype.updateColors = function () {
                if (this.isSelected) {
                    this.element.css("background-color", this.parent.appColors.listSelBackgroundColor ? this.parent.appColors.listSelBackgroundColor : "");
                    this.labelElement.css("color", this.parent.appColors.listSelForegroundColor ? this.parent.appColors.listSelForegroundColor : "");
                }
                else {
                    this.element.css("background-color", this.parent.appColors.listBackgroundColor ? this.parent.appColors.listBackgroundColor : "");
                    this.labelElement.css("color", this.parent.appColors.listForegroundColor ? this.parent.appColors.listForegroundColor : "");
                }
            };
            /**
             * Handles click on the one ListBoxItem in the ListBox.
             * @param sender
             * @param e
             */
            ListBoxItem.prototype._listBoxItemClicked = function (sender, e) {
                this.isSelected = !this.isSelected;
                this.selectionChanged.raise(new SelectionChangedEventArgs(this, this.isSelected), this); //JC: 
            };
            return ListBoxItem;
        }());
        /**
         * Public class represents list box component with lines of ListBoxItems.
         */
        var ListBox = (function () {
            function ListBox(appColors) {
                this._element = $("<div>").addClass("list-box");
                this._appColors = appColors;
                this._items = [];
                this.width = -1;
                this.height = -1;
                this.valueMember = "0";
                this.displayMember = "1";
                this.selectionChanged = new Resco.Event(this);
                if (this.appColors !== undefined)
                    this.appColors.propertyChanged.add(this, this._onPropertyChanged);
            }
            Object.defineProperty(ListBox.prototype, "element", {
                /* PROPERTIES */
                get: function () {
                    return this._element;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "appColors", {
                get: function () {
                    return this._appColors;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "dataSource", {
                get: function () {
                    return this._dataSource;
                },
                set: function (value) {
                    if (Array.isArray(value)) {
                        this._dataSource = value;
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "items", {
                get: function () {
                    return this._items;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "width", {
                get: function () {
                    return this._width;
                },
                set: function (value) {
                    if (value !== this.width) {
                        this._width = value;
                        this.element.css("width", (value > -1) ? (value + "px") : "");
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "height", {
                get: function () {
                    return this._height;
                },
                set: function (value) {
                    if (value !== this.height) {
                        this._height = value;
                        this.element.css("height", (value > -1) ? (value + "px") : "");
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "valueMember", {
                get: function () {
                    return this._valueMember;
                },
                set: function (value) {
                    if (value !== this.valueMember) {
                        this._valueMember = value ? value : "0";
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(ListBox.prototype, "displayMember", {
                get: function () {
                    return this._displayMember;
                },
                set: function (value) {
                    if (value !== this.displayMember) {
                        this._displayMember = value ? value : "1";
                        this._reloadItems();
                    }
                },
                enumerable: true,
                configurable: true
            });
            //*** METHODS ***//
            ListBox.prototype._createElements = function () {
                for (var i = 0; i < this.items.length; i++) {
                    var item = this.items[i];
                    this.element.append(item.element);
                    var separator = $("<div>").addClass("separator");
                    this.element.append(separator);
                }
            };
            ListBox.prototype._reloadItems = function () {
                var _this = this;
                if (Array.isArray(this.dataSource)) {
                    this._items = this.dataSource.map(function (item) {
                        var listBoxItem = new ListBoxItem(_this, item[_this.valueMember], item[_this.displayMember], false);
                        listBoxItem.selectionChanged.add(_this, _this._onItemSelectionChanged);
                        return listBoxItem;
                    });
                    this.element.empty();
                    this._createElements();
                    this.updateColors();
                }
            };
            /**
             * Handles color updating based on the appColors object.
             */
            ListBox.prototype.updateColors = function () {
                this.element.css("background-color", this.appColors.listBackgroundColor ? this.appColors.listBackgroundColor : "");
                this.element.css("border-color", this.appColors.listSeparatorColor ? this.appColors.listSeparatorColor : "");
                $(".separator", this.element).css("background-color", this.appColors.listSeparatorColor ? this.appColors.listSeparatorColor : "");
                for (var i = 0; i < this.items.length; i++) {
                    var item = this.items[i];
                    item.updateColors();
                }
            };
            ListBox.prototype._onPropertyChanged = function (sender, e) {
                this.updateColors();
            };
            ListBox.prototype._onItemSelectionChanged = function (sender, e) {
                this.selectionChanged.raise(e, this);
            };
            return ListBox;
        }());
        Controls.ListBox = ListBox;
        var RescoComboBox = (function () {
            function RescoComboBox(settings) {
                this._isListBoxVisible = false;
                this.valueChanged = new Resco.Event(this);
                this._generateID(this._generateUniqueIdentifier());
                this._initSettings(settings);
                this._initComboBox();
            }
            RescoComboBox.prototype.openRescoComboBox = function () {
                this._isListBoxVisible = true;
                this._changedClassesInListBox();
                //@DM: Add invisible layer for handle click out of the rescoDatePicker element
                document.body.insertAdjacentHTML("afterbegin", "<div id='rescoInvisibleControlLayer" + this.id + "' class='rescoInvisibleControlLayer' style= 'width: " + document.body.offsetWidth + "px; height: " + document.body.offsetHeight + "px' > </div>");
                this._addEventListenerToInvisibleLayer();
            };
            RescoComboBox.prototype.closeRescoComboBox = function () {
                this._isListBoxVisible = false;
                this._changedClassesInListBox();
                this._removeEventListenerFromInvisibleLayer();
            };
            RescoComboBox.prototype._initSettings = function (settings) {
                this._settings = settings;
                if (this._settings.dimension === undefined) {
                    this._computeDimensions(this._settings.parentElement, this._settings.useParentDimensions);
                }
            };
            RescoComboBox.prototype._computeDimensions = function (parentElement, useParentDimentions) {
                this._settings.dimension = {
                    width: parentElement.offsetWidth > 0 ? parentElement.offsetWidth : 20,
                    height: parentElement.offsetHeight > 0 ? parentElement.offsetHeight : 40,
                    top: parentElement.offsetTop + parentElement.offsetHeight,
                    left: parentElement.offsetLeft,
                };
            };
            RescoComboBox.prototype._initComboBox = function () {
                var template = "<div id='" + this.id + "' class='rescoComboBox' style='width:" + this._settings.dimension.width + "px; height:" + this._settings.dimension.height + "px;'>\
					<div class='comboBoxHeader'>\
						<div class='selectedItem'>" + this.selectedValue + "</div>\
						<div class='arrow' style='height:" + this._settings.dimension.height + "px;'>\
							<div class='icon' style='background-image: url(" + this._settings.arrowImage + ")'></div>\
						</div>\
					</div>\
					<div class='listBoxContainer hidden'></div>\
				</div>";
                this._settings.parentElement.insertAdjacentHTML("beforeend", template);
                this._initListBox();
                this.rescoComboBoxElement = this._settings.parentElement.getElementsByClassName("rescoComboBox")[0];
                this._labelElement = this.rescoComboBoxElement.getElementsByClassName("selectedItem")[0];
                if (!this._settings.showLabel) {
                    this._labelElement.style.display = "none";
                }
                this._addEventListenerToRescoComboBox();
            };
            RescoComboBox.prototype._initListBox = function () {
                var appColors = new Controls.AppColors(); ///#FIXME remove from initialization use as setting or use default template
                this._listBox = new ListBox(appColors);
                this._listBox.dataSource = this._settings.dataSource;
                this._listBox.displayMember = this._settings.displayMember;
                this._listBox.valueMember = this._settings.valueMember;
                this._listBoxElement = this._settings.parentElement.getElementsByClassName("listBoxContainer")[0];
                this._listBoxElement.appendChild(this._listBox.element[0]);
                this._listBox.selectionChanged.add(this, this._onListBoxSelectionChanged);
                this._changedClassesInListBox();
                this._listBoxMakeNewSelection();
            };
            RescoComboBox.prototype._listBoxMakeNewSelection = function () {
                for (var i = 0; i < this._listBox.items.length; i++) {
                    if (this._listBox.items[i].label === this.selectedValue) {
                        this._listBox.items[i].isSelected = true;
                    }
                    else {
                        this._listBox.items[i].isSelected = false;
                    }
                }
            };
            RescoComboBox.prototype._addEventListenerToRescoComboBox = function () {
                var _this = this;
                this.rescoComboBoxElement.addEventListener("click", function (e) {
                    if (_this._isListBoxVisible) {
                        _this.closeRescoComboBox();
                    }
                    else {
                        _this.openRescoComboBox();
                    }
                });
            };
            RescoComboBox.prototype._addEventListenerToInvisibleLayer = function () {
                var _this = this;
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                invisibleDatePickerLayer.addEventListener("click", function (e) {
                    _this.closeRescoComboBox();
                });
            };
            RescoComboBox.prototype._removeEventListenerFromInvisibleLayer = function () {
                var invisibleDatePickerLayer = document.getElementById("rescoInvisibleControlLayer" + this.id);
                document.body.removeChild(invisibleDatePickerLayer);
            };
            RescoComboBox.prototype._onListBoxSelectionChanged = function (sender, e) {
                var item = e.changedItem;
                this._updateLabel(item.label);
                this._listBoxMakeNewSelection();
                this.valueChanged.raise(new Controls.ValueChangedEventArgs(item.label), this);
            };
            Object.defineProperty(RescoComboBox.prototype, "selectedValue", {
                get: function () {
                    return this._settings.selectedValue;
                },
                enumerable: true,
                configurable: true
            });
            RescoComboBox.prototype._changedClassesInListBox = function () {
                if (this._isListBoxVisible) {
                    if (this._listBoxElement.classList.contains("hidden"))
                        this._listBoxElement.classList.remove("hidden");
                    this._listBoxElement.classList.add("visible");
                }
                else {
                    if (this._listBoxElement.classList.contains("visible"))
                        this._listBoxElement.classList.remove("visible");
                    this._listBoxElement.classList.add("hidden");
                }
            };
            RescoComboBox.prototype._updateLabel = function (label) {
                this._settings.selectedValue = label;
                this._labelElement.textContent = this.selectedValue;
            };
            ////#FIXME move to another Utilities class
            RescoComboBox.prototype._generateID = function (id) {
                var e = document.getElementById(id);
                if (e === null)
                    this.id = id;
                else
                    this._generateID(this._generateUniqueIdentifier());
            };
            ////#FIXME move to another Utilities class
            RescoComboBox.prototype._generateUniqueIdentifier = function () {
                var identifier = Math.random().toString(16).slice(-5).toLowerCase();
                return identifier;
            };
            return RescoComboBox;
        }());
        Controls.RescoComboBox = RescoComboBox;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
