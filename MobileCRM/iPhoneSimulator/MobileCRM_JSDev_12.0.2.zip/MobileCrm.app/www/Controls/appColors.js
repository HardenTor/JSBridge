/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="event.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         *  AppColors object that loads and holds colors used in application.
         */
        var AppColors = (function () {
            function AppColors() {
                this.propertyChanged = new Resco.Event(this);
                this._loadColors();
            }
            Object.defineProperty(AppColors.prototype, "formBackgroundColor", {
                get: function () {
                    return this._formBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.formBackgroundColor) {
                        this._formBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "titleBackgroundColor", {
                get: function () {
                    return this._titleBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.titleBackgroundColor) {
                        this._titleBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("titleBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "titleForegroundColor", {
                get: function () {
                    return this._titleForegroundColor;
                },
                set: function (value) {
                    if (value !== this.titleForegroundColor) {
                        this._titleForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("titleForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemBackgroundColor", {
                get: function () {
                    return this._formItemBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.formItemBackgroundColor) {
                        this._formItemBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemLabelForegroundColor", {
                get: function () {
                    return this._formItemLabelForegroundColor;
                },
                set: function (value) {
                    if (value !== this.formItemLabelForegroundColor) {
                        this._formItemLabelForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemLabelForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "formItemLinkColor", {
                get: function () {
                    return this._formItemLinkColor;
                },
                set: function (value) {
                    if (value !== this.formItemLinkColor) {
                        this._formItemLinkColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("formItemLinkColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listBackgroundColor", {
                get: function () {
                    return this._listBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.listBackgroundColor) {
                        this._listBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listForegroundColor", {
                get: function () {
                    return this._listForegroundColor;
                },
                set: function (value) {
                    if (value !== this.listForegroundColor) {
                        this._listForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSelBackgroundColor", {
                get: function () {
                    return this._listSelBackgroundColor;
                },
                set: function (value) {
                    if (value !== this.listSelBackgroundColor) {
                        this._listSelBackgroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSelBackgroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSelForegroundColor", {
                get: function () {
                    return this._listSelForegroundColor;
                },
                set: function (value) {
                    if (value !== this.listSelForegroundColor) {
                        this._listSelForegroundColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSelForegroundColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AppColors.prototype, "listSeparatorColor", {
                get: function () {
                    return this._listSeparatorColor;
                },
                set: function (value) {
                    if (value !== this.listSeparatorColor) {
                        this._listSeparatorColor = value;
                        this.propertyChanged.raise(new Resco.PropertyChangedEventArgs("listSeparatorColor"), this);
                    }
                },
                enumerable: true,
                configurable: true
            });
            AppColors.prototype._loadColors = function () {
                var _this = this;
                this._loadColor("FormBackground", function (r) { _this.formBackgroundColor = r; });
                this._loadColor("TitleBackground", function (r) { _this.titleBackgroundColor = r; });
                this._loadColor("TitleForeground", function (r) { _this.titleForegroundColor = r; });
                this._loadColor("FormItemBackground", function (r) { _this.formItemBackgroundColor = r; });
                this._loadColor("FormItemLabelForeground", function (r) { _this.formItemLabelForegroundColor = r; });
                this._loadColor("FormItemLink", function (r) { _this.formItemLinkColor = r; });
                this._loadColor("ListBackground", function (r) { _this.listBackgroundColor = r; });
                this._loadColor("ListForeground", function (r) { _this.listForegroundColor = r; });
                this._loadColor("ListSelBackground", function (r) { _this.listSelBackgroundColor = r; });
                this._loadColor("ListSelForeground", function (r) { _this.listSelForegroundColor = r; });
                this._loadColor("ListSeparator", function (r) { _this.listSeparatorColor = r; });
            };
            AppColors.prototype._loadColor = function (color, callback) {
                MobileCRM.Application.getAppColor(color, function (result) {
                    callback(result);
                }, function (err) {
                    //Editor.showMessageBox(err, ["OK"]);
                    console.log(err);
                });
            };
            return AppColors;
        }());
        Controls.AppColors = AppColors;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
