///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="timeRange.ts" />
///<reference path="statistic.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var ResourceDictionary = (function (_super) {
                __extends(ResourceDictionary, _super);
                function ResourceDictionary() {
                    return _super.call(this) || this;
                }
                ResourceDictionary.prototype.add = function (resources) {
                    for (var i = 0; i < resources.length; i++)
                        this.Add(resources[i].getID(), resources[i]);
                };
                return ResourceDictionary;
            }(Scheduler.Dictionary));
            Scheduler.ResourceDictionary = ResourceDictionary;
            var CachedObject = (function () {
                function CachedObject() {
                    this.cachedOn = 0;
                }
                CachedObject.prototype.setCachedTimeStamp = function () {
                    this.cachedOn = Date.now();
                };
                CachedObject.prototype.resetCachedTimeStamp = function () {
                    this.cachedOn = 0;
                };
                CachedObject.prototype.expired = function () {
                    return this.cachedOn && (Date.now() - this.cachedOn) > CachedObject.ExpirationTimeout;
                };
                return CachedObject;
            }());
            CachedObject.ExpirationTimeout = 15 * 60 * 1000;
            Scheduler.CachedObject = CachedObject;
            var RuleViolationType;
            (function (RuleViolationType) {
                RuleViolationType[RuleViolationType["None"] = 0] = "None";
                RuleViolationType[RuleViolationType["TravelUnavailability"] = 1] = "TravelUnavailability";
                RuleViolationType[RuleViolationType["OutsideWorkingHours"] = 2] = "OutsideWorkingHours";
                RuleViolationType[RuleViolationType["WindowStart"] = 3] = "WindowStart";
                RuleViolationType[RuleViolationType["WindowEnd"] = 4] = "WindowEnd";
                RuleViolationType[RuleViolationType["OverlappingTimeOffs"] = 5] = "OverlappingTimeOffs";
                RuleViolationType[RuleViolationType["OverlappingTasks"] = 6] = "OverlappingTasks";
                RuleViolationType[RuleViolationType["MissingSkills"] = 7] = "MissingSkills";
                RuleViolationType[RuleViolationType["MissingTerritories"] = 8] = "MissingTerritories"; // Qualified Territories - The qualified Resource does not operate in the following territories: [territory1], [territory2]
            })(RuleViolationType = Scheduler.RuleViolationType || (Scheduler.RuleViolationType = {}));
            var RuleViolation = (function () {
                function RuleViolation(violationType, data, tasksInCollision) {
                    this.violationType = violationType;
                    this.data = data || [];
                    this.tasksInCollision = tasksInCollision || [];
                }
                RuleViolation.initialize = function () {
                    RuleViolation.messages = new Scheduler.Dictionary();
                    RuleViolation.messages.Add(RuleViolationType.None.toString(), "");
                    RuleViolation.messages.Add(RuleViolationType.TravelUnavailability.toString(), "Scheduler.Msg.TravelUnavailability");
                    RuleViolation.messages.Add(RuleViolationType.OutsideWorkingHours.toString(), "Scheduler.Msg.OutsideWorkingHours");
                    RuleViolation.messages.Add(RuleViolationType.WindowStart.toString(), "Scheduler.Msg.WindowStart");
                    RuleViolation.messages.Add(RuleViolationType.WindowEnd.toString(), "Scheduler.Msg.WindowEnd");
                    RuleViolation.messages.Add(RuleViolationType.OverlappingTimeOffs.toString(), "Scheduler.Msg.OverlappingTimeOffs");
                    RuleViolation.messages.Add(RuleViolationType.OverlappingTasks.toString(), "Scheduler.Msg.OverlappingTasks");
                    RuleViolation.messages.Add(RuleViolationType.MissingSkills.toString(), "Scheduler.Msg.MissingSkills");
                    RuleViolation.messages.Add(RuleViolationType.MissingTerritories.toString(), "Scheduler.Msg.MissingTerritories");
                };
                return RuleViolation;
            }());
            Scheduler.RuleViolation = RuleViolation;
            RuleViolation.initialize(); // Call own static constructor manually (Dictionary must be initialized yet!), since static constructors are not supported in JavaScript and thus in TypeScript.
            var Neighbors = (function () {
                function Neighbors() {
                }
                return Neighbors;
            }());
            Scheduler.Neighbors = Neighbors;
            var TravelInfo = (function () {
                function TravelInfo() {
                }
                return TravelInfo;
            }());
            Scheduler.TravelInfo = TravelInfo;
            var Resource = (function () {
                function Resource(id, name, target, rowIndex, office) {
                    this.rowIndex = -1;
                    //super();
                    this.id = id;
                    this.name = name;
                    this.office = office;
                    this.target = target;
                    this.sorted = false;
                    //if (target)
                    //	this.setCachedTimeStamp();
                    this.rowIndex = rowIndex;
                    this._statistics = [];
                }
                Resource.prototype.reference = function () {
                    return new MobileCRM.Reference(Scheduler.Container.inputs.resources.entityName, this.id, this.name);
                };
                Resource.prototype.clone = function () {
                    var r = new Resource(this.id, this.name, this.target, this.rowIndex, this.office);
                    if (this.tasks) {
                        r.tasks = [];
                        for (var i = 0; i < this.tasks.length; i++) {
                            var cloned = this.tasks[i].clone();
                            delete cloned.ganttElement;
                            r.tasks.push(cloned);
                        }
                        r.sorted = this.sorted;
                    }
                    return r;
                };
                ;
                Resource.prototype.getID = function () {
                    return this.id;
                };
                Resource.prototype.getName = function () {
                    return this.name;
                };
                Resource.prototype.clearTasks = function () {
                    this.tasks = undefined;
                    this.sorted = false;
                };
                Resource.prototype.resetSort = function () {
                    this.sorted = false;
                };
                Resource.prototype.getOffice = function () {
                    return this.office;
                };
                Resource.prototype.getTasks = function () {
                    this.sort();
                    return this.tasks;
                };
                Resource.prototype.sort = function () {
                    if (!this.sorted && this.tasks && this.tasks.length > 1) {
                        this.tasks.sort(function (a, b) { return a.getStatus().isFinished() ? -1 : (b.getStatus().isFinished() ? 1 : (a.getStart() - b.getStart())); });
                        this.sorted = true;
                    }
                };
                Resource.getDefaultImage = function () {
                    if (Resource._imagePlaceholder === undefined) {
                        Resource._imagePlaceholder = null;
                        if (Scheduler.Container.inputs.resources.imagePlaceholder) {
                            var image = Scheduler.ImageFactory.getInstance().getImageAsBase64string(Scheduler.Container.inputs.resources.imagePlaceholder, "");
                            if (image)
                                Resource._imagePlaceholder = image;
                        }
                    }
                    return Resource._imagePlaceholder;
                };
                Resource.prototype.getImage = function (onLoad) {
                    if (this._image !== undefined)
                        onLoad(this._image);
                    else {
                        var verticalView = Scheduler.Container.inputs.resources;
                        var self = this;
                        if (verticalView.imageQuery) {
                            var repo = new MobileCrm.Data.DynamicRepository();
                            var entity = new MobileCrm.Data.DynamicEntity(verticalView.entityName, repo);
                            repo.add(new MobileCrm.Data.MetaProperty(verticalView.primaryKeyName, MobileCrm.Data.CrmType.PrimaryKey));
                            entity.trySetValue(verticalView.primaryKeyName, this.id);
                            var imageLoader = new MobileCrm.UI.JSBridgeImageLoader(verticalView.imageQuery);
                            self._image = Resource.getDefaultImage();
                            imageLoader.load(entity, function (data) {
                                if (data)
                                    self._image = "data:image/png;base64," + data;
                                onLoad(self._image);
                            });
                        }
                    }
                };
                Resource.prototype.addTask = function (task) {
                    this.removeTask(task);
                    task.setParent(this);
                    if (!this.tasks)
                        this.tasks = [];
                    this.tasks.push(task);
                    this.sorted = this.tasks.length === 1;
                };
                Resource.prototype.removeTask = function (task) {
                    var tasks;
                    if (task.getParent() && (tasks = task.getParent().getTasks())) {
                        var idx = tasks.indexOf(task);
                        if (idx !== undefined)
                            tasks.splice(idx, 1);
                    }
                    task.setParent(undefined);
                };
                Resource.prototype.findTaskById = function (id) {
                    var foundTask = null;
                    this.forEach(function (task) {
                        if (task.id === id) {
                            foundTask = task;
                            return true;
                        }
                        return false;
                    }, false);
                    return foundTask;
                };
                Resource.prototype.slotIsFreeForScheduling = function (range) {
                    return this.getPeriodCollisions(range, true, false).length === 0;
                };
                Resource.prototype.getNeighbors = function (task) {
                    if (!this.tasks)
                        return { prev: null, next: null };
                    this.sort();
                    var idx = this.tasks.indexOf(task);
                    if (idx < 0 || this.tasks.length == 1)
                        return { prev: null, next: null };
                    else if (idx === 0)
                        return { prev: null, next: this.tasks[idx + 1] };
                    else if (idx === this.tasks.length - 1)
                        return { prev: this.tasks[idx - 1], next: null };
                    else
                        return { prev: this.tasks[idx - 1], next: this.tasks[idx + 1] };
                };
                Resource.prototype.hasOfficeAddress = function (task) {
                    var location = task.getLocation();
                    var office = this.office ? this.office.location : undefined;
                    return location && office && office.address && office.address === location.address;
                };
                Resource.calculateTravelInfo = function (task, onResult, mode) {
                    var waypoint;
                    var self = this;
                    if (!task || !(waypoint = task.getLocation()))
                        return;
                    var parent = task.resource;
                    if (mode === undefined)
                        mode = task.getTravel().mode;
                    if (!(Scheduler.Container.inputs.scheduledTasks.attrTravelMode ? true : false) || mode == Scheduler.TravelMode.FromOfficeToOffice || mode == Scheduler.TravelMode.Default) {
                        Scheduler.Geo.Service.calculateTravelDurationsFromOffice(function (durations) {
                            if (durations && durations.length == 1) {
                                var travelInfo = { toAddress: waypoint, toDuration: durations[0], fromAddress: Scheduler.Geo.defaultOrigin, fromDuration: durations[0] };
                                onResult(travelInfo);
                            }
                            else
                                onResult(undefined);
                        }, [waypoint]);
                    }
                    else if (parent) {
                        var neighbors = parent.getNeighbors(task);
                        var tasks = [];
                        var origin;
                        var destination;
                        var waypoint = task.getLocation();
                        tasks.push(task);
                        if (neighbors) {
                            if (neighbors.prev && (mode & Scheduler.TravelMode.FromPreviousClient) == Scheduler.TravelMode.FromPreviousClient) {
                                origin = neighbors.prev.getLocation();
                                tasks.push(neighbors.prev);
                            }
                            if (neighbors.next && (mode & Scheduler.TravelMode.ToNextClient) == Scheduler.TravelMode.ToNextClient) {
                                destination = neighbors.next.getLocation();
                                tasks.push(neighbors.next);
                            }
                        }
                        Scheduler.Geo.Service.findOptimalRoute(function (route) {
                            if (route && route.durations && route.durations.length == 2) {
                                var travelInfo = { toAddress: waypoint, toDuration: route.durations[0], fromAddress: route.origin, fromDuration: route.durations[1] };
                                onResult(travelInfo);
                            }
                            else
                                onResult(undefined);
                        }, [waypoint], origin, destination, true);
                    }
                    else
                        onResult(undefined);
                };
                /*
                private _calculateTravelDuration(task: Task, neighbors: Neighbors, onFinishCallback: (travelInfo: TravelInfo) => void): void {
                    var waypoints = task.getLocation();
                    Geo.Service.getRouteDuration((travelAddressOffice: number) => {
                        if (travelAddressOffice === 0) {
                            onFinishCallback(undefined);
                            return;
                        }
        
                        var travelInfo: any = { toAddress: waypoints, toDuration: travelAddressOffice, fromAddress: waypoints, fromDuration: travelAddressOffice };
        
                        let callbackCounter = 1;
                        let onPartialFinishCallback = () => {
                            callbackCounter--;
                            if (callbackCounter === 0)
                                onFinishCallback(travelInfo);
                        };
        
                        var prevAddress;
                        if (neighbors.prev && (prevAddress = neighbors.prev.getLocation())) {
                            callbackCounter++;
                            Geo.Service.getRouteDuration((travelPrevAddressOffice: number) => {
                                let duration = task.getWorkStart() - neighbors.prev.getWorkEnd();
        
                                // if travel from task A (previous) to office and from office to task B (current) is longer than time space between tasks, then calculate travel A-B
                                if ((travelPrevAddressOffice > 0) && ((travelPrevAddressOffice + travelAddressOffice + 10 * minuteInMiliseconds) > duration)) {
                                    Geo.Service.getRouteDuration((travelAB: number) => {
                                        if (travelAB > 0 && travelAB < (travelPrevAddressOffice + travelAddressOffice)) {
                                            travelInfo.toAddress = prevAddress;
                                            travelInfo.toDuration = travelAB;
                                        }
                                        onPartialFinishCallback();
                                    }, prevAddress, waypoints);
                                }
                                else
                                    onPartialFinishCallback();
                            }, prevAddress);
                        }
        
                        var nextAddress;
                        if (neighbors.next && (nextAddress = neighbors.next.getLocation())) {
                            callbackCounter++;
                            Geo.Service.getRouteDuration((travelNextAddressOffice: number) => {
                                let duration = neighbors.next.getWorkStart() - task.getWorkEnd();
        
                                // if travel from task A (current) to office and from office to task B (next) is longer than time space between tasks, then calculate travel A-B
                                if ((travelNextAddressOffice > 0) && ((travelAddressOffice + travelNextAddressOffice + 10 * minuteInMiliseconds) > duration)) {
                                    Geo.Service.getRouteDuration((travelAB: number) => {
                                        if (travelAB > 0 && travelAB < (travelAddressOffice + travelNextAddressOffice)) {
                                            travelInfo.fromAddress = nextAddress;
                                            travelInfo.fromDuration = travelAB;
                                        }
                                        onPartialFinishCallback();
                                    }, waypoints, nextAddress);
                                }
                                else
                                    onPartialFinishCallback();
                            }, nextAddress);
                        }
        
                        onPartialFinishCallback();
                    }, waypoints);
                }
                */
                Resource.prototype.forEach = function (callback, ignoreCompleted) {
                    if (!this.tasks)
                        return;
                    this.sort();
                    if (ignoreCompleted) {
                        for (var i = 0; i < this.tasks.length; i++)
                            if (this.tasks[i].getStatus().isFinished() === false && callback(this.tasks[i]))
                                break;
                    }
                    else {
                        for (var i = 0; i < this.tasks.length; i++)
                            if (callback(this.tasks[i]))
                                break;
                    }
                };
                /**
                 * Find all overlaps between requiredPeriod and time period of other tasks belonging to this resource.
                 * Returns all overlapped tasks.
                 * @param requiredPeriod time period that should be considered if overlaps with another tasks time periods
                 * @param firstOnly if true method returns only the first overlapped task that is find (and end finding)
                 * @param ignoreTravel if true task time period without travel to and travel from duration will be considered
                 * @param ignoreTaskWithId task that match this id will not be considered
                 */
                Resource.prototype.getPeriodCollisions = function (requiredPeriod, firstOnly, ignoreTravel, ignoreTaskWithId) {
                    var collisions = [];
                    var tasks = this.getTasks();
                    if (!tasks)
                        return collisions;
                    for (var i = 0; i < tasks.length; i++) {
                        var task = tasks[i];
                        if (task.getStatus().isFinished() || (task.getID() === ignoreTaskWithId))
                            continue;
                        var taskPeriod = void 0;
                        if (ignoreTravel)
                            taskPeriod = new Scheduler.TimeRange(task.getWorkStart(), task.getWorkEnd());
                        else
                            taskPeriod = new Scheduler.TimeRange(task.getStart(), task.getEnd());
                        if (taskPeriod.contain(requiredPeriod)) {
                            collisions.push(task);
                            if (firstOnly)
                                break;
                        }
                    }
                    return collisions;
                };
                Resource.prototype.updateStatistics = function (view) {
                    var _this = this;
                    this._statistics = [];
                    view.zoom.forEachMonth(function (startDate, endDate, workingDays) {
                        var statistic = new Scheduler.Statistic(_this, new Scheduler.TimeRange(startDate.valueOf(), endDate.valueOf()), workingDays);
                        statistic.updateStatistics();
                        _this._statistics.push(statistic);
                    });
                };
                Resource.prototype.getStatistics = function () {
                    return this._statistics;
                };
                /**
                 * Check rule violations for resourceTask and call callback function when partial and complete data are acquired.
                 * Callback function is called first time (with completed argument set to false) when partial (synch) data are acquired.
                 * Callback function is called second time (with completed argument set to true) when all (synch + async) data are acquired.
                 * @param resourceTask task belonging to this resource, for which we need to get rule violations
                 * @param onFinishCallback callback function that is called when partial and complete data are acquired
                 */
                Resource.prototype.getRuleViolations = function (resourceTask) {
                    var ruleViolations = [];
                    if (resourceTask.resource !== this)
                        return ruleViolations;
                    // check OverlappingTasks and OverlappingTimeOffs
                    var overlappingTasksNames = [];
                    var overlappingTasks = [];
                    var overlappingTimeOffs = [];
                    var tasksInCollision = this.getPeriodCollisions(new Scheduler.TimeRange(resourceTask.getWorkStart(), resourceTask.getWorkEnd()), false, true, resourceTask.id);
                    for (var i = 0; i < tasksInCollision.length; i++) {
                        var taskInCollision = tasksInCollision[i];
                        if (taskInCollision.isTimeOff()) {
                            overlappingTimeOffs.push(taskInCollision);
                        }
                        else {
                            overlappingTasksNames.push(taskInCollision.getName());
                            overlappingTasks.push(taskInCollision);
                        }
                    }
                    if (overlappingTasks.length > 0)
                        ruleViolations.push(new RuleViolation(RuleViolationType.OverlappingTasks, overlappingTasksNames, overlappingTasks));
                    if (overlappingTimeOffs.length > 0)
                        ruleViolations.push(new RuleViolation(RuleViolationType.OverlappingTimeOffs, undefined, overlappingTimeOffs));
                    // check WindowStart
                    if (resourceTask.isBeforeWindowStart())
                        ruleViolations.push(new RuleViolation(RuleViolationType.WindowStart));
                    // check WindowEnd
                    if (resourceTask.isAfterWindowEnd())
                        ruleViolations.push(new RuleViolation(RuleViolationType.WindowEnd));
                    // check OutsideWorkingHours
                    if (resourceTask.isOutsideWorkingHours()) {
                        ruleViolations.push(new RuleViolation(RuleViolationType.OutsideWorkingHours));
                    }
                    else {
                        // check TravelUnavailability
                        var travelUnavailability = resourceTask.isTravelUnavailability(resourceTask, tasksInCollision.length);
                        if (travelUnavailability.unavailable) {
                            var travel = resourceTask.getTravel();
                            var data = [travel.toInMinutes.toString(), travel.fromInMinutes.toString()];
                            ruleViolations.push(new RuleViolation(RuleViolationType.TravelUnavailability, data, travelUnavailability.collisions));
                        }
                    }
                    // check MissingSkills
                    // TODO: Add check for missing skills in the future. Think about it how to make it efficiently, because it is asynchronous.
                    // check MissingTerritories
                    // TODO: Add check for missing territories in the future. Think about it how to make it efficiently, because it is asynchronous.
                    return ruleViolations;
                };
                return Resource;
            }());
            Scheduler.Resource = Resource;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
