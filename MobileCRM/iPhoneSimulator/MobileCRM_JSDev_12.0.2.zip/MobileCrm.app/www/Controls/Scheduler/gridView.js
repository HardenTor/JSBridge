///<reference path="../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../TypeScriptDefinitions/perfect-scrollbar.d.ts" />
///<reference path="../../Controls/datePicker.ts"/>
///<reference path="../../Controls/popupMenu.ts"/>
///<reference path="../../Controls/gestureManager.ts"/>
///<reference path="autoplanner.ts" />
///<reference path="scroller.ts" />
///<reference path="container.ts" />
///<reference path="utilities.ts" />
///<reference path="taskMoveManager.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var View = (function () {
                function View(container, minGanttSize) {
                    this.xOffsetUT = 0;
                    this.timeNow = 0;
                    this._columnWidth = 0;
                    this._rowHeight = 0;
                    this._resourceUrl = 'res/'; // URL to resources (images etc.)
                    this._rescoDatePicker = null;
                    this.container = container; // is the a GantEditor instance
                    this._minGanttSize = minGanttSize;
                    this.zoom = new Zoom(this.container.settings);
                    this._rowHeight = this.container.listRowHeight;
                    this.taskPopupMenu = new Controls.PopupMenu();
                    this.taskPopupMenu.menuColor = Scheduler.Container.constants.componentsBackgroundColor;
                    this.taskPopupMenu.borderColor = "#aaaaaa";
                    this.taskPopupMenu.useBorder = true;
                    this.taskPopupMenu.iconSize = 22;
                    if (!Scheduler.Container.ref.isDesktop)
                        Scheduler.Container.constants.taskTooltipEnabled = false;
                    this.element = this._createViewElement();
                }
                Object.defineProperty(View.prototype, "viewBody", {
                    //public get viewHeader(): ViewHeader {
                    //	return this._viewHeader;
                    //}
                    get: function () {
                        return this._viewBody;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(View.prototype, "todayLine", {
                    get: function () {
                        return this._todayLine;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(View.prototype, "vScroll", {
                    get: function () {
                        return this.viewBody.vScroll;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(View.prototype, "columnWidth", {
                    get: function () {
                        return this._columnWidth;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(View.prototype, "rowHeight", {
                    get: function () {
                        return this._rowHeight;
                    },
                    enumerable: true,
                    configurable: true
                });
                View.prototype.getRowPosition = function (rowIndex) {
                    return rowIndex * this.rowHeight;
                };
                View.prototype._createViewElement = function () {
                    var _this = this;
                    this._viewHeader = new ViewHeader(this, this.zoom, this._minGanttSize);
                    this.timeNow = new Date().getTime();
                    if (this.zoom.getVisibleTimeRange().timeIsInside(this.timeNow))
                        this._todayLine = new TodayLine(this); // Constructor "new ViewHeader()" must be called first to ensure that zoom.setContentWidth() method was called and initialized this._pixelsPerMilisecond!
                    else
                        this._todayLine = undefined;
                    this._viewBody = new ViewBody(this, this._viewHeader.computedTableWidth, this.container.listHeight);
                    this._viewHeader.build(this, this.zoom, function (isEnd, isHoliday, width) {
                        _this._viewBody.addCell(1, isEnd, isHoliday, width);
                    });
                    var element = $("<div>");
                    element.attr("id", "gridView");
                    element.css({ width: this._viewHeader.computedTableWidth });
                    element.append(this._viewHeader.element);
                    element.append(this.viewBody.element);
                    if (this.todayLine)
                        element.append(this.todayLine.handleElement);
                    return element;
                };
                //<%-------------------------------------- GANTT TASK GRAPHIC ELEMENT --------------------------------------%>
                View.prototype.createCoverLayer = function () {
                    if (this.container.draggableContainer.focusedTask !== undefined) {
                        var ids = this.container.draggableContainer.focusedTask.getAvailableResorcesIdForMove();
                        if (ids.length > 0) {
                            var coverTemplate = "<div id='coverLayer'>";
                            for (var _i = 0, ids_1 = ids; _i < ids_1.length; _i++) {
                                var row = ids_1[_i];
                                var rowTemplate = "<div class='moveCoverRow' style='height:" + Scheduler.Container.constants.listCtrlRowHeight + "px; width: 100%; background-color: " + (row.canAssign ? "" : "gray") + "'></div>";
                                coverTemplate += rowTemplate;
                            }
                            coverTemplate += "</div>";
                            this.viewBody.vScrollContentElement.append(coverTemplate);
                        }
                    }
                };
                View.prototype.removeCoverLayer = function () {
                    $("#coverLayer").remove();
                };
                View.prototype.hasCoverLayer = function () {
                    return $("#coverLayer").length > 0;
                };
                View.dateMillisecondsToText = function (dateMilliseconds) {
                    if (!dateMilliseconds)
                        return "";
                    var date = new Date(dateMilliseconds);
                    var options = { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" };
                    return date.toLocaleString([], options);
                };
                View.prototype.redrawTasks = function () {
                    this.xOffsetUT = 0;
                    this.redrawTasksInRange(0);
                };
                View.prototype.redrawTasksInRange = function (startIndex) {
                    var counter = Scheduler.Container.constants.unscheduledViewMaxTasksInRow;
                    var refreshableContainer = startIndex === 0 ? null : this.element;
                    var tasksContainerElement = this.viewBody.tasksContainerElement;
                    //let unscheduledTasksContainer = this.element.find("#undefinedTasks");
                    //Debug.writeln("TaskDrawingAll[start]"); //for performance measurement only
                    //Task.performances[0] = new Performance(); //for performance measurement only
                    //Task.perfdata[0] = 0; //for performance measurement only
                    //Task.perfdata[1] = 0; //for performance measurement only
                    //Task.performances[1] = new Performance(); //for performance measurement only
                    //Task.performances[1].start(); //for performance measurement only
                    this.container.forEachScheduledTaskInRange(startIndex, function (task, parent) {
                        task.drawBox(tasksContainerElement[0], refreshableContainer);
                        //Task.perfdata[1]++; //for performance measurement only
                    });
                    //Debug.writeln("TaskCount: " + Task.perfdata[1]); //for performance measurement only
                    //Debug.writeln("TaskDrawing[createContent]: " + Task.perfdata[0] + "ms"); //for performance measurement only
                    //Debug.writeln("TaskDrawingAll[end]: " + Task.performances[1].end() + "ms"); //for performance measurement only
                    /*
                    if (unscheduledTasksContainer.length > 0) {
                        this.container.unscheduledTasksBar.forEach((task) => {
                            if (--counter >= 0) {
                                task.drawBox(unscheduledTasksContainer[0], refreshableContainer);
                            }
                        });
                    }*/
                    this.onTasksChanged();
                };
                View.prototype.redrawStatistics = function () {
                    var _this = this;
                    this.container.forEachStatistic(function (statistic, resource) {
                        statistic.draw(_this);
                    });
                };
                View.prototype.redrawStatisticsInRange = function (startIndex) {
                    var _this = this;
                    this.container.forEachStatisticInRange(startIndex, function (statistic, resource) {
                        statistic.draw(_this);
                    });
                };
                View.prototype.updateStatistics = function () {
                    this.updateStatisticsInRange(0);
                };
                View.prototype.updateStatisticsInRange = function (startIndex) {
                    var _this = this;
                    this.container.forEachScheduledTaskInRange(startIndex, function (task, parent) {
                        task.updateRuleViolations();
                    });
                    this.container.forEachResourceInRange(startIndex, function (resource) {
                        resource.updateStatistics(_this);
                    });
                };
                /**
                 * Force months mode recalculation to use 6 or 12 months depending on view width
                 */
                View.prototype.updateMonthsMode = function () {
                    if (this.zoom.inMonthsMode())
                        this.setLevel("m");
                };
                View.prototype.setLevel = function (id) {
                    var range = this.zoom.getTimeRange();
                    var date = range ? new Date(range.start) : new Date();
                    var settings = this.container.settings;
                    var zoomLevel = settings.zoomLevel;
                    if (id === "m") {
                        var viewWidth = this.element.width();
                        id = viewWidth <= (Zoom.Levels["m12"].m_minimalColumnWidth * 12) ? "m6" : "m12"; // mark "<=" (equality) is necessary because this.element.width() can not be less that width of its content element
                    }
                    if (zoomLevel !== id) {
                        if (zoomLevel.charAt(0) === "m") {
                            date = settings.selectedDate; // if month statistics overview was shown, use cached date from previous view to show new view in the same day
                        }
                        else if (id.charAt(0) !== "m") {
                            if (range && range.timeIsInside(new Date().valueOf()))
                                date = settings.selectedDate = new Date();
                        }
                        if (settings.zoomLevel != id) {
                            settings.zoomLevel = id;
                            settings.setDirty();
                            this.container.settings = settings;
                        }
                        //settings.save(this.container.settingsFileName);
                        this.zoom = new Zoom(settings);
                        this.scrollToDate(date);
                        this.container.updateTodayText();
                    }
                };
                View.prototype.setZoomLevel = function () {
                    var ctrl = this.container.buttonsBar.zoomLevelElement;
                    if (ctrl != undefined) {
                        this.setLevel(ctrl.val());
                    }
                };
                View.prototype.onResize = function () {
                    this.redraw();
                    this.updateMonthsMode();
                };
                View.prototype.onFilterChanged = function (settings) {
                    if (!settings)
                        return;
                    var zoomLevele = this.zoom.getLevel();
                    if (settings.zoomLevel !== zoomLevele) {
                        settings.zoomLevel = zoomLevele;
                        settings.setDirty();
                    }
                    this.zoom = new Zoom(settings);
                    this.container.settings = settings;
                    this.container.reloadTasks();
                };
                View.prototype.redraw = function () {
                    var parentElement = this.element.parent();
                    var scrollY = this.vScroll.getScrollPos();
                    if (this.container.isDesktop)
                        this._deactivatePerfectScrollbar();
                    var selectedRowIndex = this.selectedRowIndex;
                    var focusedTask = this.container.draggableContainer.focusedTask; // cache focusedTask because it will be set to undefined in takeFocusFromFocusedTask() method
                    this.container.draggableContainer.takeFocusFromFocusedTask(); // remove events associated with focus properly from this.element before they will be removed in next step during element.remove() method
                    this.element.remove();
                    this.element = this._createViewElement();
                    parentElement.append(this.element);
                    this.addExtentedEventsToView();
                    // set old row selection
                    this.selectedRowIndex = selectedRowIndex;
                    // set old selected task
                    if (focusedTask && focusedTask.isEditable() && !this.container.isLocked())
                        this.container.draggableContainer.setFocusToTask(focusedTask, true);
                    if (this.zoom.inMonthsMode()) {
                        this.updateStatistics();
                        this.redrawStatistics();
                        this.container.updateKPIControl();
                    }
                    else {
                        this.redrawTasks();
                        //this.container.unscheduledTasksBar.updateLabel();
                        if (this.container.fresh) {
                            this.container.fresh = false; // !!!this.container.fresh must be reset before showToday() call to prevent recursive infinite loop!!!
                            if (this.zoom && this.zoom.getVisibleTimeRange().timeIsInside(this.container.settings.selectedDate.getTime()) == false)
                                this.showDate(this.container.settings.selectedDate);
                        }
                    }
                    this.container.setButtonsBarInfo();
                    if (this.container.isDesktop)
                        this._activatePerfectScrollbar();
                    //set old scroll
                    this.vScroll.setScrollPos(scrollY); // @JC: Setting scroll position redraws DOM elements immediately. Therefore it is better to have all tasks loaded yet to avoid flickering.
                };
                View.prototype.appendRows = function (rowsCount) {
                    var scrollY = this.vScroll.getScrollPos();
                    if (this.container.isDesktop)
                        this._deactivatePerfectScrollbar();
                    var loadedResourcesCount = this.viewBody.getRowsCount();
                    this.viewBody.updateToNewRows();
                    if (this.hasCoverLayer()) {
                        this.removeCoverLayer();
                        this.createCoverLayer();
                    }
                    if (this.zoom.inMonthsMode()) {
                        this.updateStatisticsInRange(loadedResourcesCount);
                        this.redrawStatisticsInRange(loadedResourcesCount);
                        this.container.updateKPIControl();
                    }
                    else {
                        this.redrawTasksInRange(loadedResourcesCount);
                    }
                    if (this.container.isDesktop)
                        this._activatePerfectScrollbar();
                    this.vScroll.setScrollPos(scrollY);
                };
                View.prototype._activatePerfectScrollbar = function () {
                    var bodyTableElement = this.viewBody.element;
                    if (bodyTableElement.length > 0) {
                        this._perfectScrollbar = new PerfectScrollbar(bodyTableElement[0], { suppressScrollX: true });
                    }
                };
                View.prototype._deactivatePerfectScrollbar = function () {
                    if (this._perfectScrollbar) {
                        this._perfectScrollbar.destroy();
                        this._perfectScrollbar = undefined;
                    }
                };
                //public appendNewTasks(startRow: number): void {
                //	var par = this.element.parent();
                //	var self = this;
                //	//try to maintain last scroll
                //	var scrollY = this.vScroll.getScrollPos();
                //	if (this.container.isDesktop)
                //		this.viewBody.element.perfectScrollbar("destroy");
                //	this.container.forEachResourceInRange(startRow, function (resource: Resource) {
                //		var tasks: Task[] = resource.getTasks();
                //		if (tasks) {
                //			for (var i = 0; i < tasks.length; i++) {
                //				var task: Task = tasks[i];
                //				if (task && task.resource )
                //					self.drawTask(task);
                //			}
                //		}
                //	});
                //	this.updateUTRowLabel();
                //	if (this.container.isDesktop)
                //		this.viewBody.element.perfectScrollbar({ suppressScrollX: true });
                //	this.vScroll.setScrollPos(scrollY); // @JC: Setting scroll position redraw DOM elements immediately. Therefore it is better to have all tasks loaded yet to avoid flickering.
                //}
                View.prototype.touchToRowIndex = function (e) {
                    var bodyTableElement = this.viewBody.element;
                    var yPositionInTasksContainer = (Controls.GestureManager.getPointerY(e) - bodyTableElement.offset().top) + bodyTableElement.scrollTop();
                    return this.container.position2RowIndex(yPositionInTasksContainer);
                };
                Object.defineProperty(View.prototype, "selectedRowIndex", {
                    get: function () {
                        return this.viewBody.selectedRowIndex;
                    },
                    set: function (rowIndex) {
                        this.viewBody.selectedRowIndex = rowIndex;
                    },
                    enumerable: true,
                    configurable: true
                });
                View.prototype.durationMillisecondsToText = function (durationMilliseconds) {
                    var date = new Date(durationMilliseconds);
                    var hours = date.getHours();
                    var minutes = date.getMinutes();
                    var out = date.getDate() + " days ";
                    out += (hours < 10 ? "0" + hours : hours) + ":";
                    out += (minutes < 10 ? "0" + minutes : minutes);
                    return out;
                };
                View.prototype.showDate = function (date) {
                    this.scrollToDate(!date ? new Date(Date.now()) : date);
                };
                View.prototype.doPageScroll = function (scrollPages) {
                    var newStartDate;
                    if (this.zoom.inMonthsMode()) {
                        var startDate = new Date(this.zoom.getTimeRange().start);
                        var year = startDate.getFullYear();
                        var month = startDate.getMonth();
                        month += this.zoom.inMonthsMode6() ? (6 * scrollPages) : (12 * scrollPages);
                        newStartDate = new Date(year, month);
                    }
                    else {
                        var start = this.zoom.getTimeRange().start + scrollPages * this.zoom.m_pageInMiliseconds;
                        if (!this.zoom.showWeekendsAndHolidays() && this.zoom.inHoursMode()) {
                            var direction = scrollPages > 0 ? +1 : -1;
                            while (Scheduler.Utilities.isHoliday(new Date(start + 12 * Scheduler.hourInMiliseconds)))
                                start += direction * this.zoom.m_pageInMiliseconds;
                        }
                        newStartDate = new Date(start);
                    }
                    this.scrollToDate(newStartDate);
                };
                View.prototype.scrollToDate = function (date) {
                    if (date === undefined)
                        return this.zoom.getVisibleTimeRange().start;
                    if (this.container.dataLoadEnabed(true)) {
                        this.container.settings.selectedDate = date;
                        this.container.settings.setDirty();
                        this.onFilterChanged(this.container.settings);
                        return this.zoom.getVisibleTimeRange().start;
                    }
                };
                View.prototype.onTasksChanged = function () {
                    this.container.updateKPIControl();
                };
                View.prototype.hasTaskOutsideTimeRange = function (task) {
                    var taskRangeWithTravel = new Scheduler.TimeRange(task.getStart(), task.getEnd());
                    var timeRange = this.zoom.getTimeRange();
                    return !timeRange.contain(taskRangeWithTravel);
                };
                View.prototype.hasScheduledTaskVisible = function (task) {
                    return task.getTaskBoxDimensions() !== undefined;
                };
                View.prototype._initRescoDatePicker = function () {
                    var firstDay = Scheduler.Container.defaultOffice.firstDayOfWeek;
                    var settings = {
                        firstWeekDay: firstDay,
                        actualDate: new Date(),
                        dayNames: Scheduler.Utilities.getAbbreviatedDayNames(firstDay),
                        monthNames: Scheduler.Container.constants.cultureInfo.dateTimeFormat.monthNames.slice(),
                        images: [
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_left.png", ""),
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_right.png", ""),
                        ],
                        platform: MobileCRM.bridge.platform,
                    };
                    this._rescoDatePicker = new Resco.Controls.RescoDatePicker(settings, this.container.buttonsBar.calendarPreviewElement[0], false);
                    this._rescoDatePicker.datePickerClicked.add(this, this._calendarPreviewClicked);
                    this._rescoDatePicker.datePickerBlur.add(this, this._calendarPreviewBlur);
                };
                /**
                 * Open calendar preview for jump to selected date.
                 */
                View.prototype.openCalendarPreview = function () {
                    if (this._rescoDatePicker === null)
                        this._initRescoDatePicker();
                    this._rescoDatePicker.showRescoDatePicker(true, 60); //Although taskBoxDiv has z-index: 10, but task eventTargetElement has z-idex: 50. Therefore z-index: 60 is enough to overlap focused task.
                };
                View.prototype._calendarPreviewClicked = function (sender, e) {
                    var clickedItem = e.item;
                    var date = clickedItem.date;
                    this._rescoDatePicker.hideRescoDatePicker();
                    this.showDate(date);
                };
                View.prototype._calendarPreviewBlur = function (sender, e) {
                    this._rescoDatePicker.hideRescoDatePicker();
                };
                View.prototype.addExtentedEventsToView = function () {
                    var _this = this;
                    this.addSwipeEventListenerToElement(function () { return _this.doPageScroll(-1); }, function () { return _this.doPageScroll(1); });
                    this._addLongPressEventToElement();
                };
                View.prototype.addSwipeEventListenerToElement = function (movePrevious, moveNext) {
                    var _this = this;
                    if (this.viewBody.element && this.viewBody.element.length > 0) {
                        var moveManagingElement = this.viewBody.element[0];
                        if (moveManagingElement) {
                            var swipeHammer = new Hammer(moveManagingElement);
                            swipeHammer.on("swipeleft", function (e) {
                                if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing | Scheduler.DragDropActions.WasProcessed))
                                    moveNext();
                            });
                            swipeHammer.on("swiperight", function (e) {
                                if (!_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.IsProcessing | Scheduler.DragDropActions.WasProcessed))
                                    movePrevious();
                            });
                        }
                    }
                };
                View.prototype._addLongPressEventToElement = function () {
                    if (Scheduler.Container.constants.taskPopupMenuEnabled) {
                        var bodyTableElement = this.viewBody.element;
                        var eventNameStart = Controls.GestureManager.DOWN + ".longpress";
                        bodyTableElement.off(eventNameStart).on(eventNameStart, null, this._onLongPressStart.bind(this));
                    }
                };
                View.prototype._onLongPressStart = function (e) {
                    var _this = this;
                    if ((e.which === 0) || (e.which === 1)) {
                        if (!this.zoom.inMonthsMode()) {
                            var bodyTableElement_1 = this.viewBody.element;
                            var eventNameMove_1 = Controls.GestureManager.MOVE + ".longpress";
                            this._longPressTimeoutId = setTimeout(function () {
                                _this._longPressTimeoutId = undefined;
                                if (!_this.container.isLocked() && !_this.container.draggableContainer.moveManager.hasStateFlags(Scheduler.DragDropActions.DragRecognized) && !Scheduler.TaskPropertyDlg.isShown()) {
                                    var rowIndex = _this.touchToRowIndex(e);
                                    var resource = _this.container.getResourceByRowIndex(rowIndex);
                                    if (resource) {
                                        var taskId = Scheduler.Task.getIdFromChildElement(e.target);
                                        var task = void 0;
                                        if (taskId && (task = resource.findTaskById(taskId)) && task.isEditable()) {
                                            _this._onShowTaskPopupMenu(task, rowIndex);
                                        }
                                        else {
                                            var x = Controls.GestureManager.getPointerX(e);
                                            var y = Controls.GestureManager.getPointerY(e);
                                            _this._onShowResourcePopupMenu({ x: x, y: y }, rowIndex);
                                        }
                                        // Prevent scrolling content (on iOS), because this event did not start on popup menu background container, thus it is not propagating to it, so default scrolling cannot be prevented in popup menu.
                                        bodyTableElement_1.on(eventNameMove_1, null, function (e) {
                                            e.preventDefault();
                                        });
                                    }
                                }
                            }, Scheduler.Container.constants.taskPopupMenuTimeout);
                            var eventNameEnd_1 = Controls.GestureManager.UP + ".longpress";
                            $("body").on(eventNameEnd_1, null, function (e) {
                                $("body").off(eventNameEnd_1);
                                bodyTableElement_1.off(eventNameMove_1);
                                _this.cancelLongPress();
                            });
                        }
                    }
                };
                View.prototype.cancelLongPress = function () {
                    if (this._longPressTimeoutId !== undefined) {
                        if (this._longPressTimeoutId !== null) {
                            clearTimeout(this._longPressTimeoutId);
                        }
                        this._longPressTimeoutId = undefined;
                    }
                };
                View.prototype._onShowTaskPopupMenu = function (task, rowIndex) {
                    Scheduler.TaskTooltip.removeTooltip();
                    this._initTaskPopupMenu();
                    var pos = this._getPopupMenuOffset(task);
                    this.taskPopupMenu.x = pos.x;
                    this.taskPopupMenu.y = pos.y;
                    var bodyTableElement = this.container.viewCtrl.viewBody.element;
                    var bodyTableBoxViewOffset = bodyTableElement.offset();
                    this.taskPopupMenu.insideRectangle = { x: bodyTableBoxViewOffset.left, y: bodyTableBoxViewOffset.top, width: bodyTableElement.width(), height: bodyTableElement.height() };
                    this.taskPopupMenu.open();
                    this.container.draggableContainer.setFocusToTask(task, false);
                    this.container.setSelectedRow(rowIndex);
                };
                View.prototype._onShowResourcePopupMenu = function (offset, rowIndex) {
                    Scheduler.TaskTooltip.removeTooltip();
                    this._initResourcePopupMenu();
                    this.taskPopupMenu.x = offset.x;
                    this.taskPopupMenu.y = offset.y;
                    var bodyTableElement = this.container.viewCtrl.viewBody.element;
                    var bodyTableBoxViewOffset = bodyTableElement.offset();
                    this.taskPopupMenu.insideRectangle = { x: bodyTableBoxViewOffset.left, y: bodyTableBoxViewOffset.top, width: bodyTableElement.width(), height: bodyTableElement.height() };
                    this.taskPopupMenu.open();
                    this.container.draggableContainer.takeFocusFromFocusedTask();
                    this.container.setSelectedRow(rowIndex);
                };
                View.prototype._initTaskPopupMenu = function () {
                    var _this = this;
                    this.taskPopupMenu.zIndex = 70;
                    this.taskPopupMenu.items = [];
                    this.taskPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.Rebook") || "Rebook Task", "url(" + Scheduler.Container.imageFolder + "rebook.png)", function (e) {
                        Scheduler.AutoPlanner.Core.rebookTask(_this.container.draggableContainer.focusedTask);
                    }));
                    this.taskPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.FindSubstitution") || "Substitute Resource", "url(" + Scheduler.Container.imageFolder + "findSubstitution.png)", function (e) {
                        Scheduler.AutoPlanner.Core.findSubstitution(_this.container.draggableContainer.focusedTask);
                    }));
                    this.taskPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.OptimizeResource") || "Optimize Resource", "url(" + Scheduler.Container.imageFolder + "optimizeResource.png)", function (e) {
                        var task = _this.container.draggableContainer.focusedTask;
                        if (task)
                            Scheduler.AutoPlanner.Core.optimizeResource(task.resource);
                    }));
                    if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Completed)) {
                        var itemLabel = (Scheduler.StringTable.get("Scheduler.Msg.SetAs") || "Set As") + " " + (Scheduler.StringTable.get("Scheduler.WOS.statuscode.6") || "Completed");
                        this.taskPopupMenu.items.push(new Controls.PopupMenuItem(itemLabel, "url(" + Scheduler.Container.imageFolder + "setAsCompleted.png)", function (e) {
                            if (_this.container.draggableContainer.focusedTask)
                                _this.container.draggableContainer.focusedTask.setAsCompleted();
                        }));
                    }
                    if (Scheduler.Container.statusCodeTable.isSupported(Scheduler.TaskStatusType.Canceled)) {
                        var itemLabel = (Scheduler.StringTable.get("Scheduler.Msg.SetAs") || "Set As") + " " + (Scheduler.StringTable.get("Scheduler.WOS.statuscode.7") || "Canceled");
                        this.taskPopupMenu.items.push(new Controls.PopupMenuItem(itemLabel, "url(" + Scheduler.Container.imageFolder + "setAsCanceled.png)", function (e) {
                            if (_this.container.draggableContainer.focusedTask)
                                _this.container.draggableContainer.focusedTask.setAsCanceled();
                        }));
                    }
                };
                View.prototype._initResourcePopupMenu = function () {
                    var _this = this;
                    this.taskPopupMenu.zIndex = 70;
                    this.taskPopupMenu.items = [];
                    this.taskPopupMenu.items.push(new Controls.PopupMenuItem(Scheduler.StringTable.get("Scheduler.Msg.OptimizeResource") || "Optimize Resource", "url(" + Scheduler.Container.imageFolder + "optimizeResource.png)", function (e) {
                        var rowIndex = _this.container.viewCtrl.selectedRowIndex;
                        var resource = _this.container.getResourceByRowIndex(rowIndex);
                        if (resource)
                            Scheduler.AutoPlanner.Core.optimizeResource(resource);
                    }));
                };
                View.prototype._getPopupMenuOffset = function (task) {
                    var taskBoxDivOffset = task.taskBoxDiv.offset();
                    var x = taskBoxDivOffset.left + (task.taskBoxDiv.width() / 2);
                    var y = taskBoxDivOffset.top + (task.taskBoxDiv.height() / 2);
                    return { x: x, y: y };
                };
                return View;
            }());
            Scheduler.View = View;
            var ViewHeader = (function () {
                function ViewHeader(view, zoom, minGanttSize) {
                    var settings = Scheduler.Container.constants;
                    var tableWidth = $(".rightPanel").width();
                    if (tableWidth === null || tableWidth === undefined) {
                        tableWidth = $(window).width() - settings.listCtrlWidth - 5;
                    }
                    this.calculatedColumnWidth = zoom.calculateColumnWidth(tableWidth);
                    view._columnWidth = this.calculatedColumnWidth < zoom.m_minimalColumnWidth ? zoom.m_minimalColumnWidth : this.calculatedColumnWidth;
                    this.computedTableWidth = Math.floor(zoom.columnsPerView() * view._columnWidth);
                    if (tableWidth && (!minGanttSize || (minGanttSize < 0)))
                        this.computedTableWidth = Math.max(this.computedTableWidth, tableWidth);
                    zoom.setContentWidth(this.computedTableWidth);
                    this.rowElement1 = $("<tr>").addClass("ganttHead1");
                    this.rowElement2 = $("<tr>").addClass("ganttHead2");
                    this.element = this._createGridViewHeaderElement();
                }
                ViewHeader.prototype.build = function (view, zoom, onDrawColumn) {
                    var _this = this;
                    var settings = Scheduler.Container.constants;
                    var calculatedColumnWidth = this.calculatedColumnWidth;
                    var columnsPerPage = zoom.columnsPerPage();
                    var tr1 = this.rowElement1;
                    var tr2 = this.rowElement2;
                    if (zoom.inDaysMode()) {
                        var dayToString_1 = (zoom.m_thresholdWidth && calculatedColumnWidth < zoom.m_thresholdWidth) ? settings.dayToShortString : settings.dayToString;
                        var lastWeekDay = (Scheduler.Container.defaultOffice.firstDayOfWeek + 6) % 7;
                        if (((lastWeekDay === 6) || (lastWeekDay === 0)) && !zoom.showWeekendsAndHolidays()) {
                            lastWeekDay = 5; // Friday
                        }
                        zoom.forEachPage(function (startDate, endDate, isHoliday) {
                            tr1.append(_this._createHeadCell(settings.timeRangeToString(startDate, new Date(endDate.valueOf() - 1)), columnsPerPage, false, columnsPerPage * view.columnWidth));
                        });
                        zoom.forEachColumn(function (startDate, endDate, isHoliday) {
                            tr2.append(_this._createHeadCell(dayToString_1(startDate), 1, isHoliday, view.columnWidth));
                            onDrawColumn(startDate.getDay() === lastWeekDay, isHoliday, view.columnWidth);
                        });
                    }
                    else if (zoom.inHoursMode()) {
                        var endHour = zoom.lastDisplayedHour();
                        zoom.forEachPage(function (startDate, endDate, isHoliday) {
                            tr1.append(_this._createHeadCell(settings.timeToString(startDate), columnsPerPage, false, columnsPerPage * view.columnWidth));
                        });
                        zoom.forEachColumn(function (startDate, endDate, isHoliday) {
                            var hour = startDate.getHours();
                            tr2.append(_this._createHeadCell(settings.hourToString(hour), 1, isHoliday, view.columnWidth));
                            onDrawColumn(hour === endHour, isHoliday, view.columnWidth);
                        });
                    }
                    else if (zoom.inMonthsMode()) {
                        var has6Months = zoom.inMonthsMode6();
                        zoom.forEachPage(function (startDate, endDate, isHoliday) {
                            tr1.append(_this._createHeadCell(settings.yearToString(startDate), columnsPerPage, false, columnsPerPage * view.columnWidth));
                        });
                        zoom.forEachColumn(function (startDate, endDate, isHoliday) {
                            tr2.append(_this._createHeadCell(settings.monthToString(startDate), 1, false, view.columnWidth));
                            var isLastMonth = ((startDate.getMonth() + 1) % (has6Months ? 6 : 12)) === 0;
                            onDrawColumn(isLastMonth, false, view.columnWidth);
                        });
                    }
                    else
                        console.error("Unknown zoom level.");
                };
                ViewHeader.prototype._createHeadCell = function (label, span, isHoliday, width) {
                    var th = $("<th>")
                        .html(label)
                        .attr("colSpan", span);
                    if (width)
                        th.width(Math.floor(width));
                    if (isHoliday)
                        th.addClass("holyColumnHeader");
                    else
                        th.css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    return th;
                };
                ViewHeader.prototype._createGridViewHeaderElement = function () {
                    var element = $("<div>").attr("id", "viewHeader");
                    element.width("100%");
                    element.height(Scheduler.Container.constants.viewHeaderHeight);
                    element.append(this._createHeaderTableElement());
                    return element;
                };
                ViewHeader.prototype._createHeaderTableElement = function () {
                    var headerTable = $("<table cellspacing=0 cellpadding=0>");
                    headerTable.width(this.computedTableWidth);
                    headerTable.addClass("headerTable");
                    if (this.rowElement1)
                        headerTable.append(this.rowElement1);
                    if (this.rowElement2)
                        headerTable.append(this.rowElement2);
                    return headerTable;
                };
                return ViewHeader;
            }());
            var ViewBody = (function () {
                function ViewBody(gridView, tableWidth, tableHeigh) {
                    this.gridView = gridView;
                    this.tasksContainerElement = $("<div>").attr("id", "tasksContainer");
                    this.trBodyElement = $("<tr>").addClass("ganttBody");
                    this._tableWidth = tableWidth;
                    this._tableHeigh = tableHeigh;
                    this.vScrollContentElement = this._createVScrollContentElement();
                    this.element = this._createGridViewBodyTableElement();
                    this.vScroll = new Scheduler.VScroll(this.element);
                }
                ViewBody.prototype.addCell = function (span, isEnd, isHoliday, width) {
                    var td = $("<td>")
                        .html("")
                        .attr("colSpan", span)
                        .addClass("ganttBodyCell")
                        .width(Math.floor(width));
                    if (isHoliday)
                        td.addClass("holyColumn");
                    if (isEnd)
                        td.addClass("endColumn");
                    this.trBodyElement.append(td);
                };
                ViewBody.prototype._createGridViewBodyTableElement = function () {
                    var element = $("<div>").attr("id", "viewBody");
                    element.css("top", Scheduler.Container.constants.viewHeaderHeight + "px");
                    element.css("background-color", Scheduler.Container.constants.componentsBackgroundColor);
                    element.append(this.vScrollContentElement);
                    var eventNameScroll = (MobileCRM.bridge && MobileCRM.bridge.platform == "iOS" && (Controls.GestureManager.pointerEventType === Controls.PointerEventType.touch)) ? "scroll.gdf touchmove.gdf" : "scroll.gdf";
                    element.on(eventNameScroll, null, function (e) { return Scheduler.Container.ref.gridViewScrolled(element.scrollTop()); });
                    if (Scheduler.Container.constants.enableRowSelection) {
                        var eventNameEnd = Controls.GestureManager.UP + ".selected";
                        element.on(eventNameEnd, null, this._onRowClicked.bind(this)); // touchend or mouseup event need to be used there to have e.target set to the correct element
                    }
                    return element;
                };
                ViewBody.prototype._onRowClicked = function (e) {
                    Scheduler.Container.ref.setSelectedRow(Scheduler.Container.ref.viewCtrl.touchToRowIndex(e));
                };
                ViewBody.prototype._createVScrollContentElement = function () {
                    var element = $("<div>").attr("id", "gridViewVScrollContent");
                    element.css("position", "relative"); // this is necessary to keep correct x and y coordinates within the container
                    element.css("width", this._tableWidth);
                    element.append(this._createNonWorkingLayer());
                    element.append(this._createRowsLayer(this._tableHeigh));
                    element.append(this._createBodyTableElement(this._tableWidth, this._tableHeigh, this.trBodyElement));
                    if (this.gridView.todayLine) {
                        element.append(this.gridView.todayLine.lineElement);
                    }
                    element.append(this._createTasksLayerElement());
                    return element;
                };
                ViewBody.prototype._createNonWorkingLayer = function () {
                    function createChildElement(startDate, endDate) {
                        var x = zoom.timeToPixelPosition(startDate.valueOf());
                        var y = zoom.timeToPixelPosition(endDate.valueOf());
                        var childTemplate = "<div class='nonWorkingTime' style='width:" + (y - x) + "px; left:" + x + "px'></div>";
                        return childTemplate;
                    }
                    function addInnerElements(workingDayStart, workingDayEnd) {
                        // JC: Quick fix. Need to implement hiding holidays days!
                        var dayWorkStartDate = new Date(workingDayStart);
                        var dayWorkEndDate = new Date(workingDayEnd);
                        var dayStartDate = new Date(dayWorkStartDate.getFullYear(), dayWorkStartDate.getMonth(), dayWorkStartDate.getDate());
                        var dayEndDate = new Date(dayWorkStartDate.getFullYear(), dayWorkStartDate.getMonth(), dayWorkStartDate.getDate() + 1);
                        if (zoom.showWeekendsAndHolidays() || !Scheduler.Utilities.isWeekend(dayStartDate.getDay())) {
                            element.innerHTML += createChildElement(dayStartDate, dayWorkStartDate);
                            element.innerHTML += createChildElement(dayWorkEndDate, dayEndDate);
                        }
                    }
                    var element = document.createElement("div");
                    element.classList.add("nonWorkingLayer");
                    var zoom = this.gridView.zoom;
                    if (!zoom.inMonthsMode()) {
                        var timeRange = zoom.getTimeRange();
                        var workingHours = Scheduler.Container.defaultOffice.getWorkingSlots(timeRange);
                        for (var i = 0; i < workingHours.length; i++) {
                            var workingHour = workingHours[i];
                            addInnerElements(workingHour.start, workingHour.end);
                        }
                    }
                    return element;
                };
                ViewBody.prototype._createRowsLayer = function (height) {
                    var element = document.createElement("div");
                    element.classList.add("rowsLayer");
                    this._addNewRowsToRowsLayer(element, 0, height);
                    return element;
                };
                ViewBody.prototype._createBodyTableElement = function (width, height, bodyElement) {
                    var element = $("<table cellspacing=0 cellpadding=0>");
                    element.addClass("bodyTable");
                    element.width(width);
                    element.height(height);
                    element.append(bodyElement);
                    return element;
                };
                ViewBody.prototype._createTasksLayerElement = function () {
                    var element = $("<div>").attr("id", "tasksLayer");
                    element.append(this.tasksContainerElement);
                    return element;
                };
                ViewBody.prototype._addNewRowsToRowsLayer = function (parentElement, startTopPosition, height) {
                    var rowHeight = Scheduler.Container.constants.listCtrlRowHeight;
                    for (var top_1 = startTopPosition; top_1 < height; top_1 += rowHeight) {
                        var row = document.createElement("div");
                        row.classList.add("ganttRow");
                        row.style.height = rowHeight + "px";
                        row.style.top = top_1 + "px";
                        row.setAttribute("data-index", Math.round(top_1 / rowHeight).toString());
                        parentElement.appendChild(row);
                    }
                };
                ViewBody.prototype.getRowsCount = function () {
                    var rowsLayer = this.vScrollContentElement.children(".rowsLayer");
                    return rowsLayer.children().length;
                };
                ViewBody.prototype.updateToNewRows = function () {
                    var height = this.gridView.container.listHeight;
                    var bodyTable = this.vScrollContentElement.children(".bodyTable");
                    var rowsLayer = this.vScrollContentElement.children(".rowsLayer");
                    var startTopPosition = bodyTable.height();
                    bodyTable.height(height);
                    this._addNewRowsToRowsLayer(rowsLayer[0], startTopPosition, height);
                };
                Object.defineProperty(ViewBody.prototype, "selectedRowIndex", {
                    get: function () {
                        var index = -1;
                        var selectedRowElement = this.vScrollContentElement.children(".rowsLayer").children(".ganttRow.selectedRow");
                        if (selectedRowElement && (selectedRowElement.length > 0)) {
                            var dataIndex = parseInt(selectedRowElement.attr("data-index"));
                            if (dataIndex !== NaN)
                                index = dataIndex;
                        }
                        return index;
                    },
                    set: function (rowIndex) {
                        var rowsLayer = this.vScrollContentElement.children(".rowsLayer");
                        rowsLayer.children(".ganttRow.selectedRow").removeClass("selectedRow");
                        rowsLayer.children(".ganttRow[data-index=" + rowIndex.toString() + "]").addClass("selectedRow");
                    },
                    enumerable: true,
                    configurable: true
                });
                return ViewBody;
            }());
            Scheduler.ViewBody = ViewBody;
            var ZoomLevelInfo = (function () {
                function ZoomLevelInfo(columnInMiliseconds, pageInMiliseconds, pagesPerView, minimalColumnWidth, thresholdWidth) {
                    this.m_columnInMiliseconds = columnInMiliseconds;
                    this.m_pageInMiliseconds = pageInMiliseconds;
                    this.m_pagesPerView = pagesPerView;
                    this.m_minimalColumnWidth = minimalColumnWidth;
                    this.m_thresholdWidth = thresholdWidth;
                }
                ZoomLevelInfo.prototype.daysInView = function () {
                    return (this.m_pageInMiliseconds * this.m_pagesPerView) / Scheduler.dayInMiliseconds;
                };
                return ZoomLevelInfo;
            }());
            Scheduler.ZoomLevelInfo = ZoomLevelInfo;
            var MonthHelper = (function () {
                function MonthHelper(workingDays, timeRange) {
                    this.workingDays = workingDays;
                    this.timeRange = timeRange;
                }
                return MonthHelper;
            }());
            var Zoom = (function (_super) {
                __extends(Zoom, _super);
                function Zoom(filter) {
                    var _this = _super.call(this, Scheduler.hourInMiliseconds, Scheduler.dayInMiliseconds, 1, 20) || this;
                    _this._startWorkingHour = 0;
                    _this._workingHours = 24;
                    _this._showWeekendsAndHolidays = true;
                    _this._pixelsPerMilisecond = 1; //stores coefficient to convert time period used in the view to pixels and pixels to the time period
                    var info = Zoom.Levels[!filter.zoomLevel ? "d" : filter.zoomLevel];
                    if (!info)
                        info = Zoom.Levels["d"];
                    _this._level = filter.zoomLevel;
                    _this.m_columnInMiliseconds = info.m_columnInMiliseconds;
                    _this.m_pageInMiliseconds = info.m_pageInMiliseconds;
                    _this.m_pagesPerView = info.m_pagesPerView;
                    _this.m_minimalColumnWidth = info.m_minimalColumnWidth;
                    _this.m_thresholdWidth = info.m_thresholdWidth;
                    _this._startWorkingHour = 0;
                    _this._workingHours = 24;
                    _this._milisecondsPerPage = _this.m_pageInMiliseconds;
                    _this._milisecondsPerDay = Scheduler.dayInMiliseconds;
                    _this._columnsInPage = _this.m_pageInMiliseconds / _this.m_columnInMiliseconds;
                    if (filter.hasValidWorkingHours()) {
                        var maxWorkingHour = filter.endWorkingHour;
                        var minWorkingHour = filter.startWorkingHour;
                        if (maxWorkingHour <= 0 || maxWorkingHour > 24)
                            maxWorkingHour = 24;
                        if (minWorkingHour <= 0)
                            minWorkingHour = 0;
                        if (minWorkingHour > maxWorkingHour)
                            minWorkingHour = maxWorkingHour;
                        if (_this.inMonthsMode()) {
                            _this._startWorkingHour = Math.floor(minWorkingHour);
                            _this._workingHours = Math.floor(maxWorkingHour - _this._startWorkingHour);
                            // this.m_pageInMiliseconds and this.m_columnInMiliseconds will be set properly in recalculate method later
                        }
                        else {
                            var block = _this.m_columnInMiliseconds < Scheduler.dayInMiliseconds ? 24 / _this._columnsInPage : 1;
                            maxWorkingHour = Math.ceil(maxWorkingHour / block) * block;
                            _this._startWorkingHour = Math.floor(minWorkingHour / block) * block;
                            _this._workingHours = (maxWorkingHour - _this._startWorkingHour);
                            _this._milisecondsPerDay = _this._workingHours * Scheduler.hourInMiliseconds;
                            if (_this.inHoursMode()) {
                                _this._milisecondsPerPage = _this._milisecondsPerDay;
                                _this._columnsInPage = _this._milisecondsPerPage / _this.m_columnInMiliseconds;
                            }
                            else
                                _this._milisecondsPerPage = _this._milisecondsPerDay * _this._columnsInPage;
                        }
                    }
                    _this.recalculate(filter);
                    return _this;
                }
                Zoom.prototype.getLevel = function () {
                    return this._level;
                };
                Zoom.prototype.inHoursMode = function () {
                    return this._level.charAt(0) === "h";
                };
                Zoom.prototype.inDaysMode = function () {
                    return this._level.charAt(0) === "d";
                };
                Zoom.prototype.inMonthsMode = function () {
                    return this._level.charAt(0) === "m";
                };
                Zoom.prototype.inMonthsMode6 = function () {
                    return this._level === "m6";
                };
                Zoom.prototype.showWeekendsAndHolidays = function () {
                    return this._showWeekendsAndHolidays;
                };
                Zoom.prototype.setContentWidth = function (contentWidth) {
                    this._contentWidth = contentWidth;
                    this._pixelsPerMilisecond = contentWidth / (this._milisecondsPerPage * this.m_pagesPerView); //this._visibleTimeRange.duration();
                };
                Zoom.prototype.positionToTimeSimple = function (pos) {
                    return this._visibleTimeRange.start + Math.round(pos / this._pixelsPerMilisecond);
                };
                // takes into account working hours also
                Zoom.prototype.positionToTimeForHiddenWeekends = function (pos) {
                    var timeOffset = Math.round(pos / this._pixelsPerMilisecond);
                    var dayIdx = Math.floor(timeOffset / this._milisecondsPerDay);
                    if (dayIdx < 0)
                        return this._visibleTimeRange.start - 1; // -1 because start is included in the interval
                    else if (dayIdx >= this._days.length)
                        return this._visibleTimeRange.end;
                    var hoursInMilliseconds = timeOffset - (dayIdx * this._milisecondsPerDay);
                    return this._days[dayIdx].start + hoursInMilliseconds;
                };
                Zoom.prototype.timeToPositionSimple = function (milliseconds, doNotRound) {
                    var position = -1;
                    var timeOffset = milliseconds - this._timeRange.start;
                    if (milliseconds < this._visibleTimeRange.start)
                        position = -1;
                    else if (milliseconds >= this._visibleTimeRange.end)
                        position = this._contentWidth;
                    else {
                        position = timeOffset * this._pixelsPerMilisecond;
                    }
                    return !doNotRound ? Math.round(position) : position;
                };
                Zoom.prototype.timeToPositionWithDefinedWorkHours = function (milliseconds, doNotRound) {
                    var position = -1;
                    var timeOffset = milliseconds - this._timeRange.start;
                    if (milliseconds < this._visibleTimeRange.start)
                        position = -1;
                    else if (milliseconds >= this._visibleTimeRange.end)
                        position = this._contentWidth;
                    else {
                        var dayIdx = Math.floor(timeOffset / Scheduler.dayInMiliseconds);
                        var hour = (timeOffset - dayIdx * Scheduler.dayInMiliseconds) / Scheduler.hourInMiliseconds;
                        hour -= this._startWorkingHour;
                        if (hour < 0)
                            timeOffset = dayIdx * this._milisecondsPerDay;
                        else if (hour >= this._workingHours)
                            timeOffset = ((dayIdx + 1) * this._milisecondsPerDay);
                        else
                            timeOffset = (dayIdx + (hour / this._workingHours)) * this._milisecondsPerDay;
                        position = timeOffset * this._pixelsPerMilisecond;
                    }
                    return !doNotRound ? Math.round(position) : position;
                };
                // takes into account working hours also
                Zoom.prototype.timeToPositionForHiddenWeekends = function (milliseconds, doNotRound) {
                    var position = -1;
                    var timeOffset = milliseconds - this._timeRange.start;
                    if (milliseconds < this._visibleTimeRange.start)
                        position = -1;
                    else if (milliseconds >= this._visibleTimeRange.end)
                        position = this._contentWidth;
                    else {
                        var dayIdx = Math.floor(timeOffset / Scheduler.dayInMiliseconds);
                        var hour = (timeOffset - dayIdx * Scheduler.dayInMiliseconds) / Scheduler.hourInMiliseconds;
                        dayIdx = this._days.length - 1;
                        while (dayIdx >= 0 && this._days[dayIdx].start > milliseconds)
                            dayIdx--;
                        if (dayIdx < 0)
                            position = -1;
                        else if (milliseconds >= this._days[dayIdx].end) {
                            timeOffset = ((dayIdx + 1) * this._milisecondsPerDay);
                            position = timeOffset * this._pixelsPerMilisecond;
                        }
                        else {
                            timeOffset = dayIdx * Scheduler.dayInMiliseconds + hour * Scheduler.hourInMiliseconds;
                            if (this._milisecondsPerDay < Scheduler.dayInMiliseconds) {
                                hour -= this._startWorkingHour;
                                if (hour < 0)
                                    timeOffset = dayIdx * this._milisecondsPerDay;
                                else if (hour >= this._workingHours)
                                    timeOffset = ((dayIdx + 1) * this._milisecondsPerDay);
                                else
                                    timeOffset = (dayIdx + (hour / this._workingHours)) * this._milisecondsPerDay;
                            }
                            position = timeOffset * this._pixelsPerMilisecond;
                        }
                    }
                    return !doNotRound ? Math.round(position) : position;
                };
                Zoom.prototype.timeDurationToWidth = function (duration) {
                    var sign = (duration < 0) ? -1 : 1; // 1 for positive, -1 for negative
                    duration = sign * duration;
                    if (!this.inMonthsMode()) {
                        if (this._milisecondsPerDay < Scheduler.dayInMiliseconds) {
                            var days = Math.floor(duration / Scheduler.dayInMiliseconds);
                            var hour = (duration - days * Scheduler.dayInMiliseconds) / Scheduler.hourInMiliseconds;
                            hour -= this._startWorkingHour;
                            if (hour < 0)
                                duration = days * this._milisecondsPerDay;
                            else if (hour >= this._workingHours)
                                duration = ((days + 1) * this._milisecondsPerDay) - 1;
                            else
                                duration = (days + (hour / this._workingHours)) * this._milisecondsPerDay;
                        }
                    }
                    return sign * Math.floor(duration * this._pixelsPerMilisecond);
                };
                Zoom.prototype.columnsPerPage = function () {
                    return this._columnsInPage;
                };
                Zoom.prototype.columnsPerView = function () {
                    return this.m_pagesPerView * this._columnsInPage;
                };
                Zoom.prototype.lastDisplayedHour = function () {
                    if (this.inMonthsMode())
                        return this._startWorkingHour + this._workingHours - 1;
                    return this._startWorkingHour + this._workingHours - (this._workingHours / this._columnsInPage);
                };
                Zoom.prototype.calculateColumnWidth = function (tableWidth) {
                    return tableWidth / this.columnsPerView();
                };
                Zoom.prototype.getTimeRange = function () {
                    return this._timeRange;
                };
                Zoom.prototype.getVisibleTimeRange = function () {
                    return this._visibleTimeRange;
                };
                Zoom.prototype.getStartWorkingHour = function () {
                    return this._startWorkingHour;
                };
                Zoom.prototype.getWorkingHours = function () {
                    return this._workingHours;
                };
                Zoom.prototype._getMonthWorkingDays = function (year, month) {
                    var start = new Date(year, month).valueOf();
                    var end = new Date(year, month + 1).valueOf();
                    var workingDays = 0;
                    for (var currentDay = start; currentDay < end; currentDay += Scheduler.dayInMiliseconds) {
                        var currentDayDate = new Date(currentDay);
                        if (!Scheduler.Utilities.isHoliday(currentDayDate)) {
                            workingDays++;
                        }
                    }
                    return workingDays;
                };
                Zoom.prototype.recalculate = function (filter) {
                    this._showWeekendsAndHolidays = filter.showWeekendsAndHolidays;
                    this.timeToPixelPosition = this.timeToPositionSimple;
                    this.pixelPositionToTime = this.positionToTimeSimple;
                    if (this.inMonthsMode()) {
                        var year = filter.selectedDate.getFullYear();
                        var monthsCount = this.inMonthsMode6() ? 6 : 12;
                        var firstMonth = this.inMonthsMode6() ? (filter.selectedDate.getMonth() < 6 ? 0 : 6) : 0;
                        this._months = [];
                        for (var i = firstMonth; i < (firstMonth + monthsCount); i++) {
                            var startDate = new Date(year, i);
                            var endDate = new Date(year, i + 1); // TimeRange must be from 000 to 000 next day to have exactly 1 day duration, because end time of the TimeRange is not included yet in the time interval.
                            var monthWorkingDays = this._getMonthWorkingDays(startDate.getFullYear(), startDate.getMonth());
                            var monthTimeRange = new Scheduler.TimeRange(startDate.valueOf(), endDate.valueOf());
                            this._months.push(new MonthHelper(monthWorkingDays, monthTimeRange));
                        }
                        this._visibleTimeRange = new Scheduler.TimeRange(this._months[0].timeRange.start, this._months[this._months.length - 1].timeRange.end);
                        this._timeRange = this._visibleTimeRange;
                        this.m_pageInMiliseconds = this._timeRange.duration();
                        this._milisecondsPerPage = this.m_pageInMiliseconds;
                        this._columnsInPage = monthsCount;
                        this.m_columnInMiliseconds = Math.floor(this.m_pageInMiliseconds / this._columnsInPage);
                    }
                    else {
                        var days;
                        if (this.inDaysMode()) {
                            Scheduler.Container.defaultOffice.setFirstDayOfThisWeek(filter.selectedDate);
                            days = this._showWeekendsAndHolidays ? 7 : 5;
                            this._columnsInPage = days;
                            this._milisecondsPerPage = this._milisecondsPerDay * days;
                            days *= this.m_pagesPerView;
                        }
                        else {
                            days = this.daysInView();
                        }
                        filter.selectedDate.setHours(0, 0, 0, 0);
                        if (days < 1)
                            days = 1;
                        this._days = [];
                        var date = filter.selectedDate.valueOf();
                        var startShift = this._startWorkingHour * Scheduler.hourInMiliseconds;
                        var endShift = (this._startWorkingHour + this._workingHours) * Scheduler.hourInMiliseconds;
                        while (this._days.length < days) {
                            if (this._showWeekendsAndHolidays || !Scheduler.Utilities.isWeekend((new Date(date + 12 * Scheduler.hourInMiliseconds)).getDay())) {
                                this._days.push(new Scheduler.TimeRange(date + startShift, date + endShift));
                            }
                            date += Scheduler.dayInMiliseconds;
                        }
                        if (!this._showWeekendsAndHolidays) {
                            this.timeToPixelPosition = this.timeToPositionForHiddenWeekends;
                            this.pixelPositionToTime = this.positionToTimeForHiddenWeekends;
                        }
                        else if (this._milisecondsPerDay < Scheduler.dayInMiliseconds) {
                            this.timeToPixelPosition = this.timeToPositionWithDefinedWorkHours;
                            this.pixelPositionToTime = this.positionToTimeForHiddenWeekends;
                        }
                        var len = this._days.length;
                        this._timeRange = new Scheduler.TimeRange(this._days[0].start - startShift, this._days[len - 1].end - endShift + Scheduler.dayInMiliseconds);
                        this._visibleTimeRange = new Scheduler.TimeRange(this._days[0].start, this._days[len - 1].end);
                    }
                    return this._visibleTimeRange;
                };
                Zoom.prototype.forEachPage = function (renderFunction) {
                    if (this.inHoursMode()) {
                        for (var i = 0; i < this._days.length; i++)
                            renderFunction(new Date(this._days[i].start), new Date(this._days[i].end), Scheduler.Utilities.isHoliday(new Date(this._days[i].start)));
                    }
                    else {
                        for (var date = this._timeRange.start; date < this._timeRange.end; date += this.m_pageInMiliseconds) {
                            var d = new Date(date);
                            renderFunction(d, new Date(date + this.m_pageInMiliseconds), Scheduler.Utilities.isHoliday(d));
                        }
                    }
                };
                Zoom.prototype.forEachColumn = function (renderFunction) {
                    if (this.inHoursMode()) {
                        for (var i = 0; i < this._days.length; i++) {
                            var startPage = this._days[i].start;
                            var endPage = this._days[i].end;
                            for (var col = 0; col < this._columnsInPage; col++) {
                                var startDate = new Date(startPage);
                                var endDate = new Date(endPage);
                                renderFunction(startDate, endDate, Scheduler.Utilities.isHoliday(startDate));
                                startPage += this.m_columnInMiliseconds;
                                endPage += this.m_columnInMiliseconds;
                            }
                        }
                    }
                    else if (this.inMonthsMode()) {
                        this.forEachMonth(function (startDate, endDate, workingDays) {
                            renderFunction(startDate, endDate, false);
                        });
                    }
                    else {
                        for (var i = 0; i < this._days.length; i++) {
                            var startDate = new Date(this._days[i].start);
                            var endDate = new Date(this._days[i].end);
                            renderFunction(startDate, endDate, Scheduler.Utilities.isHoliday(startDate));
                        }
                    }
                };
                Zoom.prototype.forEachMonth = function (proc) {
                    if (this.inMonthsMode()) {
                        for (var i = 0; i < this._months.length; i++) {
                            var startDate = new Date(this._months[i].timeRange.start);
                            var endDate = new Date(this._months[i].timeRange.end);
                            proc(startDate, endDate, this._months[i].workingDays);
                        }
                    }
                };
                return Zoom;
            }(ZoomLevelInfo));
            Zoom.Levels = {
                "h": new ZoomLevelInfo(Scheduler.hourInMiliseconds, Scheduler.dayInMiliseconds, 1, 20),
                "h2": new ZoomLevelInfo(Scheduler.hourInMiliseconds * 4, Scheduler.dayInMiliseconds, 2, 20),
                "h3": new ZoomLevelInfo(Scheduler.hourInMiliseconds * 6, Scheduler.dayInMiliseconds, 3, 20),
                "d": new ZoomLevelInfo(Scheduler.dayInMiliseconds, Scheduler.dayInMiliseconds * 7, 1, 20, 40),
                "d2": new ZoomLevelInfo(Scheduler.dayInMiliseconds, Scheduler.dayInMiliseconds * 7, 2, 20, 40),
                "d4": new ZoomLevelInfo(Scheduler.dayInMiliseconds, Scheduler.dayInMiliseconds * 7, 4, 20, 40),
                "d6": new ZoomLevelInfo(Scheduler.dayInMiliseconds, Scheduler.dayInMiliseconds * 7, 6, 20, 40),
                "m6": new ZoomLevelInfo(Scheduler.dayInMiliseconds * 30, (Scheduler.dayInMiliseconds * 30) * 6, 1, 70),
                "m12": new ZoomLevelInfo(Scheduler.dayInMiliseconds * 30, (Scheduler.dayInMiliseconds * 30) * 12, 1, 70),
            };
            Scheduler.Zoom = Zoom;
            var TodayLine = (function () {
                function TodayLine(view) {
                    this._color = "#FF3435";
                    this._lineStyle = "dashed";
                    this._linewidth = 2;
                    this._handleHeight = 8;
                    this._handleAroundWidth = 3;
                    this._position = view.zoom.timeToPixelPosition(view.timeNow);
                    this.handleElement = this._createTodayLineHandleElement();
                    this.lineElement = this._createTodayLineElement();
                }
                TodayLine.prototype._createTodayLineElement = function () {
                    var element = $("<div>").attr("id", "todayLine");
                    element.css({ left: this._position });
                    element.css({ "border-left-style": this._lineStyle });
                    element.css({ "border-left-width": this._linewidth });
                    element.css({ "border-left-color": this._color });
                    return element;
                };
                TodayLine.prototype._createTodayLineHandleElement = function () {
                    var element = $("<div>").attr("id", "todayLineHandle");
                    element.css({ left: this._position - this._handleAroundWidth });
                    element.css({ top: Scheduler.Container.constants.viewHeaderHeight - this._handleHeight });
                    element.css({ width: this._linewidth + (2 * this._handleAroundWidth) });
                    element.css({ height: this._handleHeight });
                    element.append(this._createSquareElement());
                    element.append(this._createArrowElement());
                    element.append(this._createArrowPointElement());
                    return element;
                };
                TodayLine.prototype._createSquareElement = function () {
                    var element = $("<div>").addClass("handleSquare");
                    element.css({ "background-color": this._color });
                    element.css({ width: this._linewidth + (2 * this._handleAroundWidth) });
                    element.css({ height: this._handleHeight - this._handleAroundWidth });
                    return element;
                };
                TodayLine.prototype._createArrowElement = function () {
                    var element = $("<div>").addClass("handleArrow");
                    var arrowHeight = (this._handleAroundWidth >= 1) ? (this._handleAroundWidth - 1) : 0;
                    element.css({ "border-top-color": this._color });
                    element.css({ width: this._linewidth + (2 * this._handleAroundWidth) });
                    element.css({ height: arrowHeight });
                    element.css({ "border-width": this._handleAroundWidth });
                    element.css({ "border-top-width": arrowHeight });
                    element.css({ "border-bottom-width": 0 });
                    return element;
                };
                TodayLine.prototype._createArrowPointElement = function () {
                    var element = $("<div>").addClass("handleArrowPoint");
                    element.css({ "background-color": this._color });
                    element.css({ left: this._handleAroundWidth });
                    element.css({ width: this._linewidth });
                    return element;
                };
                return TodayLine;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
