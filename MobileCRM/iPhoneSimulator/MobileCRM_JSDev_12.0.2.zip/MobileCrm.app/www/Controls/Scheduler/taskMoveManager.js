///<reference path="../../Controls/popupMenu.ts"/>
///<reference path="../../Controls/gestureManager.ts"/>
///<reference path="gridview.ts" />
///<reference path="utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var VScrollDirection;
            (function (VScrollDirection) {
                VScrollDirection[VScrollDirection["None"] = 0] = "None";
                VScrollDirection[VScrollDirection["Up"] = 1] = "Up";
                VScrollDirection[VScrollDirection["Down"] = 2] = "Down";
            })(VScrollDirection || (VScrollDirection = {}));
            var DragDropActions;
            (function (DragDropActions) {
                DragDropActions[DragDropActions["None"] = 0] = "None";
                DragDropActions[DragDropActions["IsProcessing"] = 1] = "IsProcessing";
                DragDropActions[DragDropActions["WasProcessed"] = 2] = "WasProcessed";
                DragDropActions[DragDropActions["WasLeaved"] = 4] = "WasLeaved";
                DragDropActions[DragDropActions["DragRecognized"] = 8] = "DragRecognized";
            })(DragDropActions = Scheduler.DragDropActions || (Scheduler.DragDropActions = {}));
            /**
             * Class that manages and handles drag and drop moving gesture.
             */
            var DragDropManager = (function () {
                function DragDropManager(containerElement) {
                    var _this = this;
                    this.downManagement = function (ge) {
                        if (_this.hasStateFlags(DragDropActions.IsProcessing)) {
                            ge.cancelDown = true;
                            return;
                        }
                        var e = ge.jQueryEventObject;
                        _this._eventArgs = e;
                        _this._setStateFlags(DragDropActions.WasProcessed | DragDropActions.WasLeaved | DragDropActions.DragRecognized, false);
                        _this._setStateFlags(DragDropActions.IsProcessing, true);
                        _this._containerElementOffset = _this._containerElement.offset();
                        _this._originalPointX = ge.pageX - _this._containerElementOffset.left;
                        _this._originalPointY = ge.pageY - _this._containerElementOffset.top;
                        _this._oldPointX = _this._originalPointX;
                        _this._oldPointY = _this._originalPointY;
                        _this.onStart.raise({ x: _this._originalPointX, y: _this._originalPointY });
                        var target = e.target;
                        if (!$.contains(document.body, target))
                            _this._cacheTargetElement(target);
                    };
                    this.moveManagement = function (ge) {
                        if (!_this.hasStateFlags(DragDropActions.IsProcessing))
                            return;
                        var e = ge.jQueryEventObject;
                        _this._eventArgs = e;
                        // manage moving
                        var pointX = ge.pageX - _this._containerElementOffset.left;
                        var pointY = ge.pageY - _this._containerElementOffset.top;
                        var originalDeltaPointX = pointX - _this._originalPointX;
                        var originalDeltaPointY = pointY - _this._originalPointY;
                        var deltaPointX = pointX - _this._oldPointX;
                        var deltaPointY = pointY - _this._oldPointY;
                        _this._oldPointX = pointX;
                        _this._oldPointY = pointY;
                        if (!_this.hasStateFlags(DragDropActions.DragRecognized)) {
                            var canStartDragArgs = { odx: originalDeltaPointX, ody: originalDeltaPointY, canStartDrag: true };
                            _this.onCanStartDrag.raise(canStartDragArgs);
                            if (canStartDragArgs.canStartDrag) {
                                _this._setStateFlags(DragDropActions.DragRecognized, true);
                                _this.onDragStart.raise({ x: pointX, y: pointY });
                            }
                        }
                        if (_this.hasStateFlags(DragDropActions.DragRecognized)) {
                            _this.onDragMove.raise({ x: pointX, y: pointY, dx: deltaPointX, dy: deltaPointY });
                        }
                        _this.onMove.raise({ x: pointX, y: pointY });
                        var target = e.target;
                        if (!$.contains(document.body, target))
                            _this._cacheTargetElement(target);
                    };
                    this.upManagement = function (ge) {
                        if (!_this.hasStateFlags(DragDropActions.IsProcessing))
                            return;
                        _this._eventArgs = ge.jQueryEventObject;
                        var pointX = ge.pageX - _this._containerElementOffset.left;
                        var pointY = ge.pageY - _this._containerElementOffset.top;
                        _this._setStateFlags(DragDropActions.IsProcessing, false); // necessary for proper event order execution on devices
                        _this._setStateFlags(DragDropActions.WasProcessed, true);
                        if (_this.hasStateFlags(DragDropActions.DragRecognized)) {
                            _this.onDrop.raise({ x: pointX, y: pointY });
                        }
                        else {
                            _this.onEndWithoutDragDrop.raise({ x: pointX, y: pointY });
                        }
                        _this.onEnd.raise({ x: pointX, y: pointY });
                        if (_this._cachedTarget) {
                            _this._cachedTarget.remove();
                            _this._cachedTarget = undefined;
                            _this._eventArgs = undefined;
                        }
                    };
                    this.cancelManagement = function (ge) {
                        if (!_this.hasStateFlags(DragDropActions.IsProcessing))
                            return;
                        _this._eventArgs = ge.jQueryEventObject;
                        _this._setStateFlags(DragDropActions.WasLeaved, true);
                        _this.upManagement(ge);
                    };
                    this._stateFlags = DragDropActions.None;
                    this._containerElement = containerElement;
                    this.onStateFlagsChanged = new Resco.Event(this);
                    this.onStart = new Resco.Event(this);
                    this.onCanStartDrag = new Resco.Event(this);
                    this.onDragStart = new Resco.Event(this);
                    this.onDragMove = new Resco.Event(this);
                    this.onMove = new Resco.Event(this);
                    this.onDrop = new Resco.Event(this);
                    this.onEndWithoutDragDrop = new Resco.Event(this);
                    this.onEnd = new Resco.Event(this);
                }
                DragDropManager.prototype._setStateFlags = function (flags, addFlag) {
                    if (addFlag) {
                        if (flags === DragDropActions.None) {
                            this._stateFlags = DragDropActions.None;
                        }
                        else {
                            this._stateFlags |= flags;
                        }
                    }
                    else {
                        this._stateFlags &= ~flags;
                    }
                    this.onStateFlagsChanged.raise(this._stateFlags);
                };
                DragDropManager.prototype.hasStateFlags = function (flags) {
                    return (this._stateFlags & flags) !== DragDropActions.None;
                };
                /**
                 * Force manager to cache (append back) target element in DOM tree until gesture ends, to keep events raising as expected on devices also.
                 */
                DragDropManager.prototype.onTargetElementWasRemoved = function () {
                    if (this._eventArgs && this._eventArgs.target) {
                        var target = this._eventArgs.target;
                        if (!$.contains(document.body, target))
                            this._cacheTargetElement(target);
                    }
                };
                /**
                 * Append event target element back to DOM tree to keep touch events raising (on parent element also) even after event target element was removed.
                 * @param element - event target element
                 */
                DragDropManager.prototype._cacheTargetElement = function (element) {
                    this._cachedTarget = $(element);
                    this._cachedTarget.css({ display: "none" });
                    $("body").append(this._cachedTarget);
                };
                return DragDropManager;
            }());
            Scheduler.DragDropManager = DragDropManager;
            /**
             * Class that manages and handles user's task moving.
             */
            var TaskMoveManager = (function () {
                /**
                 * Constructor of the TaskMoveManager
                 */
                function TaskMoveManager(container, draggableContainerElement) {
                    var _this = this;
                    this._gestureManager = new Controls.GestureManager();
                    this._taskMoveData = new TaskMoveData(null, null, null, null);
                    this._autoScrollVTimerHandle = null;
                    this._autoScrollVRunningDirection = VScrollDirection.None;
                    this._asVScrollFrequency = 20; // times/second [Hz]
                    this._asDeltaY = 0;
                    this._asScrollTop = 0;
                    this._asMaxScrollTop = 0;
                    this.downManagement = function (ge, item) {
                        _this._item = item;
                        _this._dragDropManager.downManagement(ge);
                    };
                    this.moveManagement = function (ge) {
                        _this._dragDropManager.moveManagement(ge);
                    };
                    this.upManagement = function (ge) {
                        _this._dragDropManager.upManagement(ge);
                    };
                    this.cancelManagement = function (ge) {
                        _this._dragDropManager.cancelManagement(ge);
                    };
                    this._scrollToBottom = function () {
                        _this._asScrollTop += _this._asDeltaY;
                        if (_this._asScrollTop > _this._asMaxScrollTop) {
                            _this._asScrollTop = _this._asMaxScrollTop;
                            _this._stopAutoScrollVTimer();
                        }
                        _this._container.viewCtrl.vScroll.setScrollPos(_this._asScrollTop);
                        // trigger onMove
                        _this._taskMoveData = _this._getTaskMoveData(_this._taskMoveData.workStartXPosition, _this._taskMoveData.taskBoxYPosition);
                        _this._task.onDragMove(_this._taskMoveData.resource, _this._taskMoveData.workStart);
                    };
                    this._scrollToTop = function () {
                        _this._asScrollTop -= _this._asDeltaY;
                        if (_this._asScrollTop < 0) {
                            _this._asScrollTop = 0;
                            _this._stopAutoScrollVTimer();
                        }
                        _this._container.viewCtrl.vScroll.setScrollPos(_this._asScrollTop);
                        // trigger onMove
                        _this._taskMoveData = _this._getTaskMoveData(_this._taskMoveData.workStartXPosition, _this._taskMoveData.taskBoxYPosition);
                        _this._task.onDragMove(_this._taskMoveData.resource, _this._taskMoveData.workStart);
                    };
                    this._constants = Scheduler.Container.constants;
                    this._stateFlags = DragDropActions.None;
                    this._container = container;
                    this._dragDropManager = new DragDropManager(draggableContainerElement);
                    this._dragDropManager.onStateFlagsChanged.add(this, this._stateFlagsChangedManagement);
                    this._dragDropManager.onStart.add(this, this._startManagement);
                    this._dragDropManager.onCanStartDrag.add(this, this._canStartDragManagement);
                    this._dragDropManager.onDragStart.add(this, this._dragStartManagement);
                    this._dragDropManager.onDragMove.add(this, this._dragMoveManagement);
                    //this._dragDropManager.onMove.add(this, this._moveManagement);
                    this._dragDropManager.onDrop.add(this, this._dropManagement);
                    //this._dragDropManager.onEndWithoutDragDrop.add(this, this._endWithoutDragDropManagement);
                    //this._dragDropManager.onEnd.add(this, this._endManagement);
                    this._asDeltaY = Math.round(this._constants.viewVScrollSpeed / this._asVScrollFrequency);
                }
                TaskMoveManager.prototype.hasStateFlags = function (flags) {
                    return (this._stateFlags & flags) !== DragDropActions.None;
                };
                TaskMoveManager.prototype.resetStateFlags = function () {
                    if (!this._dragDropManager.hasStateFlags(DragDropActions.IsProcessing)) {
                        this._stateFlags = DragDropActions.None;
                    }
                };
                Object.defineProperty(TaskMoveManager.prototype, "gestureManager", {
                    get: function () {
                        return this._gestureManager;
                    },
                    enumerable: true,
                    configurable: true
                });
                /**
                 * Force manager to cache (append back) target element in DOM tree until gesture ends, to keep events raising as expected on devices also.
                 */
                TaskMoveManager.prototype.onTargetElementWasRemoved = function () {
                    this._dragDropManager.onTargetElementWasRemoved();
                };
                /**
                 * Remove event handlers that handles move action.
                 */
                TaskMoveManager.prototype.unbindFromFocusedTask = function () {
                    this.resetStateFlags();
                    var focusedTask = this._container.draggableContainer.focusedTask;
                    if (focusedTask) {
                        if (focusedTask.ganttElement) {
                            this.gestureManager.offDownMoveUpCancel(focusedTask.ganttElement, this.downManagement, this.moveManagement, this.upManagement, this.cancelManagement);
                        }
                    }
                };
                /**
                 * Add event handlers that handles move action that consist from down/start, move and up/end events.
                 * @param task: Task to which will be move action event handlers added.
                 */
                TaskMoveManager.prototype.bindToFocusedTask = function () {
                    var focusedTask = this._container.draggableContainer.focusedTask;
                    if (focusedTask) {
                        if (focusedTask.ganttElement) {
                            this.gestureManager.onDownMoveUpCancel(focusedTask.ganttElement, this.downManagement, this.moveManagement, this.upManagement, this.cancelManagement);
                        }
                    }
                };
                TaskMoveManager.prototype._resetAllPrivateFields = function () {
                    this._task = undefined;
                    this._originalPointX = undefined;
                    this._originalPointY = undefined;
                    this._originalTaskBoxX = undefined;
                    this._originalTaskBoxY = undefined;
                    this._originalTaskDeltaPointX = undefined;
                    this._originalTaskDeltaPointY = undefined;
                    this._taskMoveData.reset();
                    this._autoScrollVTimerHandle = null;
                    this._autoScrollVRunningDirection = VScrollDirection.None;
                };
                TaskMoveManager.prototype._stateFlagsChangedManagement = function (sender, e) {
                    this._stateFlags = e;
                };
                TaskMoveManager.prototype._startManagement = function (sender, e) {
                    this._resetAllPrivateFields();
                    this._originalPointX = e.x;
                    this._originalPointY = e.y;
                    //this._stopAutoScrollHTimer();
                    this._stopAutoScrollVTimer();
                };
                TaskMoveManager.prototype._canStartDragManagement = function (sender, e) {
                    e.canStartDrag = !this._container.loadingInProcess && !this._container.viewCtrl.taskPopupMenu.isOpened && ((Math.abs(e.odx) > this._constants.viewTaskMinMoveDistance) || (Math.abs(e.ody) > this._constants.viewTaskMinMoveDistance));
                };
                TaskMoveManager.prototype._dragStartManagement = function (sender, e) {
                    if (this._item)
                        this._container.onHorizontalListItemDragStart(e, this._item);
                    this._task = this._container.draggableContainer.focusedTask;
                    if (this._task) {
                        var originalTaskBoxPosition = this._task.ganttElement.position();
                        this._originalTaskBoxX = originalTaskBoxPosition.left;
                        this._originalTaskBoxY = originalTaskBoxPosition.top;
                        if (this._task.containerView === Scheduler.TaskContainerView.IsInUndefinedTasksContainer) {
                            this._task.appendTaskBoxFromUTCToDC();
                        }
                        else if (this._task.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                            this._task.appendTaskBoxFromTCToDC();
                        }
                        // Compute relative distance in x and y coordinates between task box element position and real position of the mouse/touch point.
                        var taskBoxPosition = this._task.ganttElement.position();
                        this._originalTaskDeltaPointX = this._originalPointX - (taskBoxPosition.left + this._task.getWorkStartXPosition());
                        this._originalTaskDeltaPointY = this._originalPointY - taskBoxPosition.top;
                        // trigger onMoveStart
                        this._taskMoveData = this._getTaskMoveData(e.x - this._originalTaskDeltaPointX, e.y - this._originalTaskDeltaPointY);
                        this._task.onDragStart(this._taskMoveData.resource, this._taskMoveData.workStart);
                    }
                };
                TaskMoveManager.prototype._dragMoveManagement = function (sender, e) {
                    if (this._task) {
                        if (this._task.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                            var workStartXPosition = e.x - this._originalTaskDeltaPointX;
                            var taskBoxYPosition = e.y - this._originalTaskDeltaPointY;
                            this._taskMoveData = this._getTaskMoveData(workStartXPosition, taskBoxYPosition);
                            var taskBoxDimensions = this._task.getTaskBoxDimensions(this._taskMoveData.workStart);
                            if (taskBoxDimensions) {
                                this._task.ganttElement.css({ left: workStartXPosition - taskBoxDimensions.travelToWidth, top: taskBoxYPosition });
                                // trigger onMove
                                this._task.onDragMove(this._taskMoveData.resource, this._taskMoveData.workStart);
                                //this._autoScrollHorizontally(deltaPointX);
                                this._autoScrollVertically(e.dy);
                            }
                        }
                    }
                };
                TaskMoveManager.prototype._dropManagement = function (sender, e) {
                    if (this._task) {
                        //this._stopAutoScrollHTimer();
                        this._stopAutoScrollVTimer();
                        if (this._task.containerView === Scheduler.TaskContainerView.IsInDraggableContainer) {
                            this._task.appendTaskBoxFromDCToTC();
                            // trigger onDrop
                            var taskBoxPosition = this._task.ganttElement.position();
                            this._taskMoveData = this._getTaskMoveData(taskBoxPosition.left + this._task.getWorkStartXPosition(), taskBoxPosition.top);
                            // !!!Method _onDropFinished is cached (with all its arguments) as local variable of the task.onDrop() method, until it is called (even from nested async method) and task.onDrop() method really ends and release own local variables!!!
                            this._task.onDrop(this._taskMoveData.resource, this._taskMoveData.workStart, this._onDropFinished.bind(this, this._task, this._originalTaskBoxX, this._originalTaskBoxY)); // It is necessary to call onDrop every time when task was moved, to guarantee that undefined taskBox div will be appended back to proper element, if it was not reassigned!
                        }
                    }
                };
                /**
                 * Returns task to it's original position that it had before user moved the task, if success argument is set to false.
                 * This method is cached (with all its arguments) as local variable of the task.onDrop() method,
                 * until it is called (even from nested async method) and task.onDrop() method really ends and release own local variables.
                 */
                TaskMoveManager.prototype._onDropFinished = function (task, originalTaskBoxX, originalTaskBoxY, success) {
                    if (!success) {
                        if (task.containerView === Scheduler.TaskContainerView.IsInDraggableContainer)
                            task.appendTaskBoxFromDCToTC();
                        if (task.getStatus().isUnscheduled() && !task.isUnscheduledNew())
                            task.appendTaskBoxFromDCOrTCToUTC();
                        if (task.ganttElement)
                            task.ganttElement.css({ left: originalTaskBoxX, top: originalTaskBoxY });
                        // trigger onMoveRevert
                        task.onMoveRevert();
                    }
                    else {
                        // trigger onMoveSuccessful
                        task.onMoveSuccessful();
                    }
                };
                TaskMoveManager.prototype._getTaskMoveData = function (workStartXPosition, taskBoxYPosition) {
                    var rowResource = null;
                    var workStartTime = null;
                    if (this._task) {
                        if (((workStartXPosition !== undefined) && (workStartXPosition !== null)) && ((taskBoxYPosition !== undefined) && (taskBoxYPosition !== null))) {
                            if (!this._dragDropManager.hasStateFlags(DragDropActions.WasLeaved)) {
                                var height = this._task.ganttElement.height();
                                var xPositionInDraggableContainer = workStartXPosition;
                                var yPositionInDraggableContainer = taskBoxYPosition + Math.round((height ? height : 0) / 2);
                                var draggableContainer = this._container.draggableContainer.element;
                                var delta = Scheduler.Utilities.getContainersOffsetDelta(this._container.viewCtrl.viewBody.tasksContainerElement, draggableContainer);
                                if (this._task.containerView === Scheduler.TaskContainerView.IsInTasksContainer) {
                                    xPositionInDraggableContainer += delta.x;
                                    yPositionInDraggableContainer += delta.y;
                                }
                                // tasks scrollable view edges
                                var leftEdge = 0;
                                var rightEdge = draggableContainer.width();
                                var topEdge = Scheduler.Utilities.getContainersOffsetDelta(this._container.viewCtrl.viewBody.element, draggableContainer).y;
                                var bottomEdge = draggableContainer.height();
                                if ((leftEdge <= xPositionInDraggableContainer) && (xPositionInDraggableContainer < rightEdge)) {
                                    var xPositionInTasksContainer = (xPositionInDraggableContainer - delta.x);
                                    workStartTime = this._container.viewCtrl.zoom.pixelPositionToTime(xPositionInTasksContainer);
                                    if (!this._container.viewCtrl.zoom.getVisibleTimeRange().timeIsInside(workStartTime))
                                        workStartTime = null;
                                }
                                if ((topEdge <= yPositionInDraggableContainer) && (yPositionInDraggableContainer < bottomEdge)) {
                                    var yPositionInTasksContainer = (yPositionInDraggableContainer - delta.y);
                                    rowResource = this._container.getResourceByRowIndex(this._container.position2RowIndex(yPositionInTasksContainer));
                                }
                            }
                        }
                    }
                    return new TaskMoveData(workStartXPosition, taskBoxYPosition, workStartTime, rowResource);
                };
                // auto scrolling
                /*
                private _autoScrollHorizontally(): void {
                    let taskBox = this._task.ganttElement;
                    var scrollWidth = this._container.viewCtrl.m_hScroll.getPageSize();
                    var taskBoxWidth = parseFloat(taskBox.attr("width"));
                    var scrollLeftEdge = this._container.viewCtrl.m_hScroll.getScrollPos();
                    var scrollRightEdge = scrollLeftEdge + scrollWidth;
                    var taskBoxLeftEdge;
        
                    var delta = Utilities.getContainersOffsetDelta(this._container.viewCtrl.viewBody.tasksContainerElement, this._container.draggableContainer.element);
                    taskBoxLeftEdge = parseFloat(taskBox.attr("x")) - delta.x;
        
                    var taskBoxRightEdge = taskBoxLeftEdge + taskBoxWidth;
                    var distanceFromLeftEdge = taskBoxLeftEdge - scrollLeftEdge;
                    var distanceFromRightEdge = scrollRightEdge - taskBoxRightEdge;
                    var exceedLeft = distanceFromLeftEdge < this._constants.ganttAutoHScrollMinEdgeSpace;
                    var exceedRight = distanceFromRightEdge < this._constants.ganttAutoHScrollMinEdgeSpace;
                    var taskBoxTooWide = (taskBoxWidth + 2 * this._constants.ganttAutoHScrollMinEdgeSpace) > scrollWidth;
        
                    if (this._autoScrollHRunningDirection === 0 && (distanceFromLeftEdge < 0) && (distanceFromRightEdge < 0)) {
                        // if start and end edge of the task is not visible in the view do not start scrolling automatically.
                    } else {
                        if (this._taskMoveHDirection > 0) {
                            if ((this._autoScrollHRunningDirection < 0) && !exceedLeft) {
                                this._stopAutoScrollHTimer();
                            } else if (exceedRight && (!taskBoxTooWide || (distanceFromRightEdge > 0))) {
                                this._startAutoScrollHTimer(true);
                            }
                        } else if (this._taskMoveHDirection < 0) {
                            if ((this._autoScrollHRunningDirection > 0) && !exceedRight) {
                                this._stopAutoScrollHTimer();
                            } else if (exceedLeft && (!taskBoxTooWide || (distanceFromLeftEdge > 0))) {
                                this._startAutoScrollHTimer(false);
                            }
                        }
                    }
                }
        
                private _autoScrollHTimerHandle: number = null;
        
                private _startAutoScrollHTimer(scrollRight): void {
                    function _scrollToRight() {
                        var scrollLeft = this._container.viewCtrl.m_hScroll.getScrollPos();
                        var newScrollLeft = scrollLeft + deltaX;
                        if (newScrollLeft > maxScrollLeftValue) {
                            newScrollLeft = maxScrollLeftValue;
                            deltaX = newScrollLeft - scrollLeft; // to keep task box on the same position like it is scrolled
                            this._stopAutoScrollHTimer();
                        }
        
                        this._container.viewCtrl.m_hScroll.setScrollPos(newScrollLeft);
        
                        // trigger onMove
                        this._taskMoveData = this._getTaskMoveData(this._taskMoveData.workStartXPosition, this._taskMoveData.taskBoxYPosition);
                        taskLocal.onMove(owningResource);
                    }
        
                    function _scrollToLeft() {
                        var scrollLeft = this._container.viewCtrl.m_hScroll.getScrollPos();
                        var newScrollLeft = scrollLeft - deltaX;
                        if (newScrollLeft < 0) {
                            newScrollLeft = 0;
                            deltaX = scrollLeft - newScrollLeft; // to keep task box on the same position like it is scrolled
                            this._stopAutoScrollHTimer();
                        }
        
                        this._container.viewCtrl.m_hScroll.setScrollPos(newScrollLeft);
        
                        // trigger onMove
                        this._taskMoveData = this._getTaskMoveData(this._taskMoveData.workStartXPosition, this._taskMoveData.taskBoxYPosition);
                        taskLocal.onMove(owningResource);
                    }
        
                    if (this._autoScrollHRunningDirection === 0) {
                        var scrollHFrequency = 50; // times/second [Hz]
                        var scrollTimeInterval = Math.round(1000 / scrollHFrequency);
                        var taskLocal = this._task;
                        var deltaX = Math.round(this._constants.ganttAutoHScrollSpeed / scrollHFrequency);
                        var maxScrollLeftValue = this._container.viewCtrl.m_hScroll.getMaxScrollPos();
                        var owningResource = this._getRowResource();
        
                        if (scrollRight === true) {
                            this._autoScrollHRunningDirection = 1;
                            this._autoScrollHTimerHandle = setInterval(_scrollToRight.bind(this), scrollTimeInterval);
                        } else {
                            this._autoScrollHRunningDirection = -1;
                            this._autoScrollHTimerHandle = setInterval(_scrollToLeft.bind(this), scrollTimeInterval);
                        }
                    }
                }
        
                private _stopAutoScrollHTimer(): void {
                    if (this._autoScrollHTimerHandle) {
                        clearInterval(this._autoScrollHTimerHandle);
                    }
        
                    this._autoScrollHTimerHandle = null;
                    this._autoScrollHRunningDirection = 0;
                }*/
                TaskMoveManager.prototype._autoScrollVertically = function (deltaPointY) {
                    var delta = Scheduler.Utilities.getContainersOffsetDelta(this._container.viewCtrl.viewBody.tasksContainerElement, this._container.draggableContainer.element);
                    var taskBox = this._task.ganttElement;
                    var taskBoxTopEdge = taskBox.position().top - delta.y;
                    var taskBoxBottomEdge = taskBoxTopEdge + taskBox.height();
                    var scrollTopEdge = this._container.viewCtrl.vScroll.getScrollPos();
                    var scrollBottomEdge = scrollTopEdge + this._container.viewCtrl.vScroll.getPageSize();
                    var distanceFromTopEdge = taskBoxTopEdge - scrollTopEdge;
                    var distanceFromBottomEdge = scrollBottomEdge - taskBoxBottomEdge;
                    var exceedTop = distanceFromTopEdge < this._constants.viewVScrollMinEdgeSpace;
                    var exceedBottom = distanceFromBottomEdge < this._constants.viewVScrollMinEdgeSpace;
                    if ((this._autoScrollVRunningDirection === VScrollDirection.None) && (distanceFromTopEdge < 0) && (distanceFromBottomEdge < 0)) {
                        // if top and bottom edge of the task is not visible in the view do not start scrolling automatically.
                    }
                    else {
                        if (deltaPointY > 0) {
                            if ((this._autoScrollVRunningDirection === VScrollDirection.Up) && !exceedTop) {
                                this._stopAutoScrollVTimer();
                            }
                            if (exceedBottom && (distanceFromBottomEdge > 0)) {
                                this._startAutoScrollVTimer(true);
                            }
                        }
                        else if (deltaPointY < 0) {
                            if ((this._autoScrollVRunningDirection === VScrollDirection.Down) && !exceedBottom) {
                                this._stopAutoScrollVTimer();
                            }
                            if (exceedTop && (distanceFromTopEdge > 0)) {
                                this._startAutoScrollVTimer(false);
                            }
                        }
                    }
                };
                TaskMoveManager.prototype._startAutoScrollVTimer = function (scrollDown) {
                    if (this._autoScrollVRunningDirection === VScrollDirection.None) {
                        var scrollTimeInterval = Math.round(1000 / this._asVScrollFrequency);
                        this._asScrollTop = this._container.viewCtrl.vScroll.getScrollPos();
                        this._asMaxScrollTop = this._container.viewCtrl.vScroll.getMaxScrollPos();
                        if (scrollDown === true) {
                            this._autoScrollVRunningDirection = VScrollDirection.Down;
                            this._autoScrollVTimerHandle = setInterval(this._scrollToBottom, scrollTimeInterval);
                        }
                        else {
                            this._autoScrollVRunningDirection = VScrollDirection.Up;
                            this._autoScrollVTimerHandle = setInterval(this._scrollToTop, scrollTimeInterval);
                        }
                    }
                };
                TaskMoveManager.prototype._stopAutoScrollVTimer = function () {
                    if (this._autoScrollVTimerHandle) {
                        clearInterval(this._autoScrollVTimerHandle);
                    }
                    this._autoScrollVTimerHandle = null;
                    this._autoScrollVRunningDirection = VScrollDirection.None;
                };
                return TaskMoveManager;
            }());
            Scheduler.TaskMoveManager = TaskMoveManager;
            var TaskMoveData = (function () {
                function TaskMoveData(workStartXPosition, taskBoxYPosition, workStart, resource) {
                    this.workStartXPosition = workStartXPosition;
                    this.taskBoxYPosition = taskBoxYPosition;
                    this.workStart = workStart;
                    this.resource = resource;
                }
                TaskMoveData.prototype.reset = function () {
                    this.workStart = null;
                    this.resource = null;
                };
                return TaskMoveData;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
