///<reference path="interfaces.ts" />
///<reference path="libs\es6-shim.d.ts"/>
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t;
    return { next: verb(0), "throw": verb(1), "return": verb(2) };
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            Scheduler.LocationCache = new Scheduler.Dictionary();
            // Class covers location data
            var Location = (function () {
                function Location(address, latitude, longitude) {
                    this.isOffice = false;
                    this._address = address;
                    this._longitude = longitude;
                    this._latitude = latitude;
                }
                Location.isValid = function (l) {
                    return l && ((l._longitude !== undefined && l._latitude !== undefined) || l._address !== undefined);
                };
                Location.prototype.hasGPS = function () {
                    return this._longitude !== undefined && this._latitude !== undefined;
                };
                Location.prototype.setLocation = function (latitude, longitude) {
                    this._longitude = longitude;
                    this._latitude = latitude;
                    this._URI = undefined;
                };
                Location.prototype.address = function (val) {
                    if (val)
                        this._address = val;
                    return this._address;
                };
                Location.prototype.toString = function () {
                    return this._address && this._address !== "" ? this._address : this._latitude + "," + this._longitude;
                };
                Location.prototype.getAsEncodeURI = function () {
                    if (!this._URI) {
                        if (this.hasGPS())
                            return this._URI = this._latitude + "," + this._longitude;
                        else if (this._address)
                            return this._URI = encodeURIComponent(this._address);
                    }
                    return this._URI;
                };
                Location.prototype.calculateDistance = function (dst) {
                    if (!dst || (dst._latitude === undefined) || (dst._longitude === undefined))
                        return 0;
                    if ((this._latitude === undefined) || (this._longitude === undefined))
                        return 0;
                    if (dst._latitude === this._latitude && dst._longitude === this._longitude)
                        return 0.0001; // the same place
                    var latRad1 = this._latitude * Location.deg2rad;
                    var longRad1 = this._longitude * Location.deg2rad;
                    var latRad2 = dst._latitude * Location.deg2rad;
                    var longRad2 = dst._longitude * Location.deg2rad;
                    var diffLongRad = longRad2 - longRad1;
                    var diffLatRad = latRad2 - latRad1;
                    var a = Math.pow(Math.sin(diffLatRad / 2.0), 2.0) + ((Math.cos(latRad1) * Math.cos(latRad2)) * Math.pow(Math.sin(diffLongRad / 2.0), 2.0));
                    var c = 2.0 * Math.atan2(Math.sqrt(a), Math.sqrt(1.0 - a));
                    return Location.avg_earth_radius * c;
                };
                return Location;
            }());
            Location.deg2rad = Math.PI / 180.0;
            Location.avg_earth_radius = 6376.5; // 6378100; // True radius varies from 6356752.3m (polar) to 6378137m (equatorial).
            Scheduler.Location = Location;
            var Route = (function () {
                function Route() {
                }
                return Route;
            }());
            Scheduler.Route = Route;
            // Class gets/calculates distance between locations and provides optimal route get/calculation
            var Geo = (function () {
                function Geo() {
                    this.items = {};
                }
                Geo.prototype.initialize = function (origin, apiKey) {
                    Google.MapRequest.initApiKey(apiKey);
                    Geo.defaultOrigin = origin;
                    Geo.defaultOrigin.isOffice = true;
                };
                /// Find optimal route from Office -> waypoints[0] ->...->waypoints[n] -> Office
                Geo.prototype.findOptimalRoute = function (onFinishCallback, waypoints, origin, destination, doNotOptimize) {
                    var _this = this;
                    var self = this;
                    var adr;
                    var addresses = [];
                    var route = new Route();
                    var defaultOrigin = Geo.defaultOrigin;
                    var office;
                    // there is no office address
                    if (!defaultOrigin || !(office = defaultOrigin.getAsEncodeURI())) {
                        onFinishCallback(undefined);
                        return;
                    }
                    // Route object initialization 
                    route.origin = origin ? origin : defaultOrigin;
                    route.destination = destination ? destination : defaultOrigin;
                    route.waypoints = [];
                    route.waypoint_order = [];
                    for (var i = 0; i < waypoints.length; i++) {
                        if ((adr = waypoints[i].getAsEncodeURI()) && adr != office) {
                            route.waypoints.push(waypoints[i]);
                            addresses.push(adr);
                        }
                    }
                    // situation: origin == destination and waypoints=1 (try to get from cache)
                    if (waypoints.length == 1 && route.origin == route.destination) {
                        var duration = this.getDurationFromCache(route.origin, route.destination);
                        if (duration != 0) {
                            route.durations.push(duration);
                            route.durations.push(duration);
                            route.waypoint_order = [0];
                            onFinishCallback(route);
                            return;
                        }
                    }
                    // route request
                    Google.MapRequest.requestJSBridge(function (geo, error) {
                        if (Google.Geo.isValid(geo)) {
                            var resultRoute = geo.routes[0];
                            var resultLegs = resultRoute.legs;
                            var d;
                            var i = 0;
                            route.durations = [];
                            if (route.waypoints.length > 0 && resultLegs.length == route.waypoints.length + 1) {
                                d = new Distance(route.origin, route.waypoints[0], resultLegs[0]);
                                route.durations.push(d.duration());
                                _this.addToCache(d);
                                for (i = 1; i < route.waypoints.length; i++) {
                                    d = new Distance(route.waypoints[i - 1], route.waypoints[i], resultLegs[i]);
                                    route.durations.push(d.duration());
                                    _this.addToCache(d);
                                }
                                d = new Distance(route.waypoints[i - 1], route.destination, resultLegs[i]);
                                route.durations.push(d.duration());
                                _this.addToCache(d);
                            }
                            else if (resultLegs.length > 0) {
                                d = new Distance(route.origin, route.destination, resultLegs[0]);
                                route.durations.push(d.duration());
                                _this.addToCache(d);
                            }
                            route.waypoint_order = resultRoute.waypoint_order;
                            onFinishCallback(route);
                            return;
                        }
                        else {
                            // try to calculate optimal way
                            onFinishCallback(undefined);
                            //var timeMatrix = self.prepareMatrix(route);
                            //self.calculateDistanceMatrix(onFinishCallback, 0, 0, waypoints, timeMatrix);
                            return;
                        }
                    }, office, office, addresses, doNotOptimize);
                };
                //public durationsFromOffice(onFinishCallback: (durationsInMilliseconds: number[]) => void, waypoints: Location[]) {
                //	var ret = this.asyncDurationsFromOffice(waypoints);
                //}
                Geo.prototype.calculateTravelDurationsFromOffice = function (onFinishCallback, waypoints) {
                    var defaultOrigin = Geo.defaultOrigin;
                    if (!Location.isValid(defaultOrigin)) {
                        onFinishCallback(undefined);
                        return undefined;
                    }
                    var promise = new Array(waypoints.length);
                    for (var i = 0; i < waypoints.length; i++)
                        promise[i] = this.calculateTravelDuration(defaultOrigin, waypoints[i]);
                    Promise.all(promise).then(function (results) {
                        onFinishCallback(results);
                    });
                };
                Geo.prototype.calculateTravelDuration = function (office, destination) {
                    return __awaiter(this, void 0, void 0, function () {
                        var duration, distance;
                        return __generator(this, function (_a) {
                            duration = undefined;
                            if (!office || !destination)
                                return [2 /*return*/, 0]; //new Promise<number>((resolve, reject) => { resolve(0); });
                            else if (office === destination)
                                return [2 /*return*/, 1]; //new Promise<number>((resolve, reject) => { resolve(1); });
                            else if ((duration = this.getDurationFromCache(office, destination)) && duration != 0)
                                return [2 /*return*/, duration]; //new Promise<number>((resolve, reject) => { resolve(duration); });
                            else {
                                distance = new Distance(office, destination);
                                this.addToCache(distance);
                                return [2 /*return*/, new Promise(function (resolve, reject) {
                                        Google.MapRequest.requestJSBridge(function (geo, error) {
                                            // error is ignored.
                                            if (Google.Geo.isValid(geo)) {
                                                var waypoint = geo.geocoded_waypoints[0];
                                                var legs = geo.routes[0].legs;
                                                if (waypoint.geocoder_status === "OK" && legs && legs.length > 0)
                                                    distance.set(legs[0]);
                                            }
                                            resolve(distance.duration());
                                        }, distance.A.getAsEncodeURI(), distance.B.getAsEncodeURI());
                                    })];
                            }
                            return [2 /*return*/];
                        });
                    });
                };
                /**
                * Returns route duration in milliseconds through onFinishCallback. The shortest valid value is 1 millisecond (if addresses are the same) and 0 is return when distance can not be obtained.
                */
                Geo.prototype.getRouteDuration = function (onFinishCallback, origin, destination) {
                    if (!origin) {
                        onFinishCallback(0);
                        return;
                    }
                    if (!destination) {
                        if (!(destination = Geo.defaultOrigin)) {
                            onFinishCallback(0);
                            return;
                        }
                    }
                    else if (origin === destination) {
                        onFinishCallback(1);
                        return;
                    }
                    var duration = this.getDurationFromCache(origin, destination);
                    if (duration != 0)
                        onFinishCallback(duration);
                    else {
                        var distance = new Distance(destination, origin);
                        this.addToCache(distance);
                        this.sendDistanceRequest(distance, function () {
                            onFinishCallback(distance.duration());
                        });
                    }
                };
                Geo.prototype.calculateBestCombination = function (location, timeMatrix) {
                    return undefined;
                };
                Geo.prototype.prepareMatrix = function (route) {
                    var locationCount = route.waypoints.length + 1;
                    var timeMatrix = new Array(locationCount);
                    for (var i = 0; i < locationCount; i++) {
                        timeMatrix[i] = new Array(locationCount);
                        for (var j = 0; j < locationCount; j++)
                            timeMatrix[i][j] = -1;
                    }
                    return timeMatrix;
                };
                Geo.prototype.calculateDistanceMatrix = function (onFinishCallback, row, col, location, timeMatrix) {
                    if (row < location.length) {
                        var l = location[row];
                        var self = this;
                        if (col === 0) {
                            self.getRouteDuration(function (travelDuration) {
                                timeMatrix[row][0] = travelDuration;
                                if (col <= row)
                                    col = row + 1;
                                self.calculateDistanceMatrix(onFinishCallback, row, col, location, timeMatrix);
                            }, l);
                        }
                        else if (col < location.length) {
                            self.getRouteDuration(function (travelDuration) {
                                timeMatrix[row][col] = travelDuration;
                                self.calculateDistanceMatrix(onFinishCallback, ++row, 0, location, timeMatrix);
                            }, l, location[col]);
                        }
                        else
                            self.calculateDistanceMatrix(onFinishCallback, ++row, 0, location, timeMatrix);
                    }
                    else
                        onFinishCallback(this.calculateBestCombination(location, timeMatrix));
                };
                Geo.prototype.getDurationFromCache = function (origin, destination) {
                    var distance = this.items[origin.toString() + "|" + destination.toString()];
                    return distance ? distance.duration() : 0;
                };
                Geo.prototype.addToCache = function (d) {
                    var pointA = d.A.toString(), pointB = d.B.toString();
                    this.items[pointA + "|" + pointB] = d;
                    this.items[pointB + "|" + pointA] = d;
                };
                Geo.prototype.sendDistanceRequest = function (d, onFinishCallback) {
                    if (!d.A || !d.B) {
                        onFinishCallback();
                        return;
                    }
                    Google.MapRequest.requestJSBridge(function (geo, error) {
                        if (Google.Geo.isValid(geo)) {
                            var waypoint = geo.geocoded_waypoints[0];
                            var legs = geo.routes[0].legs;
                            if (waypoint.geocoder_status === "OK" && legs && legs.length > 0)
                                d.set(legs[0]);
                        }
                        onFinishCallback();
                    }, d.A.getAsEncodeURI(), d.B.getAsEncodeURI());
                };
                return Geo;
            }());
            Geo.Service = new Geo();
            Scheduler.Geo = Geo;
            // Helper class gets or calculates distance between location A and B
            var Distance = (function () {
                function Distance(A, B, leg) {
                    this.A = A;
                    this.B = B;
                    if (leg)
                        this.set(leg);
                    else {
                        this._distanceAproximation = this.A ? this.A.calculateDistance(this.B) : 0;
                        if (this._distanceAproximation === 0.0001) {
                            this._distance = this._distanceAproximation;
                            this._duration = 1;
                        }
                    }
                }
                Distance.prototype.distance = function () {
                    return this._distance ? this._distance : this._distanceAproximation;
                };
                Distance.prototype.duration = function () {
                    if (this._duration)
                        return this._duration;
                    else if (!this._distanceAproximation && this.A)
                        this._distanceAproximation = this.A.calculateDistance(this.B);
                    if (!this._distanceAproximation)
                        return 0;
                    //return this.roundToMinutes(((this._distanceAproximation * 40) / 60) * minuteInMiliseconds); // duration in minutes when speed is 40km/h
                    return this.roundToMinutes((this._distanceAproximation * 40) / 60); // duration in minutes when speed is 40km/h
                };
                Distance.prototype.set = function (leg) {
                    if (!this.A.hasGPS() && leg.start_location && leg.start_location.lat && leg.start_location.lng)
                        this.A.setLocation(leg.start_location.lat, leg.start_location.lng);
                    if (!this.B.hasGPS() && leg.end_location && leg.end_location.lat && leg.end_location.lng)
                        this.B.setLocation(leg.end_location.lat, leg.end_location.lng);
                    this._distance = leg.distance.value / 1000; // convert to km
                    this._duration = leg.duration.value * 1000; // convert to milliseconds
                    this._duration = this.roundToMinutes(this._duration);
                    if (this._duration === 0)
                        this._duration = 1;
                };
                Distance.prototype.roundToMinutes = function (val) {
                    return Math.ceil(val / Scheduler.minuteInMiliseconds) * Scheduler.minuteInMiliseconds;
                };
                return Distance;
            }());
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
var Google;
(function (Google) {
    var Gps = (function () {
        function Gps() {
        }
        return Gps;
    }());
    var Value = (function () {
        function Value() {
        }
        return Value;
    }());
    var Leg = (function () {
        function Leg() {
        }
        return Leg;
    }());
    Google.Leg = Leg;
    var Waypoin = (function () {
        function Waypoin() {
        }
        return Waypoin;
    }());
    var Route = (function () {
        function Route() {
        }
        return Route;
    }());
    var Geo = (function () {
        function Geo() {
        }
        Geo.isValid = function (g) {
            return g && g.status === "OK" && g.routes && g.routes.length > 0 && g.geocoded_waypoints && g.geocoded_waypoints.length > 0;
        };
        return Geo;
    }());
    Google.Geo = Geo;
    var MapRequest = (function () {
        function MapRequest() {
        }
        MapRequest.initApiKey = function (apiKey) {
            if (apiKey)
                this._apiKey += "&key=" + apiKey;
        };
        MapRequest.createRequestUrl = function (origin, destination, waypoints, doNotOptimize) {
            var requestUri = "https://maps.googleapis.com/maps/api/directions/json?origin=" + origin + "&destination=" + destination;
            if (waypoints && waypoints.length > 0) {
                if (!doNotOptimize && waypoints.length > 1)
                    requestUri += "&waypoints=optimize:true|";
                else
                    requestUri += "&waypoints=optimize:false|";
                for (var i = 0; i < waypoints.length; i++)
                    requestUri += "|" + waypoints[i];
            }
            requestUri += "&mode=driving&sensor=false&unit=metric&language=en-EN";
            if (this._apiKey)
                requestUri += this._apiKey;
            return requestUri;
        };
        // Generate Google Directions API URL (according to https://developers.google.com/maps/documentation/directions)
        MapRequest.requestJSBridge = function (onFinishCallback, origin, destination, waypoints, doNotOptimize) {
            try {
                var httpWebRequest = new MobileCRM.Services.HttpWebRequest();
                var requestUri = this.createRequestUrl(origin, destination, waypoints, doNotOptimize);
                if (!requestUri) {
                    onFinishCallback(undefined, "Google map request failed. Invalid input parameters.");
                    return;
                }
                httpWebRequest.method = "GET";
                httpWebRequest.send(requestUri, function (response) {
                    var err = undefined;
                    var geo = undefined;
                    if (response.responseCode === 200)
                        geo = JSON.parse(response.responseText);
                    else
                        err = response.responseText;
                    onFinishCallback(geo, err);
                }, null);
            }
            catch (e) {
                onFinishCallback(undefined, e.message);
            }
        };
        return MapRequest;
    }());
    Google.MapRequest = MapRequest;
})(Google || (Google = {}));
