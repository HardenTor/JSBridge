///<reference path="../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="stringTable.ts" />
///<reference path="interfaces.ts" />
///<reference path="geo.ts" />
///<reference path="timeRange.ts" />
///<reference path="utilities.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var TaskStatusCode = (function () {
                function TaskStatusCode(value, name, localizationKey, taskStatusType, color, progressColor, isSecondaryValue) {
                    this.value = +value;
                    this.name = name;
                    this.localizationKey = localizationKey;
                    this.taskStatusType = +taskStatusType;
                    this.color = color;
                    this.progressColor = progressColor;
                    this.isSecondaryValue = isSecondaryValue;
                }
                return TaskStatusCode;
            }());
            Scheduler.TaskStatusCode = TaskStatusCode;
            var FilterDataSource = (function () {
                function FilterDataSource(name, localizationKey, filteredByLocalizationKey, query) {
                    this.name = name;
                    this.localizationKey = localizationKey;
                    this.filteredByLocalizationKey = filteredByLocalizationKey;
                    this.fetch = query;
                }
                return FilterDataSource;
            }());
            Scheduler.FilterDataSource = FilterDataSource;
            var LinkedData = (function () {
                function LinkedData(attrToFilterBy, entityName, from, to, linkType) {
                    if (linkType === void 0) { linkType = "inner"; }
                    this.linkType = "inner";
                    this.attrToFilterBy = attrToFilterBy;
                    this.entityName = entityName;
                    this.from = from;
                    this.to = to;
                    this.linkType = linkType;
                }
                return LinkedData;
            }());
            Scheduler.LinkedData = LinkedData;
            var AddressAttributes = (function (_super) {
                __extends(AddressAttributes, _super);
                function AddressAttributes(entityName, from, to, linkType) {
                    if (linkType === void 0) { linkType = "inner"; }
                    var _this = _super.call(this, undefined, entityName, from, to, linkType) || this;
                    _this.latitude = "address1_latitude";
                    _this.longitude = "address1_longitude";
                    _this.country = "address1_country";
                    _this.city = "address1_city";
                    _this.stateorprovince = "address1_stateorprovince";
                    _this.postalcode = "address1_postalcode";
                    _this.street1 = "address1_line1";
                    _this.street2 = "address1_line2";
                    return _this;
                }
                return AddressAttributes;
            }(LinkedData));
            Scheduler.AddressAttributes = AddressAttributes;
            var EntityBase = (function () {
                function EntityBase() {
                    this.canWrite = true;
                    this.primaryKeyName = "id";
                    this.primaryFieldName = "name";
                }
                return EntityBase;
            }());
            Scheduler.EntityBase = EntityBase;
            var ResourceDataInput = (function (_super) {
                __extends(ResourceDataInput, _super);
                function ResourceDataInput() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return ResourceDataInput;
            }(EntityBase));
            Scheduler.ResourceDataInput = ResourceDataInput;
            var UnscheduledDataInput = (function (_super) {
                __extends(UnscheduledDataInput, _super);
                function UnscheduledDataInput() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.defaultDuration = 60; // [minutes]
                    _this.color = "#ffdc4c";
                    _this.viewHeight = undefined; // enables functionality for undefined tasks managing
                    return _this;
                }
                return UnscheduledDataInput;
            }(EntityBase));
            Scheduler.UnscheduledDataInput = UnscheduledDataInput;
            var ScheduledDataInput = (function (_super) {
                __extends(ScheduledDataInput, _super);
                function ScheduledDataInput() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.attrScheduledStart = "scheduledstart";
                    _this.attrScheduledEnd = "scheduledend";
                    _this.attrStatus = "statuscode";
                    _this.deniedColor = "#ff0000";
                    _this.focusedColor = "#4286ff";
                    return _this;
                }
                return ScheduledDataInput;
            }(EntityBase));
            Scheduler.ScheduledDataInput = ScheduledDataInput;
            var TimeOffsDataInput = (function (_super) {
                __extends(TimeOffsDataInput, _super);
                function TimeOffsDataInput() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.color = "#B0A3A4A5";
                    _this.textColor = "white";
                    return _this;
                }
                return TimeOffsDataInput;
            }(ScheduledDataInput));
            Scheduler.TimeOffsDataInput = TimeOffsDataInput;
            var HolidaysDataInput = (function (_super) {
                __extends(HolidaysDataInput, _super);
                function HolidaysDataInput() {
                    var _this = _super !== null && _super.apply(this, arguments) || this;
                    _this.attrMonth = "month";
                    _this.attrDay = "day";
                    return _this;
                }
                return HolidaysDataInput;
            }(EntityBase));
            Scheduler.HolidaysDataInput = HolidaysDataInput;
            var OfficeDataInput = (function (_super) {
                __extends(OfficeDataInput, _super);
                function OfficeDataInput() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                return OfficeDataInput;
            }(EntityBase));
            Scheduler.OfficeDataInput = OfficeDataInput;
            var ConfigData = (function () {
                function ConfigData() {
                }
                return ConfigData;
            }());
            Scheduler.ConfigData = ConfigData;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
