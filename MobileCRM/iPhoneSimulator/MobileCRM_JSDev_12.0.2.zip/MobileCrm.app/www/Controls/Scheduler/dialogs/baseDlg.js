///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../../../Controls/popupMenu.ts"/>
///<reference path="../../../Controls/gestureManager.ts"/>
///<reference path="../utilities.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var BaseDlg = (function () {
                function BaseDlg() {
                    var _this = this;
                    this.m_width = 0;
                    this.m_height = 0;
                    this._startClientX = 0;
                    this._startClientY = 0;
                    this._startX = 0;
                    this._startY = 0;
                    this._moveStarted = false;
                    this._gestureManager = new Controls.GestureManager();
                    this._onPointerDown = function (ge) {
                        var e = ge.jQueryEventObject;
                        if (_this._cancelDlgMove(e.target)) {
                            //@DM: fix move dialog after scroll HTML ListBox; => Controls.listBox.ts
                            ge.cancelDown = true;
                            return;
                        }
                        _this._startClientX = ge.pageX;
                        _this._startClientY = ge.pageY;
                        var elementPosition = _this._element.position();
                        _this._startX = _this._startClientX - elementPosition.left;
                        _this._startY = _this._startClientY - elementPosition.top;
                        _this._moveStarted = false;
                    };
                    this._onPointerMove = function (ge) {
                        var e = ge.jQueryEventObject;
                        var actualX = ge.pageX;
                        var actualY = ge.pageY;
                        var left = actualX - _this._startX;
                        var top = actualY - _this._startY;
                        var right = _this.m_width + left;
                        var bottom = _this.m_height + top;
                        var minVisibleWidth = window.innerWidth / 5;
                        var minVisibleHeight = window.innerHeight / 5;
                        if (minVisibleWidth > _this.m_width)
                            minVisibleWidth = _this.m_width;
                        if (minVisibleHeight > _this.m_height)
                            minVisibleHeight = _this.m_height;
                        if (!_this._moveStarted && (Math.abs(_this._startClientX - actualX) > Scheduler.Container.constants.dialogMinMoveDistance || Math.abs(_this._startClientY - actualY) > Scheduler.Container.constants.dialogMinMoveDistance)) {
                            _this._moveStarted = true;
                        }
                        if (_this._moveStarted) {
                            if ((right - minVisibleWidth) >= 0 && (left + minVisibleWidth) < window.innerWidth)
                                _this._element.css({ left: left });
                            if ((bottom - minVisibleHeight) >= 0 && (top + minVisibleHeight) < window.innerHeight)
                                _this._element.css({ top: top });
                        }
                    };
                    this._onPointerUp = function (ge) {
                        _this._moveStarted = false;
                    };
                    this.dialog = null;
                    this.tabButtons = null;
                }
                BaseDlg.prototype.create = function (content, width, height, onCloseCallBack) {
                    var _this = this;
                    if (!width)
                        width = 400;
                    if (!height)
                        height = 500;
                    this.m_width = width;
                    this.m_height = height;
                    this._onCloseCallBack = onCloseCallBack;
                    $("#__blackpopup__").remove();
                    this._backgroundElement = $("<div>").attr("id", "__blackpopup__");
                    this._backgroundElement.append("<div id='bwinPopupd' name='bwinPopupd'></div>");
                    Scheduler.Utilities.bringToFront(this._backgroundElement);
                    this._element = this._backgroundElement.find("#bwinPopupd");
                    this._element.css({
                        width: width,
                        height: height,
                        left: this.getPositionValue(window.innerWidth, this.m_width),
                        top: Math.floor(window.innerHeight / 10),
                    });
                    var closeButton = content.find(".closeButton");
                    closeButton.click(function () {
                        _this.destroy();
                    });
                    $("body").append(this._backgroundElement);
                    // prevents click on underlay elements if dialog is shown over them
                    this._backgroundElement.on("click", null, function (e) {
                        e.stopPropagation();
                    });
                    this._element.append(content);
                    this._addMoveEventsToDialogWindow(this._element);
                    return this._element;
                };
                BaseDlg.prototype.getPositionValue = function (dimension, dialogDimension) {
                    return Math.floor(dimension / 2) - Math.floor(dialogDimension / 2);
                };
                BaseDlg.prototype._addMoveEventsToDialogWindow = function (element) {
                    this._gestureManager.onDownMoveUpCancel(element, this._onPointerDown, this._onPointerMove, this._onPointerUp, this._onPointerUp);
                };
                BaseDlg.prototype._removeMoveEventsToDialogWindow = function (element) {
                    this._gestureManager.offDownMoveUpCancel(element, this._onPointerDown, this._onPointerMove, this._onPointerUp, this._onPointerUp);
                };
                BaseDlg.prototype._cancelDlgMove = function (target) {
                    var $target = $(target);
                    var $tabBodyContent = $(".rescoTabContent.displayFlex .rescoTabBodyContent");
                    if ($tabBodyContent.length > 0) {
                        var tabBodyContent = $tabBodyContent[0];
                        var isScrollable = tabBodyContent.clientHeight < tabBodyContent.scrollHeight;
                        this._updateTabBodyContentOverflow(tabBodyContent, isScrollable); // JC: !!!Hack to make dialog move possible on android devices if "rescoTabBodyContent" element is dragged.
                        if (isScrollable && $target.closest(tabBodyContent).length > 0) {
                            return true; // Move needs to be canceled for mouse (pointerType) also, because if scrollbar (on ".rescoTabBodyContent" element) is clicked, scrollbar consumes mouseup event!
                        }
                    }
                    if (target.localName === "button" ||
                        target.localName === "input" ||
                        target.localName === "select" ||
                        target.localName === "option" ||
                        (target.localName === "label" && target.hasAttribute("for"))) {
                        return true;
                    }
                    if ($target.hasClass("rescoTabButton") ||
                        $target.closest(".rescoInputDatePicker").length > 0 ||
                        $target.closest(".rescoInputTimePicker").length > 0 ||
                        $target.closest(".list-box").length > 0 ||
                        $target.closest(".sliderPointStart").length > 0 ||
                        $target.closest(".sliderPointEnd").length > 0) {
                        return true;
                    }
                    return false;
                };
                BaseDlg.prototype._updateTabBodyContentOverflow = function (tabBodyContent, isScrollable) {
                    // JC: !!!Hack to make dialog move possible on android devices if "rescoTabBodyContent" element is dragged. If element "overflow" css style is set to "auto", up event arrives and end move. (Probably showing scrollbar caused element redraw.)
                    if (MobileCRM.bridge.platform === "Android") {
                        if (isScrollable) {
                            tabBodyContent.style.overflowX = "scroll";
                            tabBodyContent.style.overflowY = "scroll";
                        }
                        else {
                            tabBodyContent.style.overflowX = "hidden";
                            tabBodyContent.style.overflowY = "hidden";
                        }
                    }
                };
                BaseDlg.prototype.destroy = function () {
                    var _this = this;
                    this._removeMoveEventsToDialogWindow(this._element);
                    this._backgroundElement.slideUp(300, function () {
                        _this._backgroundElement.remove();
                        if (_this._onCloseCallBack)
                            _this._onCloseCallBack();
                    });
                };
                BaseDlg.prototype.initializeTabDialog = function (dialog) {
                    var _this = this;
                    this.dialog = dialog;
                    this.tabButtons = dialog.find(".rescoTabButton");
                    this.tabButtons.click(function (evt) {
                        _this.selectPage(evt.currentTarget);
                    });
                    if (this.tabButtons.length > 0)
                        this.selectPage(this.tabButtons[0]);
                };
                BaseDlg.prototype.selectPage = function (page) {
                    // this method cannot use JQuery methods to manipulate class name, because elements are not appended to DOM yet.
                    var i;
                    var tabContent = this.dialog.find(".rescoTabContent");
                    for (i = 0; i < tabContent.length; i++) {
                        tabContent[i].className = tabContent[i].className.replace(" displayFlex", ""); //$(tabContent[i]).removeClass("displayFlex");
                    }
                    for (i = 0; i < this.tabButtons.length; i++) {
                        this.tabButtons[i].parentElement.classList.remove("active");
                        this.tabButtons[i].parentElement.classList.add("nonActive");
                    }
                    var pageId = page.getAttribute("id");
                    pageId = pageId.substring(pageId.indexOf("_") + 1);
                    this.dialog.find("#" + pageId)[0].className += " displayFlex"; //$("#" + page.innerText).addClass("displayFlex"); // .displayFlex { display: flex; display: -webkit-flex; }
                    page.parentElement.classList.remove("nonActive");
                    page.parentElement.classList.add("active");
                };
                return BaseDlg;
            }());
            Scheduler.BaseDlg = BaseDlg;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
