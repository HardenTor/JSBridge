///<reference path="../../../TypeScriptDefinitions/JSBridge.d.ts" />
///<reference path="../../../TypeScriptDefinitions/jquery.d.ts" />
///<reference path="../enums.ts" />
///<reference path="../container.ts" />
///<reference path="../settings.ts" />
///<reference path="baseDlg.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var BasePage = (function () {
                //private _tabContentBodyElement: JQuery;
                function BasePage(dialog, id, tabLocalizationKey, tabName, tabContentLocalizationKey, tabContentName) {
                    this.dialog = dialog;
                    this._id = id;
                    this._tabLocalizationKey = tabLocalizationKey;
                    this._tabName = tabName;
                    this._tabContentLocalizationKey = tabContentLocalizationKey;
                    this._tabContentName = tabContentName;
                    this._tabElement = this._createTabElement();
                    this._tabContentElement = this._createTabContentElement();
                }
                Object.defineProperty(BasePage.prototype, "tabElement", {
                    get: function () {
                        return this._tabElement;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "tabContentElement", {
                    get: function () {
                        return this._tabContentElement;
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(BasePage.prototype, "tabContentBodyElement", {
                    get: function () {
                        return this.tabContentElement.find(".rescoTabBodyContent");
                    },
                    enumerable: true,
                    configurable: true
                });
                BasePage.prototype._createTabElement = function () {
                    var template = '<li><a id="tab_' + this._id + '" href="javascript: void(0)" class="rescoTabButton text" draggable="false" data-localization="' + this._tabLocalizationKey + '">' + this._tabName + '</a></li>\"';
                    return $(template);
                };
                BasePage.prototype._createTabContentElement = function () {
                    var template = '\
				<div id="' + this._id + '" class="rescoTabContent">\
					<p class="title" data-localization="' + this._tabContentLocalizationKey + '">' + this._tabContentName + '</p>\
					<p></p>\
					<div class="rescoTabBodyContent" style="display: block;"></div>\
				</div>\
			';
                    return $(template);
                };
                BasePage.prototype.addBodyContent = function (template) {
                    this.tabContentBodyElement.append(template);
                };
                BasePage.prototype.removeRescoComponents = function () {
                };
                return BasePage;
            }());
            Scheduler.BasePage = BasePage;
            var BasePickersPage = (function (_super) {
                __extends(BasePickersPage, _super);
                function BasePickersPage() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                BasePickersPage.prototype.createRescoInputDatePicker = function (element, date, dimention, isEditable) {
                    var firstDay = Scheduler.Container.defaultOffice.firstDayOfWeek;
                    var _datePickerSettings = {
                        firstWeekDay: firstDay,
                        actualDate: date,
                        dayNames: Scheduler.Utilities.getAbbreviatedDayNames(firstDay),
                        monthNames: Scheduler.Container.constants.cultureInfo.dateTimeFormat.monthNames.slice(),
                        images: [
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_left.png", ""),
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_right.png", ""),
                        ],
                        platform: MobileCRM.bridge.platform,
                    };
                    var settings = {
                        actualDate: date,
                        parentElement: element[0],
                        datePickerIcon: Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", ""),
                        datePickerSetting: _datePickerSettings,
                        dateFormat: Controls.RescoInputDatePicker.dateFormat[0],
                        readOnly: true,
                        dimension: dimention,
                        useRotationForIcon: true,
                        isEditable: isEditable
                    };
                    return new Resco.Controls.RescoInputDatePicker(settings);
                };
                BasePickersPage.prototype.createRescoInputTimePicker = function (element, minRange, time, dimension, isEditable, format) {
                    var actualTime = new Controls.RescoTime();
                    if (time instanceof Date) {
                        actualTime.hour = time.getHours();
                        actualTime.minute = time.getMinutes();
                    }
                    else {
                        actualTime = time;
                    }
                    var timePickerSettings = {
                        format: format || Resco.Controls.RescoTimePickerFormat.format24,
                        minRange: minRange,
                        arrowImages: [
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_up.png", ""),
                            Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", "")
                        ],
                        platform: MobileCRM.bridge.platform,
                        time: actualTime,
                    };
                    var settings = {
                        actualTime: actualTime,
                        parentElement: element[0],
                        timePickerIcon: Scheduler.ImageFactory.getInstance().getImageAsBase64string("Controls.arrow_down.png", ""),
                        useRotationForIcon: true,
                        timePickerSettings: timePickerSettings,
                        readOnly: true,
                        dimension: dimension,
                        isEditable: isEditable
                    };
                    return new Resco.Controls.RescoInputTimePicker(settings);
                };
                BasePickersPage.prototype.disposeRescoDateControls = function (inputDatePicker) {
                    if (inputDatePicker) {
                        inputDatePicker.valueChanged.clear();
                        inputDatePicker.disposeRescoDatePickerElement();
                        inputDatePicker = null;
                    }
                };
                BasePickersPage.prototype.disposeRescoTimeControls = function (inputTimePicker) {
                    if (inputTimePicker) {
                        inputTimePicker.valueChanged.clear();
                        inputTimePicker.disposeRescoTimePickerElement();
                        inputTimePicker = null;
                    }
                };
                return BasePickersPage;
            }(BasePage));
            Scheduler.BasePickersPage = BasePickersPage;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
