///<reference path="../../TypeScriptDefinitions/jquery.d.ts" />
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        var Scheduler;
        (function (Scheduler) {
            var HScroll = (function () {
                function HScroll(className) {
                    this._className = className;
                }
                HScroll.prototype.getScroller = function () {
                    return $(this._className);
                };
                HScroll.prototype.getScrollRange = function () {
                    return this.getScroller().get(0).scrollWidth;
                };
                HScroll.prototype.getPageSize = function () {
                    return this.getScroller().width();
                };
                HScroll.prototype.getMaxScrollPos = function () {
                    var scroller = this.getScroller();
                    return scroller.get(0).scrollWidth - scroller.width();
                };
                HScroll.prototype.getScrollPos = function () {
                    return this.getScroller().scrollLeft();
                };
                HScroll.prototype.setScrollPos = function (pos) {
                    this.getScroller().scrollLeft(pos);
                };
                HScroll.prototype.scrollToFitTask = function (taskBoxLeftEdge, taskBoxWidth, minEdgeSpace) {
                    var scrollWidth = this.getPageSize();
                    var scrollLeftEdge = this.getScrollPos();
                    var scrollRightEdge = scrollLeftEdge + scrollWidth;
                    var taskBoxRightEdge = taskBoxLeftEdge + taskBoxWidth;
                    var distanceFromLeftEdge = taskBoxLeftEdge - scrollLeftEdge;
                    var distanceFromRightEdge = scrollRightEdge - taskBoxRightEdge;
                    var exceedLeft = distanceFromLeftEdge < minEdgeSpace;
                    var exceedRight = distanceFromRightEdge < minEdgeSpace;
                    var taskBoxTooWide = (taskBoxWidth + 2 * minEdgeSpace) > scrollWidth;
                    if ((distanceFromLeftEdge < 0) && (distanceFromRightEdge < 0)) {
                        // if start and end edge of the task is not visible in the view do not start scrolling automatically.
                    }
                    else {
                        if (exceedRight && (!taskBoxTooWide || (distanceFromRightEdge > 0))) {
                            var maxScrollLeftValue = this.getMaxScrollPos();
                            var deltaScrollX = minEdgeSpace - distanceFromRightEdge;
                            var newScrollLeft = scrollLeftEdge + deltaScrollX;
                            if (newScrollLeft > maxScrollLeftValue) {
                                newScrollLeft = maxScrollLeftValue;
                            }
                            this.setScrollPos(newScrollLeft);
                        }
                        else if (exceedLeft && (!taskBoxTooWide || (distanceFromLeftEdge > 0))) {
                            var deltaScrollX = minEdgeSpace - distanceFromLeftEdge;
                            var newScrollLeft = scrollLeftEdge - deltaScrollX;
                            if (newScrollLeft < 0) {
                                newScrollLeft = 0;
                            }
                            this.setScrollPos(newScrollLeft);
                        }
                    }
                };
                return HScroll;
            }());
            Scheduler.HScroll = HScroll;
            var VScroll = (function () {
                function VScroll(scrollableElement) {
                    this._scrollableElement = scrollableElement;
                }
                VScroll.prototype.getScroller = function () {
                    return this._scrollableElement;
                };
                VScroll.prototype.getScrollRange = function () {
                    return this.getScroller().get(0).scrollHeight;
                };
                VScroll.prototype.getPageSize = function () {
                    return this.getScroller().height();
                };
                VScroll.prototype.getMaxScrollPos = function () {
                    var scroller = this.getScroller();
                    return scroller.get(0).scrollHeight - scroller.height();
                };
                VScroll.prototype.getScrollPos = function () {
                    return this.getScroller().scrollTop();
                };
                VScroll.prototype.setScrollPos = function (pos) {
                    this.getScroller().scrollTop(pos);
                };
                VScroll.prototype.scrollToFitTask = function (taskBoxTopEdge, taskBoxHeight, minEdgeSpace) {
                    var scrollHeight = this.getPageSize();
                    var scrollTopEdge = this.getScrollPos();
                    var scrollBottomEdge = scrollTopEdge + scrollHeight;
                    var taskBoxBottomEdge = taskBoxTopEdge + taskBoxHeight;
                    var distanceFromTopEdge = taskBoxTopEdge - scrollTopEdge;
                    var distanceFromBottomEdge = scrollBottomEdge - taskBoxBottomEdge;
                    var exceedTop = distanceFromTopEdge < minEdgeSpace;
                    var exceedBottom = distanceFromBottomEdge < minEdgeSpace;
                    if ((distanceFromTopEdge < 0) && (distanceFromBottomEdge < 0)) {
                        // if start and end edge of the task is not visible in the view do not start scrolling automatically.
                    }
                    else {
                        if (distanceFromBottomEdge < 0) {
                            var maxScrollTopValue = this.getMaxScrollPos();
                            var deltaScrollY = -distanceFromBottomEdge;
                            var newScrollTop = scrollTopEdge + deltaScrollY;
                            if (newScrollTop > maxScrollTopValue) {
                                newScrollTop = maxScrollTopValue;
                            }
                            this.setScrollPos(newScrollTop);
                        }
                        else if (distanceFromTopEdge < 0) {
                            var deltaScrollY = -distanceFromTopEdge;
                            var newScrollTop = scrollTopEdge - deltaScrollY;
                            if (newScrollTop < 0) {
                                newScrollTop = 0;
                            }
                            this.setScrollPos(newScrollTop);
                        }
                    }
                };
                return VScroll;
            }());
            Scheduler.VScroll = VScroll;
        })(Scheduler = Controls.Scheduler || (Controls.Scheduler = {}));
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
