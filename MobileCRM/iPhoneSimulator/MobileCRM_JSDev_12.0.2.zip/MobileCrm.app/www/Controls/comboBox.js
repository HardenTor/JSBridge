/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="event.ts" />
/// <reference path="controls.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var Controls;
    (function (Controls) {
        /**
         * Event arguments with information about which item has been changed and which is status.
         */
        var SelectionChangedEventArgs = (function (_super) {
            __extends(SelectionChangedEventArgs, _super);
            function SelectionChangedEventArgs(item, status) {
                var _this = _super.call(this) || this;
                _this._item = item;
                _this._status = status;
                return _this;
            }
            Object.defineProperty(SelectionChangedEventArgs.prototype, "changedItem", {
                get: function () {
                    return this._item;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SelectionChangedEventArgs.prototype, "status", {
                get: function () {
                    return this._status;
                },
                enumerable: true,
                configurable: true
            });
            return SelectionChangedEventArgs;
        }(Resco.EventArgs));
        /**
         * Event arguments object where is information about which item was clicked.
         */
        var TreeViewItemClickedEventArgs = (function (_super) {
            __extends(TreeViewItemClickedEventArgs, _super);
            /**
             * Constructor for TreeItemClickedEventArgs.
             */
            function TreeViewItemClickedEventArgs(treeItem) {
                var _this = _super.call(this) || this;
                _this.m_treeItem = treeItem;
                return _this;
            }
            Object.defineProperty(TreeViewItemClickedEventArgs.prototype, "treeItem", {
                /** Get treeViewItem which raised click event.*/
                get: function () {
                    return this.m_treeItem;
                },
                enumerable: true,
                configurable: true
            });
            return TreeViewItemClickedEventArgs;
        }(Resco.EventArgs));
        /**
         * Class represents one item in the list box component
         */
        var ListBoxItem = (function () {
            /**
             * Public constructor of the listBoxItem with label for this item.
             * @param label
             */
            function ListBoxItem(label) {
                var _this = this;
                this.label = label;
                this.isSelected = ko.observable(false);
                this.isSelected.subscribe(function (value) {
                    _this.selectionChanged.raise(new SelectionChangedEventArgs(_this, value), _this);
                });
                this.isEnabled = ko.observable(true);
                this.selectionChanged = new Resco.Event(this);
            }
            /**
             * Handles click on the one listBoxItem in the ListBox.
             * @param sender
             * @param e
             */
            ListBoxItem.prototype.listBoxItemClicked = function (sender, e) {
                this.isSelected(!this.isSelected());
            };
            return ListBoxItem;
        }());
        /**
         * Public ViewModel for listBox component with lines of listBoxItems.
         */
        var ListBox = (function () {
            function ListBox(parameters) {
                this.windowMonitor = parameters.windowMonitor;
                this._initialization(parameters);
            }
            /**
             * Makes initialization of the all necessary properties and calls all method for correct displaying ListBox
             * @param parameters
             */
            ListBox.prototype._initialization = function (parameters) {
                this._dimensionChanged = parameters.dimensionChanged;
                this.dataSource = parameters.dataSource;
                this._checkDimensionValues(parameters.width, parameters.height);
                this._listBoxSelectionChanged = parameters.selectionChanged;
                this.displayMember = parameters.displayMember;
                this.valueMember = parameters.valueMember;
                this.statusMember = parameters.statusMember;
                this._loadItems(this.dataSource, parameters.selectedItem);
                this.ownTemplate = ko.observable();
                this.ownTemplate = parameters.template;
                this.rootHtmlElementName = parameters.rootHtmlElementName || "content";
            };
            /**
             * Calculates dimension of the listBox based on number of items in the data source.
             * @param width number default value for width of the listBox.
             * @param height number default value for height of the listBox.
             */
            ListBox.prototype._checkDimensionValues = function (width, height) {
                this.width = this._computeWidth(width);
                this.height = this._computeHeight(height);
                if ((this._dimensionChanged !== undefined) && (this.width !== width || this.height !== height)) {
                    this._dimensionChanged({
                        width: this.width,
                        height: this.height,
                    });
                }
            };
            ListBox.prototype._computeHeight = function (dHeight) {
                var rowHeight = 43; //@DM: height of the row set in CSS ??? 
                if (this.dataSource && this.dataSource.length > 0) {
                    var computedHeight = this.dataSource.length * rowHeight;
                    if (dHeight < computedHeight) {
                        computedHeight = dHeight;
                    }
                    return computedHeight;
                }
                return dHeight;
            };
            ListBox.prototype._computeWidth = function (dWidth) {
                if (this.windowMonitor.contentClientWidth() < dWidth && this.windowMonitor.contentClientWidth() > 0) {
                    return this.windowMonitor.contentClientWidth();
                }
                return dWidth;
            };
            /**
             * Creates ListBoxItems based on the data source objects.
             * @param dataSource
             * @param selected
             */
            ListBox.prototype._loadItems = function (dataSource, selected) {
                this.items = new Array();
                for (var _i = 0, dataSource_1 = dataSource; _i < dataSource_1.length; _i++) {
                    var item = dataSource_1[_i];
                    var label = this.displayMember === undefined ? item.toString() : item[this.displayMember];
                    var listItem = new ListBoxItem(label);
                    listItem.data = item;
                    if (this.statusMember !== undefined) {
                        var status_1 = item[this.statusMember];
                        if (typeof status_1 === "boolean")
                            listItem.isEnabled(status_1);
                        else if (typeof status_1 === "function" && typeof status_1() === "boolean")
                            listItem.isEnabled(status_1);
                    }
                    if (this.valueMember !== undefined) {
                        if (selected[this.valueMember] === item[this.valueMember]) {
                            listItem.isSelected(true);
                        }
                    }
                    else {
                        if (selected.toString() === item)
                            listItem.isSelected(true);
                    }
                    listItem.selectionChanged.add(this, this._onSelectionChanged);
                    this.items.push(listItem);
                }
            };
            /**
             * Event handler after list Box item selection changed.
             * @param sender
             * @param args
             */
            ListBox.prototype._onSelectionChanged = function (sender, args) {
                this._listBoxSelectionChanged({ changedItem: args.changedItem, status: args.status });
            };
            return ListBox;
        }());
        Controls.ListBox = ListBox;
        /**
         * ViewModel for component combo box. Combo box after open contains listBox component.
         */
        var ComboBox = (function () {
            /**
             * Public constructor of the ComboBox. Initializes other parameters necessary for creation of ListBox.
             * @param parameters Object represents IComponentConfigParameters used to sets all properties for comboBox.
             */
            function ComboBox(parameters) {
                var _this = this;
                this._initializeComboBox();
                this._initializeListBoxParameters(parameters);
                var label = this.listBoxParameters.displayMember === undefined ? this.listBoxParameters.selectedItem.toString() : this.listBoxParameters.selectedItem[this.listBoxParameters.displayMember];
                this.displayLabel(label);
                this._comboBoxSelectionChanged = parameters.selectionChanged;
                this.onSelectedItemChanged = function (args) {
                    var item = args.changedItem;
                    _this.displayLabel(item.label);
                    _this.listBoxParameters.selectedItem = item.data;
                    _this.isOpened(false);
                    _this._comboBoxSelectionChanged({ changedItem: item.data, status: args.status, });
                };
                this.onListBoxDimensionChanged = function (args) {
                    _this._setListBoxPosition(_this._targetDivElement, args);
                };
            }
            /**
             * Opens comboBox after click on rolled comboBox component.
             * @param sender
             * @param e Event which calls method and which has information about target where was clicked.
             */
            ComboBox.prototype.openComboBox = function (sender, e) {
                this._targetDivElement = e.currentTarget;
                this._setListBoxPosition(this._targetDivElement, { width: this.listBoxParameters.width, height: this.listBoxParameters.height, });
                this.isOpened(true);
            };
            /**
             * Makes from expanded ComboBox one row HTML component with displayed selected value.
             * @param sender
             * @param e
             */
            ComboBox.prototype.closeComboBox = function (sender, e) {
                this.isOpened(false);
                this.position.top(0);
                this.position.left(0);
                this._targetDivElement = null;
            };
            ComboBox.prototype._initializeComboBox = function () {
                this.position = {
                    top: ko.observable(0), left: ko.observable(0),
                };
                this.isOpened = ko.observable(false);
                this.displayLabel = ko.observable();
            };
            ComboBox.prototype._initializeListBoxParameters = function (parameters) {
                this.listBoxParameters = {
                    windowMonitor: parameters.windowMonitor,
                    width: parameters.width,
                    height: parameters.height,
                    dataSource: parameters.dataSource,
                    selectedItem: parameters.selectedItem,
                    displayMember: parameters.displayMember,
                    valueMember: parameters.valueMember,
                    statusMember: parameters.statusMember,
                    template: parameters.template,
                    selectionChanged: this.onSelectedItemChanged,
                    dimensionChanged: this.onListBoxDimensionChanged,
                    rootHtmlElementName: parameters.rootHtmlElementName || "content",
                };
            };
            ComboBox.prototype._setListBoxPosition = function (div, dimension) {
                var defaultWidthOfBorder = 2; //@DM: border on side has width 1px, but on 2 sides value is 2; 
                var defaultHeight = dimension.height;
                this.listBoxParameters.width = div.offsetWidth - Math.round(div.offsetWidth / 20);
                this.listBoxParameters.windowMonitor.contentScrollTop(document.getElementById(this.listBoxParameters.rootHtmlElementName).scrollTop);
                this.listBoxParameters.windowMonitor.contentClientHeight(document.getElementById(this.listBoxParameters.rootHtmlElementName).scrollHeight);
                this.listBoxParameters.windowMonitor.contentClientWidth(document.getElementById(this.listBoxParameters.rootHtmlElementName).clientWidth);
                var margin = 2; //@DM: border size (top, bottom )
                var topParentPosition = div.offsetTop;
                if (topParentPosition + defaultHeight + margin >= this.listBoxParameters.windowMonitor.contentHeight() + this.listBoxParameters.windowMonitor.contentScrollTop()) {
                    topParentPosition = topParentPosition - defaultHeight; // + div.clientHeight;
                }
                this.position.top(topParentPosition);
                this.position.left(div.offsetLeft);
            };
            return ComboBox;
        }());
        Controls.ComboBox = ComboBox;
        /**
         * Representation of the one line in the TreeView component
         */
        var TreeViewItem = (function () {
            /**
             * Puplic constructor for treeViewItem initializes all needed properies of the TreeViewItem.
             * @param label
             */
            function TreeViewItem(label) {
                var _this = this;
                /** property has information about treeViewItem has been loaded.*/
                this.isLoaded = false;
                this.treeViewItemClicked = new Resco.Event(this);
                this.selectionChanged = new Resco.Event(this);
                this.label = label;
                this.isEnabled = ko.observable(true);
                this.isSelected = ko.observable(false);
                this.isSelected.subscribe(function (value) {
                    _this.selectionChanged.raise(new SelectionChangedEventArgs(_this, value), _this);
                });
                this.isExpanded = ko.observable();
                this.children = ko.observableArray();
                this.parent = null;
                this.isEnabled(true);
                this.hasChildren = false;
            }
            /**
             * Method handles click on the treeViewItem.
             * @param sender
             * @param e
             */
            TreeViewItem.prototype.treeViewItemClick = function (sender, e) {
                this.treeViewItemClicked.raise(new TreeViewItemClickedEventArgs(this), this);
            };
            return TreeViewItem;
        }());
        /**
         * ViewModel of the component TreeView.
         */
        var TreeView = (function () {
            function TreeView(parameters) {
                /** dimension of the opened treeView with list of treeViewItems. */
                this.dimension = {
                    width: 0,
                    height: 0,
                };
                /** position of the opened treeView with list of treeViewItems.  */
                this.position = {
                    left: ko.observable(),
                    top: ko.observable(),
                };
                this._isEnabledInitSelection = false;
                this._dataSourceItemsCount = 0;
                this.displayLabel = ko.observable();
                this.isOpened = ko.observable();
                this._dataSource = parameters.dataSource;
                this._displayMember = parameters.displayMember;
                this._childrenMember = parameters.childrenMember;
                this._childrenFlagMember = parameters.childrenFlagMember;
                this._valueMember = parameters.valueMember;
                this._selectedItems = new Array();
                this._selectedItemsPath = parameters.selectedItemsPath || new Array();
                this.windowMonitor = parameters.windowMonitor;
                this.dimension = parameters.dimension;
                this._selectionChanged = parameters.selectionItemsChanged;
                this._sort = {
                    byChildren: true,
                    byAlphabet: true,
                };
                this._isEnabledInitSelection = parameters.isEnabledInitSelection;
                this.isMultiselect = parameters.isMultiselect || false;
                this._initializeItems();
            }
            /**
             * Opens tree view component. Makes expanded TreeView.
             * @param sender
             * @param e
             */
            TreeView.prototype.openTreeView = function (sender, e) {
                var target = e.currentTarget;
                this._setTreeViewPosition(target);
                this.isOpened(true);
            };
            /**
             * Makes from expanded TreeView one row HTML component with displayed selected value.
             * @param sender
             * @param e
             */
            TreeView.prototype.closeTreeView = function (sender, e) {
                this.isOpened(false);
                this.position.top(0);
                this.position.left(0);
            };
            /**
             * Method called after click on confirm button in case of multi-selection. It generate new value as displayValue, and sent callback to parent viewModel with serialized item which are separated by','
             * @param sender
             * @param e
             */
            TreeView.prototype.confirmTreeViewItems = function (sender, e) {
                this._selectionChanged(this._returnData(this._selectedItems, true));
                this.closeTreeView(null, null);
            };
            TreeView.prototype._initializeItems = function () {
                this.rootNote = new TreeViewItem();
                this.rootNote.isExpanded(true);
                this.rootNote.isLoaded = true;
                this.rootNote.depth = 0;
                this._loadItems(this.rootNote, this._dataSource, this._selectedItemsPath[0]); //@DM: TODO now is make selection only from first item selectedItemsPath
                if (this.displayLabel() === undefined || this.displayLabel() === "") {
                    this.displayLabel(this._changeDisplayLabel());
                }
            };
            TreeView.prototype._loadItems = function (parentTreeViewItem, dataSource, selectedItemsPath) {
                if (this.isMultiselect)
                    this._dataSourceItemsCount = dataSource.length;
                for (var _i = 0, dataSource_2 = dataSource; _i < dataSource_2.length; _i++) {
                    var item = dataSource_2[_i];
                    var label = this._displayMember === undefined ? item.toString() : item[this._displayMember];
                    var treeViewItem = new TreeViewItem(label);
                    treeViewItem.treeViewItemClicked.add(this, this._treeViewItemClicked);
                    treeViewItem.selectionChanged.add(this, this._treeViewItemSelectionChanged);
                    treeViewItem.data = item;
                    treeViewItem.hasChildren = item[this._childrenMember] !== undefined && item[this._childrenMember] !== "";
                    treeViewItem.parent = parentTreeViewItem;
                    treeViewItem.depth = parentTreeViewItem.depth + 1;
                    this._makeSelection(item, treeViewItem, selectedItemsPath);
                    parentTreeViewItem.children.push(treeViewItem);
                }
                if (this._sortItemsByAlphabet) {
                    this._sortItemsByAlphabet(parentTreeViewItem.children);
                }
                if (this._sort.byChildren) {
                    this._sortItemsByChildren(parentTreeViewItem.children);
                }
            };
            TreeView.prototype._makeSelection = function (item, treeViewItem, selectedItemsPath) {
                var _this = this;
                if (this.isMultiselect) {
                    if (selectedItemsPath.length === 0) {
                        return;
                    }
                    var foundItem = selectedItemsPath.filter(function (i) { return i === item[_this._valueMember]; });
                    if (foundItem.length > 0) {
                        treeViewItem.isSelected(true);
                    }
                }
                else {
                    if (selectedItemsPath !== undefined) {
                        if (selectedItemsPath.length === 1) {
                            if (selectedItemsPath[0] === "")
                                selectedItemsPath[0] = this._dataSource[0][this._valueMember];
                            if (item[this._valueMember] === selectedItemsPath[0] && !treeViewItem.hasChildren) {
                                treeViewItem.isSelected(true);
                                if (this._isEnabledInitSelection) {
                                    this._selectionChanged(this._returnData(this._selectedItems, false));
                                }
                            }
                        }
                        else if (treeViewItem.hasChildren && selectedItemsPath.length > 1) {
                            if ((selectedItemsPath[0] === treeViewItem.data[this._valueMember]) && selectedItemsPath[1] === treeViewItem.data[this._childrenFlagMember]) {
                                this._loadTreeViewItemChildren(treeViewItem, selectedItemsPath.slice(2, selectedItemsPath.length));
                            }
                        }
                    }
                }
            };
            TreeView.prototype._sortItemsByAlphabet = function (treeViewItems) {
                var _this = this;
                treeViewItems().sort(function (i1, i2) {
                    var label1 = (_this._displayMember === undefined ? i1.data.toString() : i1.data[_this._displayMember]).toLowerCase();
                    var label2 = (_this._displayMember === undefined ? i2.data.toString() : i2.data[_this._displayMember]).toLowerCase();
                    if (label1 < label2)
                        return -1;
                    if (label1 > label2)
                        return 1;
                    return 0;
                });
            };
            TreeView.prototype._sortItemsByChildren = function (treeViewItems) {
                treeViewItems().sort(function (i1, i2) {
                    if (i1.hasChildren && !i2.hasChildren)
                        return 1;
                    if (!i1.hasChildren && i2.hasChildren)
                        return -1;
                    return 0;
                });
            };
            TreeView.prototype._treeViewItemSelectionChanged = function (sender, args) {
                var treeViewItem = args.changedItem;
                if (args.status) {
                    if (!this.isMultiselect) {
                        this._selectedItems.forEach(function (i) { return i.isSelected(false); });
                    }
                    this._selectedItems.push(treeViewItem);
                }
                else {
                    var index = this._selectedItems.indexOf(treeViewItem);
                    if (index !== -1)
                        this._selectedItems.splice(index, 1);
                }
                this.displayLabel(this._changeDisplayLabel(treeViewItem));
            };
            TreeView.prototype._changeDisplayLabel = function (treeViewItem) {
                var displayLabel = "";
                if (this.isMultiselect) {
                    var labels = this._selectedItems.map(function (si) { return si.label; });
                    switch (labels.length) {
                        case 0:
                            displayLabel = "None";
                            break;
                        case this._dataSourceItemsCount:
                            displayLabel = "All";
                            break;
                        default:
                            displayLabel = labels.join(",");
                            break;
                    }
                }
                else {
                    displayLabel = (treeViewItem !== undefined) ? treeViewItem.label : TreeView.defaultEmptyLabel;
                }
                return displayLabel;
            };
            TreeView.prototype._returnData = function (array, sendSelectedStatus) {
                var result = { changedItems: new Array() };
                if (this.isMultiselect) {
                    for (var i = 0; i < array.length; i++) {
                        result.changedItems.push({ changedItem: array[i].data, status: array[i].isSelected() });
                    }
                }
                else {
                    result.changedItems = this._generateChangedItemsArray(array[0], sendSelectedStatus);
                }
                return result;
            };
            TreeView.prototype._generateChangedItemsArray = function (treeItem, sendSelectedStatus) {
                var items = new Array();
                if (treeItem.parent.data) {
                    items = this._generateChangedItemsArray(treeItem.parent);
                }
                items.push({ changedItem: treeItem.data, status: sendSelectedStatus ? treeItem.isSelected() : false });
                return items;
            };
            TreeView.prototype._treeViewItemClicked = function (sender, e) {
                var treeViewItem = sender;
                if (treeViewItem.hasChildren) {
                    if (treeViewItem.isLoaded && treeViewItem.isExpanded())
                        treeViewItem.isExpanded(false);
                    else if (treeViewItem.isLoaded && !treeViewItem.isExpanded())
                        treeViewItem.isExpanded(true);
                    else if (!treeViewItem.isLoaded && !treeViewItem.isExpanded()) {
                        this._loadTreeViewItemChildren(treeViewItem);
                    }
                }
                else {
                    treeViewItem.isSelected(!treeViewItem.isSelected());
                    if (!this.isMultiselect) {
                        if (this._selectedItems.length > 0)
                            this._selectionChanged(this._returnData(this._selectedItems, true));
                        this.closeTreeView(null, null);
                    }
                }
            };
            TreeView.prototype._loadTreeViewItemChildren = function (treeViewItem, selectedItemsPath) {
                var dataSource = treeViewItem.data[this._childrenMember]; /// ?????
                if (typeof dataSource === "function") {
                    this._loadItems(treeViewItem, dataSource(treeViewItem.data), selectedItemsPath);
                }
                else if (Array.isArray(dataSource)) {
                    this._loadItems(treeViewItem, dataSource, selectedItemsPath);
                }
                treeViewItem.isExpanded(true);
                treeViewItem.isLoaded = true;
            };
            TreeView.prototype._setTreeViewPosition = function (div) {
                this.windowMonitor.contentScrollTop(document.getElementById("content").scrollTop);
                this.windowMonitor.contentClientHeight(document.getElementById("content").scrollHeight);
                this.windowMonitor.contentClientWidth(document.getElementById("content").clientWidth);
                this.dimension.width = div.offsetWidth - Math.round(div.offsetWidth / 20);
                var margin = 2; //@DM: border size (top, bottom )
                var topParentPosition = div.offsetTop;
                if (topParentPosition + this.dimension.height + margin >= this.windowMonitor.contentHeight() + this.windowMonitor.contentScrollTop()) {
                    topParentPosition = topParentPosition - this.dimension.height; // + div.clientHeight;
                }
                this.position.top(topParentPosition);
                this.position.left(div.offsetLeft);
                this.childrenPartHeight = (80 * this.dimension.height) / 100; //@DM 80% of height this component is for children part
                this.bottomButtonsBarHeight = (20 * this.dimension.height) / 100; //@DM 20% of height this component is for bottom bar
            };
            return TreeView;
        }());
        /** default static field for displayLabel if in treeView any item isn't selected. */
        TreeView.defaultEmptyLabel = "Select Field"; // @DM: TS 2.0 change to read-only!
        Controls.TreeView = TreeView;
    })(Controls = Resco.Controls || (Resco.Controls = {}));
})(Resco || (Resco = {}));
