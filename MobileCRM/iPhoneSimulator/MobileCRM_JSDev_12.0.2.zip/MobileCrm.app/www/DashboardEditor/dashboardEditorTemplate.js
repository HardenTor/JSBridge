﻿///<reference path="../TypeScriptDefinitions/knockout.d.ts" />

function writeTemplates() {
	var addTemplate = function (templateName, templateMarkup) {
		document.write("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "<" + "/script>");
	};

	addTemplate("dashboardEditorView",
		"<div class='designer' data-bind='style: { height: editorSizeMonitor.height() + \"px\",  backgroundColor: formBackgroundColor }'>\
			<div class='header' data-bind='style: { backgroundColor: titleBackgroundColor, color: $root.titleForegroundColor }' >\
                <div class='backButton backArrow' data-bind='click: onBackButtonClick, style: { backgroundImage: backArrowImg }'></div>\
                <div class='designerName text'><span data-bind='text: isEntityListShow() ? \"Select Entity\": editorLabel'></span></div>\
                <div class='editButton addButton' data-bind='click: addNewEntityToDashboard, style: {backgroundImage: $root.addButtonImg}, visible: !isEntityListShow()'></div>\
                <div class='backButton saveButton' data-bind='click: saveEditor, style: { backgroundImage: saveButtonImg }, visible: !isEntityListShow()'></div>\
			</div>\
            <!-- ko ifnot: isEntityListShow && isEntityEdit -->\
                <!-- ko template: { name: \"dashboardMainView\", data: $data } --><!-- /ko -->\
            <!-- /ko -->\
            <!-- ko if: isEntityListShow -->\
                <!-- ko component: { name: \"selectionListComponent\", params: { items: entities, sizeMonitor: editorSizeMonitor, callback: updateSelectedEntity }} -->\<!-- /ko -->\
			<!-- /ko -->\
			<!-- ko if: isEntityEdit -->\
				<!-- ko component: { name: \"selectedEntityEditor\", params: { dashboardEnity: $root.selectedEntity, size: $root.editorSizeMonitor, localizedLabels: $root.bottomBarDisplayLabels, tabColors: [$root.tabSelForegroundColor(), $root.tabForegroundColor() ] }} -->\<!-- /ko -->\
			<!-- /ko -->\
            <!-- ko if: $root.contextMenu.enabled() -->\
                <!-- ko template: { name: \"contextMenu\", data: $root.contextMenu } --><!-- /ko -->\
                <div class='backend' data-bind='style: { height: $root.editorSizeMonitor.dashboardContentHeight() + \"px\", width: $root.editorSizeMonitor.width() + \"px\" }, click:$root.closeContext.bind($root) '></div>\
            <!-- /ko-->\
		</div>\
		");

	addTemplate("dashboardMainView",
		"<div id='content' class='content' data-bind='style: { height: editorSizeMonitor.dashboardContentHeight() + \"px\", backgroundColor: formBackgroundColor }'>\
			<div class='dashboardComponents'>\
				<!-- ko template: { name: \"entitySection\", data: selectedEntities } --><!-- /ko -->\
			</div>\
			<div class='dashboardGrid'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span>visualization</span>\
					</div>\
				</div>\
				<!-- ko template: { name: \"dashboardGrid\", data: $data } --><!-- /ko -->\
				<div class='sectionLabel partCaption'>\
					<span>This layout will be displayed differently on mobile phones, where each component will show on a separate screen.</span>\
				</div>\
			</div>\
		</div>");

	addTemplate("entitySection",
		"<div class='entitySection'>\
			<!-- ko if: $data.length == 0 -->\
				<div class='emptyEditor' data-bind='style: {backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class=''><div class='' data-bind='text: $root.noData'></div></div>\
				</div>\
			<!-- /ko -->\
			<!-- ko foreach: $data -->\
                <div class='separator' data-bind='style: {backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='component' data-bind='style: {backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='componentPart first child' data-bind='click: $root.editSelectedEntity.bind($root)'><div class='circle' data-bind='style: {backgroundColor: $root.formItemLabelForegroundColor }'><span data-bind='text: $index() + 1, style: {color: $root.formItemBackgroundColor }'></span></div></div>\
					<div class='componentPart eLabel' data-bind='click: $root.editSelectedEntity.bind($root)'>\
						<div class='entityLabel'>\
							<div class='a mainText'>\
								<span class='blockElement' data-bind='text: displayName'></span>\
							</div>\
							<div class='a'>\
								<span class='blockElement smallText additionaText' data-bind='text: additionalText'></span>\
							</div>\
						</div>\
					</div>\
					<div class='componentPart contextMenuButton' data-bind='click: $root.openContextMenu.bind($root), style: { backgroundImage: $root.actionButtonImg }'></div>\
				</div>\
			<!-- /ko -->\
		</div>");

	addTemplate("contextMenu",
   "<div class='contextMenu' data-bind='style: { top: topPosition() + \"px\", left: leftPosition() + \"px\" , borderColor: $root.formBackgroundColor }'>\
        <div class='contextMenuItem' data-bind='style: {backgroundColor: $root.formItemBackgroundColor }, click: $root.moveUpComponent.bind($root)' >\
            <div class='imageMenuItem' data-bind='style: {backgroundImage: $root.sortUpArrowImg }' ></div>\
            <div class='labelMenuItem text' data-bind='text: labelMoveUp, style: { color: $root.formItemLabelForegroundColor } '></div>\
        </div>\
        <div class='separator' data-bind='style: {backgroundColor: $root.formBackgroundColor }'></div>\
        <div class='contextMenuItem' data-bind='style: {backgroundColor: $root.formItemBackgroundColor }, click: $root.moveDownComponent.bind($root)' >\
            <div class='imageMenuItem' data-bind='style: {backgroundImage: $root.sortDownArrowImg }' ></div>\
            <div class='labelMenuItem text' data-bind='text: labelMoveDown, style: { color: $root.formItemLabelForegroundColor } '></div>\
        </div>\
        <div class='separator' data-bind='style: {backgroundColor: $root.formBackgroundColor }'></div>\
        <div class='contextMenuItem' data-bind='style: {backgroundColor: $root.formItemBackgroundColor }, click: $root.removeSelectedItem.bind($root)' >\
            <div class='imageMenuItem' data-bind='style: {backgroundImage: $root.deleteButtonImg }' ></div>\
            <div class='labelMenuItem text' data-bind='text: labelDelete, style: { color: $root.formItemLabelForegroundColor }'></div>\
        </div>\
    </div>\
    ");

	addTemplate("dashboardGrid",
		"<div class='grid'>\
			<div class='gridRow'>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
			</div>\
			<div class='gridRow'>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
			</div>\
			<div class='gridRow'>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
			</div>\
			<div class='gridRow'>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
				<div class='gridCell'></div>\
			</div>\
		</div>");
}

function registerSelectedEntityEditorComponet() {
	var addTemplate = function (templateName, templateMarkup) {
		document.write("<script type='text/html' id='" + templateName + "'>" + templateMarkup + "<" + "/script>");
	};

	addTemplate("optionsView", "\
		<div id='content' class='content' data-bind='style: { height: editorSizeMonitor.dashboardEntityViewModelHeight() + \"px\" }'>\
			<div class='section'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span data-bind='text: $root.sectionLabels[0]'></span>\
					</div>\
				</div>\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div><span data-bind='text: $root.optionViewCommands[0]'></span></div>\
					<div>\
                        <div class='switchButton' data-bind='style: { borderColor: createNewRecords() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: createNewRecords()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: function(data, event) { changeOptionsButtonStatus(\"createNewRecors\", data, event) }, attr: { switcher: createNewRecords() ? \"on\": \"off\" }'>\
                            <div class='abc' data-bind='attr: { switcher: createNewRecords() ? \"on\": \"off\" }, style: { backgroundColor: createNewRecords() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div>\
                        </div>\
                    </div>\
				</div>\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div><span data-bind='text: $root.optionViewCommands[1]'></span></div>\
					<div><div class='switchButton' data-bind='style: { borderColor: search() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: search()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: function(data, event) { changeOptionsButtonStatus(\"search\", data, event) }, attr: { switcher: search() ? \"on\": \"off\" }'><div class='abc' data-bind='attr: { switcher: search() ? \"on\": \"off\" }, style: { backgroundColor: search() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div></div></div>\
				</div>\
			</div>\
			<div class='section'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span data-bind='text: $root.sectionLabels[1]'></span>\
					</div>\
				</div>\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='text'><span data-bind='text: $root.bottomBarDisplayLabels[1]'></span></div>\
					<div><div class='switchButton' data-bind='style: { borderColor: displayRecordsAsListView() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: displayRecordsAsListView()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: function(data, event) { changeOptionsButtonStatus(\"listView\", data, event) }, attr: { switcher: displayRecordsAsListView() ? \"on\": \"off\" }'><div class='abc' data-bind='attr: { switcher: displayRecordsAsListView() ? \"on\": \"off\" }, style: { backgroundColor: displayRecordsAsListView() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div></div></div>\
				</div>\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='text'><span data-bind='text: $root.bottomBarDisplayLabels[3]'></span></div>\
					<div><div class='switchButton' data-bind='style: { borderColor: displayRecordsAsMap() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: displayRecordsAsMap()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: function(data, event) { changeOptionsButtonStatus(\"map\", data, event) }, attr: { switcher: displayRecordsAsMap() ? \"on\": \"off\" }'><div class='abc' data-bind='attr: { switcher: displayRecordsAsMap() ? \"on\": \"off\" }, style: { backgroundColor: displayRecordsAsMap() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div></div></div>\
				</div>\
                <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='text'><span data-bind='text: $root.bottomBarDisplayLabels[2]'></span></div>\
					<div><div class='switchButton' data-bind='style: { borderColor: displayRecordsAsChart() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: displayRecordsAsChart()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: function(data, event) { changeOptionsButtonStatus(\"chart\", data, event) }, attr: { switcher: displayRecordsAsChart() ? \"on\": \"off\" }'><div class='abc' data-bind='attr: { switcher: displayRecordsAsChart() ? \"on\": \"off\" }, style: { backgroundColor: displayRecordsAsChart() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div></div></div>\
				</div>\
			</div>\
			<div class='section'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span data-bind='text: $root.sectionLabels[2]'></span>\
					</div>\
				</div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='margin-right'><span>Selected</span></div>\
					<div class='text'>\
                        <!-- ko component: { name: \"combo-box\", params:\
                            {\
                                width: 300, \
                                height: 400,\
                                windowMonitor: $root.editorSizeMonitor,\
                                dataSource: initialType, \
                                selectedItem: initialViewTypeSelected(),\
                                selectionChanged: updateInitialViewType, \
                            }} -->\
                        <!-- /ko -->\
                    </div>\
				</div>\
			</div>\
		</div>\
	");

	addTemplate("listView", "\
		<div id='content' class='content' data-bind='style: { height: editorSizeMonitor.dashboardEntityViewModelHeight() + \"px\" }'>\
			<div class='section'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span data-bind='text: $root.sectionLabels[3]'></span>\
					</div>\
				</div>\
				<!-- ko foreach: views() -->\
                    <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
					<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
						<div class='firstElement text'><span data-bind='text: $data.label'></span></div>\
						<div class='secondElement'>\
							<div class='switchButton' data-bind='style: { borderColor: $data.enabled() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: $data.enabled()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: $parent.changeButtonStatus, attr: { switcher: $data.enabled() ? \"on\": \"off\" }'>\
								<div class='abc' data-bind='attr: { switcher: $data.enabled() ? \"on\": \"off\" }, style: { backgroundColor: $data.enabled() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div>\
							</div>\
						</div>\
					</div>\
				<!-- /ko -->\
			</div>\
			<div class='section'>\
				<div class='sectionLabel'>\
					<div class='sectionLabelText'>\
						<span data-bind='text: $root.sectionLabels[2]'></span>\
					</div>\
				</div>\
				<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
					<div class='margin-right'><span>Selected</span></div>\
					<div class='text'>\
                        <!-- ko component: { name: \"combo-box\", params:\
                            {\
                                width: 300, \
                                height: 400,\
                                windowMonitor: $root.editorSizeMonitor,\
                                dataSource:  views(), \
                                displayMember: \"label\",\
                                valueMember: \"name\",\
                                statusMember: \"enabled\",\
                                selectedItem: selectedView(),\
                                selectionChanged: updateSelectedView, \
                            }} -->\
                        <!-- /ko -->\
                    </div>\
				</div>\
			</div>\
		</div>\
	");

	addTemplate("chartView", "\
		<div id='content' class='content' data-bind='style: { height: editorSizeMonitor.dashboardEntityViewModelHeight() + \"px\" }'>\
			<!-- ko if: charts().length > 0 -->\
				<div class='section'>\
					<div class='sectionLabel'>\
						<div class='sectionLabelText'>\
							<span data-bind='text: $root.sectionLabels[4]'></span>\
						</div>\
					</div>\
					<!-- ko foreach: charts() -->\
                        <div class='separator' data-bind='style: { backgroundColor: $root.formBackgroundColor }'></div>\
						<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
							<div class='firstElement text'><span data-bind='text: $data.label'></span></div>\
							<div>\
								<div class='switchButton' data-bind='style: { borderColor: $data.enabled() ? $root.formItemLinkColor: $root.formItemForegroundColor, backgroundColor: $data.enabled()? $root.formItemLinkColor: $root.formItemBackgroundColor }, click: $parent.changeButtonStatus, attr: { switcher: $data.enabled() ? \"on\": \"off\" }'>\
									<div class='abc' data-bind='attr: { switcher: $data.enabled() ? \"on\": \"off\" }, style: { backgroundColor: $data.enabled() ? $root.formItemBackgroundColor: $root.formItemForegroundColor }'></div>\
								</div>\
							</div>\
						</div>\
					<!-- /ko -->\
				</div>\
				<div class='section'>\
					<div class='sectionLabel'>\
						<div class='sectionLabelText'>\
							<span data-bind='text: $root.sectionLabels[2]'></span>\
						</div>\
					</div>\
					<div class='sectionRow' data-bind='style: { backgroundColor: $root.formItemBackgroundColor, color: $root.formItemLabelForegroundColor }'>\
                    <div class='margin-right'><span>Selected</span></div>\
                        <div class='text'>\
                            <!-- ko component: { name: \"combo-box\", params:\
                                {\
                                    width: 300, \
                                    height: 400,\
                                    windowMonitor: $root.editorSizeMonitor,\
                                    dataSource:  charts(), \
                                    displayMember: \"label\",\
                                    valueMember: \"name\",\
                                    statusMember: \"enabled\",\
                                    selectedItem: selectedChart(),\
                                    selectionChanged: updateSelectedChart, \
                                }} -->\
                            <!-- /ko -->\
                        </div>\
                    </div>\
				</div>\
			<!-- /ko -->\
			<!-- ko ifnot: charts().length > 0 -->\
				<div class='section'>\
					<div class='infoMessage'>\
						<span data-bind='text: $root.chartViewNoData'></span>\
					</div>\
				</div>\
			<!-- /ko -->\
		</div>\
	");

	addTemplate("mapView", "\
		<div id='content' class='content' data-bind='style: { height: editorSizeMonitor.dashboardEntityViewModelHeight() + \"px\" }'>\
			<div class='section'>\
				<div class='infoMessage'>\
					<div>\
						<div><span data-bind='text: $root.mapViewMessage'></span></div>\
					</div>\
				</div>\
			</div>\
		</div>\
	");

	ko.components.register("selectedEntityEditor", {
		viewModel: DashboardEditor.DashboardEntityViewModel,
		template: "\
			<div class='header' data-bind='style: { backgroundColor: $root.titleBackgroundColor, color: $root.titleForegroundColor }' >\
				<div class='backButton backArrow' data-bind='click: $root.returnBackToMainScreen.bind($root), style: { backgroundImage: $root.backArrowImg }'></div>\
				<div class='designerName designerNameWidther'><span data-bind='text: displayName'></span></div>\
			</div>\
            <!-- ko if: bottomBarButtons[0].selected() -->\
                <!-- ko template: { name: \"optionsView\", data: $data } --><!-- /ko -->\
            <!-- /ko -->\
            <!-- ko if: bottomBarButtons[1].selected() -->\
                <!-- ko template: { name: \"listView\", data: $data } --><!-- /ko -->\
            <!-- /ko -->\
            <!-- ko if: bottomBarButtons[2].selected() -->\
                <!-- ko template: { name: \"chartView\", data: $data } --><!-- /ko -->\
            <!-- /ko -->\
            <!-- ko if: bottomBarButtons[3].selected() -->\
                <!-- ko template: { name: \"mapView\", data: $data } --><!-- /ko -->\
            <!-- /ko -->\
            <div class='bottomBar'>\
                <!-- ko foreach: bottomBarButtons -->\
                    <!-- ko if: enabled() || $data.logicalName == 'listView' -->\
                        <div data-bind='style: { backgroundColor: $root.tabBackgroundColor }'>\
                            <div class='bottomButton' data-bind='attr: { logicalName: logicalName }, click: $parent.bottomMenuBarClick.bind($parent), style: { backgroundImage: base }'></div>\
                            <span class='bottomBarLabel text' data-bind='text: displayName, style: { color: selected() ? $root.tabSelForegroundColor: $root.tabForegroundColor }'></span>\
                        </div>\
                    <!-- /ko -->\
                <!-- /ko -->\
            </div>\
            "
	});
}

(function () {
	writeTemplates();

	var templateEngine = ko.nativeTemplateEngine.instance;

	registerSelectionListComponent();
	registerSelectedEntityEditorComponet();
	registerComboBox();

	ko.bindingHandlers.row = {
        update: function (element, valueAccessor) {
            ko.renderTemplate("dashboardEditorView", valueAccessor(), { templateEngine: ko.nativeTemplateEngine.instance }, element, "replaceNode");
        }
	};

}());