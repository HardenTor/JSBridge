/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../Helpers/common.ts" />
/// <reference path="../Controls/IView.ts" />
var MobileCrm;
(function (MobileCrm) {
    var ImageProvider = (function () {
        function ImageProvider() {
            this.isOnline = true;
            this.m_imageCache = new Resco.Dictionary();
            this.m_defaultImages = new Resco.Dictionary();
            this.m_currentlyDownloading = new Resco.Dictionary();
        }
        Object.defineProperty(ImageProvider, "instance", {
            get: function () {
                if (!ImageProvider.s_instance) {
                    ImageProvider.s_instance = new ImageProvider();
                }
                return ImageProvider.s_instance;
            },
            enumerable: true,
            configurable: true
        });
        ImageProvider.prototype.getImage = function (path, colorize, onLoaded, element, async, placeholderPath) {
            var _this = this;
            var result;
            var cachePath = colorize ? path + "." + colorize : path;
            if (async === null || async === undefined) {
                async = true;
            }
            if (this.m_imageCache.containsKey(cachePath)) {
                result = this.m_imageCache.getValue(cachePath);
                this._handleLoadComplete(result, { onLoaded: onLoaded, element: element });
            }
            else if (async && this.m_currentlyDownloading.containsKey(path)) {
                var list = this.m_currentlyDownloading.getValue(path);
                list.push({ onLoaded: onLoaded, element: element, colorize: colorize });
            }
            else {
                this.m_currentlyDownloading.add(path, [{ onLoaded: onLoaded, element: element, colorize: colorize }]);
                MobileCRM.Application.getAppImage(path, colorize, function (data) {
                    var handlers = _this.m_currentlyDownloading.getValue(path);
                    result = data;
                    handlers.forEach(function (handler) {
                        if (result) {
                            // check if image is in cache
                            var cachePath = handler.colorize ? path + "." + handler.colorize : path;
                            // if image is in cache, get it from cache and raise the loadcomplete callback (we are done here)
                            if (_this.m_imageCache.containsKey(cachePath)) {
                                result = _this.m_imageCache.getValue(cachePath);
                            }
                            else {
                                _this.m_imageCache.set(cachePath, result);
                            }
                        }
                        _this._handleLoadComplete(result, handler);
                    }, _this);
                    _this.m_currentlyDownloading.remove(path);
                }, function (err) {
                    var handlers = _this.m_currentlyDownloading.getValue(path);
                    handlers.forEach(function (handler) {
                        _this._handleLoadComplete(null, handler);
                    }, _this);
                    _this.m_currentlyDownloading.remove(path);
                });
            }
            return result;
        };
        ImageProvider.prototype._handleLoadComplete = function (data, handler) {
            if (data && handler.element) {
                $(handler.element).attr("src", data);
            }
            if (handler.onLoaded) {
                handler.onLoaded(data);
            }
        };
        ImageProvider.prototype.getImageFromFolder = function (folder, name, colorize, onLoaded, element, async, placeholderPath) {
            if (folder) {
                name = folder + "\\" + name;
            }
            if (!name.endsWith(".png")) {
                name += ".png";
            }
            return this.getImage(name, colorize, onLoaded, element, async, placeholderPath);
        };
        ImageProvider.prototype.clearCache = function () {
        };
        return ImageProvider;
    }());
    MobileCrm.ImageProvider = ImageProvider;
})(MobileCrm || (MobileCrm = {}));
