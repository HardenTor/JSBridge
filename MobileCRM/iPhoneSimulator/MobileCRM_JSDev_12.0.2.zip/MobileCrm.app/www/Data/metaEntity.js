/// <reference path="../Helpers/common.ts" />
/// <reference path="metaData.ts" />
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var CrmLevel;
        (function (CrmLevel) {
            CrmLevel[CrmLevel["None"] = 0] = "None";
            CrmLevel[CrmLevel["SystemRequired"] = 1] = "SystemRequired";
            CrmLevel[CrmLevel["Required"] = 2] = "Required";
            CrmLevel[CrmLevel["Recommended"] = 3] = "Recommended";
            CrmLevel[CrmLevel["ReadOnly"] = 4] = "ReadOnly";
        })(CrmLevel = Data.CrmLevel || (Data.CrmLevel = {}));
        var CrmType;
        (function (CrmType) {
            /// <summary>Boolean property; <see cref="bool"/>.</summary>
            CrmType[CrmType["Boolean"] = 0] = "Boolean";
            /// <summary>Customer, special kind of <i>Lookup</i> property, only for <i>Accounts</i> and <i>Contacts</i>; <see cref="Guid"/>.</summary>
            CrmType[CrmType["Customer"] = 1] = "Customer";
            /// <summary>Date property; <see cref="DateTime"/>.</summary>
            CrmType[CrmType["DateTime"] = 2] = "DateTime";
            /// <summary>Decimal property; <see cref="decimal"/>.</summary>
            CrmType[CrmType["Decimal"] = 3] = "Decimal";
            /// <summary>Float property; <see cref="float"/>.</summary>
            CrmType[CrmType["Float"] = 4] = "Float";
            /// <summary>Integer property; <see cref="int"/>.</summary>
            CrmType[CrmType["Integer"] = 5] = "Integer";
            /// <summary>Internal property.</summary>
            CrmType[CrmType["Internal"] = 6] = "Internal";
            /// <summary>Lookup property, generally used for foreign keys; <see cref="Guid"/>.</summary>
            CrmType[CrmType["Lookup"] = 7] = "Lookup";
            /// <summary>Memo property, large string; <see cref="string"/>.</summary>
            CrmType[CrmType["Memo"] = 8] = "Memo";
            /// <summary>Money property; <see cref="decimal"/>.</summary>
            CrmType[CrmType["Money"] = 9] = "Money";
            /// <summary>Owner property.</summary>
            CrmType[CrmType["Owner"] = 10] = "Owner";
            /// <summary>PartyList property.</summary>
            CrmType[CrmType["PartyList"] = 11] = "PartyList";
            /// <summary>Picklist property, allows to pick a value from a list; <see cref="int"/>.</summary>
            CrmType[CrmType["Picklist"] = 12] = "Picklist";
            /// <summary>Primary key property; <see cref="Guid"/>.</summary>
            CrmType[CrmType["PrimaryKey"] = 13] = "PrimaryKey";
            /// <summary>State property; Must not be used.</summary>
            CrmType[CrmType["State"] = 14] = "State";
            /// <summary>Status property, special kind of Picklist; <see cref="int"/>.</summary>
            CrmType[CrmType["Status"] = 15] = "Status";
            /// <summary>String property; <see cref="string"/>.</summary>
            CrmType[CrmType["String"] = 16] = "String";
            /// <summary>Unique identifier; <see cref="Guid"/>.</summary>
            CrmType[CrmType["UniqueIdentifier"] = 17] = "UniqueIdentifier";
            /// <summary>Virtual property.</summary>
            CrmType[CrmType["Virtual"] = 18] = "Virtual";
            /// <summary>CalendarRules property.</summary>
            CrmType[CrmType["CalendarRules"] = 19] = "CalendarRules";
            /// <summary>EntityName property; Must not be used.</summary>
            CrmType[CrmType["EntityName"] = 20] = "EntityName";
            /// <summary>BigInt property; CRM2011 specific. Used for version number instead of String in CRM4</summary>
            CrmType[CrmType["BigInt"] = 21] = "BigInt";
            /// <summary>Double property; CRM2011 specific. Specifies a double attribute.</summary>
            CrmType[CrmType["Double"] = 22] = "Double";
            /// <summary>Special type used for workflows; Must not be used.</summary>
            CrmType[CrmType["PicklistArray"] = 4096] = "PicklistArray";
            /// <summary>Special type used in RescoXRM.</summary>
            CrmType[CrmType["RowVersion"] = 524288] = "RowVersion";
            /// <summary>Special type used in RescoXRM.</summary>
            CrmType[CrmType["Binary"] = 524289] = "Binary";
            /// <summary>Special type used as a List Temporary Variable in Rules</summary>
            CrmType[CrmType["StringList"] = 524290] = "StringList";
            /// <summary>Special type used as a Lookup Temporary Variable in Rules</summary>
            CrmType[CrmType["Entity"] = 524291] = "Entity";
            /// <summary>Special type used as a Lookup Temporary Variable in Rules</summary>
            CrmType[CrmType["Fetch"] = 524292] = "Fetch";
        })(CrmType = Data.CrmType || (Data.CrmType = {}));
        var CrmDisplayFormat;
        (function (CrmDisplayFormat) {
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Default"] = 0] = "Default";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Duration"] = 1] = "Duration";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["TimeZone"] = 2] = "TimeZone";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Language"] = 3] = "Language";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Locale"] = 4] = "Locale";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Email"] = 5] = "Email";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Text"] = 6] = "Text";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["TextArea"] = 7] = "TextArea";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["Url"] = 8] = "Url";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["TickerSymbol"] = 9] = "TickerSymbol";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["PhoneticGuide"] = 10] = "PhoneticGuide";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["DateOnly"] = 11] = "DateOnly";
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["DateAndTime"] = 12] = "DateAndTime";
            // Custom - not available in CRM
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["PhoneNumber"] = 13] = "PhoneNumber";
            // CRM2011 Specific
            /// <remarks/>
            CrmDisplayFormat[CrmDisplayFormat["VersionNumber"] = 14] = "VersionNumber";
            /// <remarks>
            /// Custom - not available in CRM. Field with this format enables barcode scanning in MobileCRM Lookup form.
            /// </remarks>
            CrmDisplayFormat[CrmDisplayFormat["Barcode"] = 15] = "Barcode";
            /// <remarks>
            /// Custom - not available in CRM. Field with this format uses HTML control for display (or the HTML is stripped if HTML display is not supported on the platform).
            /// This also implies multiline display.
            /// </remarks>
            CrmDisplayFormat[CrmDisplayFormat["Html"] = 16] = "Html";
        })(CrmDisplayFormat = Data.CrmDisplayFormat || (Data.CrmDisplayFormat = {}));
        var EntityPermissionDepth;
        (function (EntityPermissionDepth) {
            /// <summary>No permission granted.</summary>
            EntityPermissionDepth[EntityPermissionDepth["None"] = 0] = "None";
            /// <summary>Permission granted for entities owner by the user.</summary>
            EntityPermissionDepth[EntityPermissionDepth["User"] = 1] = "User";
            /// <summary>Permission granted for entities owner by the user's business unit.</summary>
            EntityPermissionDepth[EntityPermissionDepth["BusinessUnit"] = 2] = "BusinessUnit";
            /// <summary>Permission granted for entities owner by the user's business unit or a child business unit.</summary>
            EntityPermissionDepth[EntityPermissionDepth["ParentChild"] = 4] = "ParentChild";
            /// <summary>Permission granted for all entities in the organization.</summary>
            EntityPermissionDepth[EntityPermissionDepth["Organization"] = 8] = "Organization";
        })(EntityPermissionDepth = Data.EntityPermissionDepth || (Data.EntityPermissionDepth = {}));
        var EntityPermission;
        (function (EntityPermission) {
            /// <summary>Read permission.</summary>
            EntityPermission[EntityPermission["Read"] = 0] = "Read";
            /// <summary>Write permission.</summary>
            EntityPermission[EntityPermission["Write"] = 1] = "Write";
            /// <summary>Create permission.</summary>
            EntityPermission[EntityPermission["Create"] = 2] = "Create";
            /// <summary>Delete permission.</summary>
            EntityPermission[EntityPermission["Delete"] = 3] = "Delete";
            /// <summary>Append permission.</summary>
            EntityPermission[EntityPermission["Append"] = 4] = "Append";
            /// <summary>AppendTo permission.</summary>
            EntityPermission[EntityPermission["AppendTo"] = 5] = "AppendTo";
            /// <summary>Assign permission.</summary>
            EntityPermission[EntityPermission["Assign"] = 6] = "Assign";
            /// <summary>Share permission.</summary>
            EntityPermission[EntityPermission["Share"] = 7] = "Share";
            /*
            None = 0,
            Read = 0x0001,
            Write = 0x0002,
            Create = 0x0004,
            Append = 0x0008,
            AppendTo = 0x0010,
            Share = 0x0020,
            Assign = 0x0040,
            Delete = 0x0080,
            */
        })(EntityPermission = Data.EntityPermission || (Data.EntityPermission = {}));
        var PropertyPermission;
        (function (PropertyPermission) {
            PropertyPermission[PropertyPermission["None"] = 0] = "None";
            PropertyPermission[PropertyPermission["Read"] = 1] = "Read";
            PropertyPermission[PropertyPermission["Create"] = 2] = "Create";
            PropertyPermission[PropertyPermission["Update"] = 4] = "Update";
            PropertyPermission[PropertyPermission["All"] = 7] = "All";
        })(PropertyPermission = Data.PropertyPermission || (Data.PropertyPermission = {}));
        var EntityAttributes;
        (function (EntityAttributes) {
            /// <summary>No additional attributes.</summary>
            EntityAttributes[EntityAttributes["None"] = 0] = "None";
            /// <summary>Entity is an activity.</summary>
            EntityAttributes[EntityAttributes["IsActivity"] = 1] = "IsActivity";
            /// <summary>Entity is a child.</summary>
            EntityAttributes[EntityAttributes["IsChild"] = 2] = "IsChild";
            /// <summary>Custom entity.</summary>
            EntityAttributes[EntityAttributes["IsCustom"] = 4] = "IsCustom";
            /// <summary>Intersection entity (Many to Many).</summary>
            EntityAttributes[EntityAttributes["IsIntersect"] = 8] = "IsIntersect";
            /// <summary>Entity is an regular activity.</summary>
            EntityAttributes[EntityAttributes["IsRegularActivity"] = 16] = "IsRegularActivity";
            /// <summary>Entity is only available in online mode.</summary>
            EntityAttributes[EntityAttributes["IsOnlineOnly"] = 32] = "IsOnlineOnly";
            /// <summary>Disable read permission.</summary>
            EntityAttributes[EntityAttributes["NoRead"] = 64] = "NoRead";
            /// <summary>Disable write permission.</summary>
            EntityAttributes[EntityAttributes["NoWrite"] = 128] = "NoWrite";
            /// <summary>Disable create permission.</summary>
            EntityAttributes[EntityAttributes["NoCreate"] = 256] = "NoCreate";
            /// <summary>Disable delete permission.</summary>
            EntityAttributes[EntityAttributes["NoDelete"] = 512] = "NoDelete";
            /// <summary>Disable append permission.</summary>
            EntityAttributes[EntityAttributes["NoAppend"] = 1024] = "NoAppend";
            /// <summary>Disable appendTo permission.</summary>
            EntityAttributes[EntityAttributes["NoAppendTo"] = 2048] = "NoAppendTo";
            /// <summary>Disable assign permission.</summary>
            EntityAttributes[EntityAttributes["NoAssign"] = 4096] = "NoAssign";
            /// <summary>Disable share permission.</summary>
            EntityAttributes[EntityAttributes["NoShare"] = 8192] = "NoShare";
            /// <summary>Resolves conflict by letting the device win.</summary>
            EntityAttributes[EntityAttributes["ConflictDeviceWins"] = 16384] = "ConflictDeviceWins";
            /// <summary>Resolves conflict by taking no action. User must decide.</summary>
            EntityAttributes[EntityAttributes["ConflictUserAction"] = 32768] = "ConflictUserAction";
            /// <summary>The database table has labels for lookup fields.</summary>
            EntityAttributes[EntityAttributes["HasLookupLabels"] = 1048576] = "HasLookupLabels";
        })(EntityAttributes = Data.EntityAttributes || (Data.EntityAttributes = {}));
        var MetaProperty = (function () {
            function MetaProperty(name, type, targets) {
                this.name = name;
                this.type = type;
                this.targets = targets;
                this.permissions = PropertyPermission.Read;
                this.defaultValue = null;
            }
            Object.defineProperty(MetaProperty.prototype, "isVirtual", {
                get: function () {
                    return this.type == CrmType.State || this.type == CrmType.PartyList;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaProperty.prototype, "isReference", {
                get: function () {
                    return MetaProperty.isReferenceType(this.type);
                },
                enumerable: true,
                configurable: true
            });
            MetaProperty.isReferenceType = function (type) {
                return type == CrmType.Lookup || type == CrmType.Customer || type == CrmType.Owner;
            };
            Object.defineProperty(MetaProperty.prototype, "isNullable", {
                get: function () {
                    return this.required != CrmLevel.SystemRequired && (this.defaultValue === null || this.defaultValue === undefined);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaProperty.prototype, "activityPartyType", {
                get: function () {
                    if (this.m_activityPartyType == ParticipationTypeCode.XrmUseFieldName) {
                        return this.name;
                    }
                    if (!this.m_activityPartyType) {
                        switch (this.name) {
                            case "requiredattendees":
                                this.m_activityPartyType = ParticipationTypeCode.Requiredattendee;
                                break;
                            case "optionalattendees":
                                this.m_activityPartyType = ParticipationTypeCode.Optionalattendee;
                                break;
                            case "organizer":
                                this.m_activityPartyType = ParticipationTypeCode.Organizer;
                                break;
                            case "bcc":
                                this.m_activityPartyType = ParticipationTypeCode.BccRecipient;
                                break;
                            case "cc":
                                this.m_activityPartyType = ParticipationTypeCode.CcRecipient;
                                break;
                            case "to":
                                this.m_activityPartyType = ParticipationTypeCode.ToRecipient;
                                break;
                            case "from":
                                this.m_activityPartyType = ParticipationTypeCode.Sender;
                                break;
                            case "resources":
                                this.m_activityPartyType = ParticipationTypeCode.Resource;
                                break;
                            case "customer":
                            case "customers":
                                this.m_activityPartyType = ParticipationTypeCode.Customer;
                                break;
                            case "partner":
                            case "partners":
                                this.m_activityPartyType = ParticipationTypeCode.Partner;
                                break;
                            case "ownerid":
                                this.m_activityPartyType = ParticipationTypeCode.Owner;
                                break;
                            case "regardingobjectid":
                                this.m_activityPartyType = ParticipationTypeCode.Regarding;
                                break;
                        }
                    }
                    return this.m_activityPartyType;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaProperty.prototype, "isMultiParty", {
                get: function () {
                    switch (this.activityPartyType) {
                        case "7":
                        case "organizer":
                        case "from":
                        case "1":
                        case "11":
                        case "customer":
                            return false;
                    }
                    return true;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaProperty.prototype, "isSingularParty", {
                get: function () {
                    return this.isReference && (this.name == "ownerid" || this.name == "regardingobjectid");
                },
                enumerable: true,
                configurable: true
            });
            MetaProperty.loadMetaProperty = function (config, version, isXrm) {
                var prop = new MetaProperty(config[0], parseInt(config[2]));
                prop.required = parseInt(config[1]);
                if (config[3]) {
                    switch (prop.type) {
                        case CrmType.Boolean:
                            prop.defaultValue = config[3] !== "0";
                            break;
                        default:
                            prop.defaultValue = config[3]; // TODO: other types??? qe?
                            break;
                    }
                }
                if (config[4]) {
                    prop.minimum = parseFloat(config[4]);
                }
                if (config[5]) {
                    prop.maximum = parseFloat(config[5]);
                }
                if (config[6]) {
                    prop.format = parseInt(config[6]);
                }
                var nextIndex = 7;
                if (version >= 30) {
                    if (config[7]) {
                        prop.precision = parseInt(config[7]);
                    }
                    prop.permissions = parseInt(config[8]);
                    nextIndex = 9;
                }
                else {
                    prop.precision = 2;
                    prop.permissions = PropertyPermission.All;
                }
                if (config[nextIndex]) {
                    prop.targets = new Array();
                    for (var i = nextIndex; i < config.length; i++) {
                        prop.targets.push(config[i]);
                    }
                }
                if (isXrm) {
                    prop.m_activityPartyType = ParticipationTypeCode.XrmUseFieldName;
                    if (prop.name == "ownerid") {
                        prop.type = CrmType.Owner;
                    }
                }
                return prop;
            };
            MetaProperty.prototype.clone = function () {
                var p = new MetaProperty(this.name, this.type, this.targets);
                p.permissions = this.permissions;
                p.defaultValue = this.defaultValue;
                p.minimum = this.minimum;
                p.maximum = this.maximum;
                p.precision = this.precision;
                p.format = this.format;
                p.entity = this.entity;
                return p;
            };
            return MetaProperty;
        }());
        Data.MetaProperty = MetaProperty;
        var MetaEntity = (function () {
            function MetaEntity(entityName, primaryKey, primaryField, objectTypeCode, attributes) {
                this.m_name = entityName;
                this.m_primaryKeyName = primaryKey;
                this.m_primaryFieldName = primaryField;
                this.m_objectTypeCode = objectTypeCode;
                this.m_attributes = attributes;
                this.m_properties = new Resco.Dictionary();
                this.isEnabled = true;
                this.m_uploadOnly = (entityName == "resco_mobileaudit" || entityName == "resco_chatpost" || entityName == "resco_chatcomment");
                if ((this.attributes & EntityAttributes.IsIntersect) != 0) {
                    this.m_primaryFieldName = null;
                    if (!primaryField) {
                        primaryField = entityName;
                    }
                    this.m_realtionshipName = primaryField;
                }
                if ((this.attributes & EntityAttributes.IsActivity) != 0) {
                    if (objectTypeCode != 4211 &&
                        objectTypeCode != 4406 &&
                        objectTypeCode != 4209 &&
                        objectTypeCode != 4251 &&
                        objectTypeCode != 4206 &&
                        objectTypeCode != 4208) {
                        this.m_attributes |= EntityAttributes.IsRegularActivity;
                    }
                }
            }
            Object.defineProperty(MetaEntity.prototype, "properties", {
                get: function () {
                    return this.m_properties;
                },
                enumerable: true,
                configurable: true
            });
            MetaEntity.prototype.findProperty = function (key) {
                return this.m_properties.getValue(key);
            };
            MetaEntity.prototype.getProperty = function (index) {
                return this.m_properties.getIndex(index);
            };
            MetaEntity.prototype.indexOf = function (propertyName) {
                return this.m_properties.indexOfKey(propertyName);
            };
            Object.defineProperty(MetaEntity.prototype, "primaryKeyName", {
                get: function () {
                    return this.m_primaryKeyName;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "primaryFieldName", {
                get: function () {
                    return this.m_primaryFieldName;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "statusFieldName", {
                get: function () {
                    var prop = this.statusField;
                    return prop ? prop.name : null;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "primaryKey", {
                get: function () {
                    return this.findProperty(this.m_primaryKeyName);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "primaryField", {
                get: function () {
                    return this.findProperty(this.m_primaryFieldName);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "statusField", {
                get: function () {
                    var props = this.m_properties.getValues();
                    for (var i = 0; i < props.length; i++) {
                        var prop = props[i];
                        if (prop.type == CrmType.Status || prop.name == "statuscode") {
                            return prop;
                        }
                    }
                    return null;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "name", {
                get: function () {
                    return this.m_name;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "objectTypeCode", {
                get: function () {
                    return this.m_objectTypeCode;
                },
                set: function (value) {
                    this.m_objectTypeCode = value;
                },
                enumerable: true,
                configurable: true
            });
            MetaEntity.prototype.add = function (prop) {
                prop.entity = this;
                this.m_properties.set(prop.name, prop);
                if (prop.type == CrmType.Status) {
                    this.add(new MetaProperty("statecode", CrmType.State));
                }
            };
            Object.defineProperty(MetaEntity.prototype, "realtionshipName", {
                get: function () {
                    return this.m_realtionshipName;
                },
                enumerable: true,
                configurable: true
            });
            MetaEntity.prototype.canRead = function () {
                return this._getDepth(EntityPermission.Read) != 0;
            };
            MetaEntity.prototype.canWrite = function () {
                return this._getDepth(EntityPermission.Write) != 0;
            };
            MetaEntity.prototype.canCreate = function () {
                return this._getDepth(EntityPermission.Create) != 0;
            };
            MetaEntity.prototype.canDelete = function () {
                return this._getDepth(EntityPermission.Delete) != 0;
            };
            MetaEntity.prototype.canAppendTo = function (child) {
                return this._getDepth(EntityPermission.AppendTo) != 0; //Metadata.entities.find(child)._getDepth(EntityPermission.Append) != 0;
            };
            MetaEntity.prototype._getDepth = function (permission) {
                var p = this.permissionMask;
                var m = permission * 4;
                var d = (p >> m) & 0xF;
                var disabled = (this.attributes & (EntityAttributes.NoRead << permission)) != 0;
                if (disabled) {
                    d = 0;
                }
                return d;
            };
            Object.defineProperty(MetaEntity.prototype, "uploadOnly", {
                get: function () {
                    return this.m_uploadOnly;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(MetaEntity.prototype, "attributes", {
                get: function () {
                    return this.m_attributes;
                },
                enumerable: true,
                configurable: true
            });
            return MetaEntity;
        }());
        Data.MetaEntity = MetaEntity;
        var ParticipationTypeCode;
        (function (ParticipationTypeCode) {
            /// <summary>Placeholder signaling that instead of the numeric value then field name should be used (Invalid).</summary>
            ParticipationTypeCode[ParticipationTypeCode["XrmUseFieldName"] = -1] = "XrmUseFieldName";
            /// <summary>None (Invalid)</summary>
            ParticipationTypeCode[ParticipationTypeCode["Invalid"] = 0] = "Invalid";
            /// <summary>BccRecipient</summary>
            ParticipationTypeCode[ParticipationTypeCode["BccRecipient"] = 4] = "BccRecipient";
            /// <summary>CcRecipient</summary>
            ParticipationTypeCode[ParticipationTypeCode["CcRecipient"] = 3] = "CcRecipient";
            /// <summary>Customer</summary>
            ParticipationTypeCode[ParticipationTypeCode["Customer"] = 11] = "Customer";
            /// <summary>Optionalattendee</summary>
            ParticipationTypeCode[ParticipationTypeCode["Optionalattendee"] = 6] = "Optionalattendee";
            /// <summary>Organizer</summary>
            ParticipationTypeCode[ParticipationTypeCode["Organizer"] = 7] = "Organizer";
            /// <summary>Owner</summary>
            ParticipationTypeCode[ParticipationTypeCode["Owner"] = 9] = "Owner";
            /// <summary>Partner</summary>
            ParticipationTypeCode[ParticipationTypeCode["Partner"] = 12] = "Partner";
            /// <summary>Regarding</summary>
            ParticipationTypeCode[ParticipationTypeCode["Regarding"] = 8] = "Regarding";
            /// <summary>Requiredattendee</summary>
            ParticipationTypeCode[ParticipationTypeCode["Requiredattendee"] = 5] = "Requiredattendee";
            /// <summary>Resource</summary>
            ParticipationTypeCode[ParticipationTypeCode["Resource"] = 10] = "Resource";
            /// <summary>Sender</summary>
            ParticipationTypeCode[ParticipationTypeCode["Sender"] = 1] = "Sender";
            /// <summary>ToRecipient</summary>
            ParticipationTypeCode[ParticipationTypeCode["ToRecipient"] = 2] = "ToRecipient";
        })(ParticipationTypeCode = Data.ParticipationTypeCode || (Data.ParticipationTypeCode = {}));
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
