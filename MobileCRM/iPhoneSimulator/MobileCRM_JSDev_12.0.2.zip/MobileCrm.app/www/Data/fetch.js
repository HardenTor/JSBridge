/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="metaEntity.ts" />
/// <reference path="metaData.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var Data;
    (function (Data) {
        var Fetch;
        (function (Fetch_1) {
            // TODO: MetaData
            var Condition = (function () {
                function Condition() {
                }
                Object.defineProperty(Condition.prototype, "serializedValue", {
                    get: function () {
                        var strVal = this.value ? this.value.toString() : "";
                        return strVal ? strVal.replace("\"", "\\\"") : "";
                    },
                    set: function (value) {
                        this.value = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                /*static deserializeJSON(jsonCodnition: any): Fetch.Condition {
                    var c = new Condition();
                    if (jsonCodnition.attribute) {
                        c.attribute = jsonCodnition.attribute;
                    }
                    if (jsonCodnition.operator) {
                        c.operator = jsonCodnition.operator;
                    }
                    if (jsonCodnition.refTarget) {
                        c.refTarget = jsonCodnition.refTarget;
                    }
                    if (jsonCodnition.refLabel) {
                        c.refLabel = jsonCodnition.refLabel;
                    }
                    c.value = jsonCodnition.value;
                    if (jsonCodnition.values) {
                        c.values = jsonCodnition.values;
                    }
                    return c;
                }
        
                public serializeJSON(): string {
                    var result = "{";
                    if (this.attribute) {
                        result += "\"attribute\":\"" + this.attribute + "\",";
                    }
                    if (this.operator) {
                        result += "\"operator\":\"" + this.operator + "\",";
                    }
                    if (!this.values || this.values.length == 0) {
                        result += "\"value\":\"" + this.serializedValue + "\",";
                    }
                    if (this.refLabel) {
                        result += "\"refLabel\":\"" + this.refLabel + "\",";
                    }
                    if (this.refTarget) {
                        result += "\"refTarget\":\"" + this.refTarget + "\",";
                    }
                    if (!this.values && this.values.length > 0) {
                        result += "\"values\":[";
                        this.values.forEach((value) => {
                            result += "\"" + value + "\",";
                        }, this);
                        result = result.substring(0, result.length - 1) + "]";
                    }
                    else if (result.length > 1) {
                        result = result.substr(0, result.length - 1);
                    }
                    result += "}";
                    return result;
        
                    return result;
                }*/
                Condition.prototype.serializeXML = function () {
                    var result = "<condition attribute=\"" + this.attribute + "\" operator=\"" + this.operator + "\"";
                    if (!this.values || this.values.length == 0) {
                        result += " value=\"" + this.serializedValue + "\"";
                    }
                    if (this.refTarget) {
                        result += " uitype=\"" + this.refTarget + "\"";
                    }
                    if (this.refLabel) {
                        result += " uiname=\"" + this.refLabel + "\"";
                    }
                    if (this.entityName) {
                        result += " entityname=\"" + this.entityName + "\"";
                    }
                    result += ">";
                    if (this.values) {
                        this.values.forEach(function (value) {
                            // TODO: handle DateTime
                            result += "<value>" + value.toString() + "</value>";
                        }, this);
                    }
                    result += "</condition>";
                    return result;
                };
                Condition.deserializeXML = function ($cond) {
                    var cond = new Condition();
                    cond.attribute = $cond.attr("attribute");
                    cond.operator = $cond.attr("operator");
                    cond.refTarget = $cond.attr("uitype");
                    cond.refLabel = $cond.attr("uiname");
                    cond.entityName = $cond.attr("entityname");
                    var valueChildren = $cond.children("value");
                    if (valueChildren.length > 0) {
                        cond.values = new Array();
                        valueChildren.each(function (index, elem) {
                            cond.values.push($(elem).text());
                        });
                    }
                    else {
                        cond.value = $cond.attr("value");
                    }
                    return cond;
                };
                Condition.prototype.clone = function () {
                    var c = new Condition();
                    c.attribute = this.attribute;
                    c.operator = this.operator;
                    c.value = this.value;
                    c.refTarget = this.refTarget;
                    c.refLabel = this.refLabel;
                    c.entityName = this.entityName;
                    c.values = this.values.slice(0);
                    return c;
                };
                Object.defineProperty(Condition.prototype, "isNop", {
                    get: function () {
                        if (!this.value && this.operator == "like" || this.operator == "not-like") {
                            return this.value == "%" || this.value == "%%";
                        }
                        return false;
                    },
                    enumerable: true,
                    configurable: true
                });
                return Condition;
            }());
            Fetch_1.Condition = Condition;
            var Order = (function () {
                function Order() {
                }
                Order.prototype.clone = function () {
                    var o = new Order();
                    o.attribute = this.attribute;
                    o.alias = this.alias;
                    o.descending = this.descending;
                    return o;
                };
                Object.defineProperty(Order.prototype, "isDescending", {
                    get: function () {
                        return this.descending == "1" || this.descending == "true";
                    },
                    set: function (value) {
                        this.descending = value ? "1" : "0";
                    },
                    enumerable: true,
                    configurable: true
                });
                Order.prototype.serializeXML = function () {
                    var result = "<order ";
                    if (this.attribute) {
                        result += "attribute=\"" + this.attribute + "\" ";
                    }
                    if (this.descending) {
                        result += "descending=\"" + this.descending + "\" ";
                    }
                    if (this.alias) {
                        result += "alias=\"" + this.alias + "\" ";
                    }
                    result += "/>";
                    return result;
                };
                Order.deserializeXML = function ($order) {
                    var order = new Order();
                    order.attribute = $order.attr("attribute");
                    order.descending = $order.attr("descending");
                    order.alias = $order.attr("alias");
                    return order;
                };
                return Order;
            }());
            Fetch_1.Order = Order;
            var Filter = (function () {
                function Filter() {
                }
                Object.defineProperty(Filter.prototype, "isEmpty", {
                    get: function () {
                        return (!this.conditions || this.conditions.length == 0) && (!this.filters || this.filters.length == 0);
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Filter.prototype, "operator", {
                    get: function () {
                        return this.m_operator ? this.m_operator : "and";
                    },
                    set: function (value) {
                        this.m_operator = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Filter.prototype.clone = function () {
                    var clone = new Filter();
                    clone.operator = this.operator;
                    if (this.conditions) {
                        clone.conditions = this.conditions.slice(0);
                    }
                    if (this.filters) {
                        clone.filters = this.filters.slice(0);
                    }
                    return clone;
                };
                Filter.prototype.clear = function () {
                    if (this.filters) {
                        this.filters.splice(0);
                    }
                    if (this.conditions) {
                        this.conditions.splice(0);
                    }
                };
                Filter.prototype._addCondition = function (condition) {
                    if (!this.conditions) {
                        this.conditions = new Array();
                    }
                    this.conditions.push(condition);
                };
                Filter.prototype.where = function (attribute, value, op) {
                    if (!op) {
                        op = "eq";
                    }
                    else if (value instanceof Array) {
                        if (op == "in") {
                            return this.In(attribute, value);
                        }
                        else if (op == "not-in") {
                            return this.NotIn(attribute, value);
                        }
                    }
                    var c = new Condition();
                    c.attribute = attribute;
                    c.operator = op;
                    c.value = value;
                    this._addCondition(c);
                    return c;
                };
                Filter.prototype.startsWith = function (attribute, value) {
                    if (!value) {
                        value = "";
                    }
                    return this.where(attribute, value + "%", "like");
                };
                Filter.prototype.contains = function (attribute, value) {
                    if (!value) {
                        value = "";
                    }
                    return this.where(attribute, "%" + value + "%", "like");
                };
                Filter.prototype.In = function (attribute, list) {
                    var values = new Array();
                    if (list) {
                        values = list.slice(0);
                    }
                    if (values.length == 0)
                        return undefined;
                    if (values.length == 1) {
                        return this.where(attribute, values[0]);
                    }
                    var c = new Condition();
                    c.attribute = attribute;
                    c.operator = "in";
                    c.values = values;
                    this._addCondition(c);
                    return c;
                };
                Filter.prototype.NotIn = function (attribute, list) {
                    var values = new Array();
                    if (list) {
                        values = list.slice(0);
                    }
                    if (values.length == 0)
                        return undefined;
                    var c = new Condition();
                    c.attribute = attribute;
                    c.operator = "not-in";
                    c.values = values;
                    this._addCondition(c);
                    return c;
                };
                Filter.prototype.isCurrentUser = function (attribute) {
                    return this.where(attribute, null, "eq-userid");
                };
                Filter.prototype.between = function (attribute, low, high) {
                    var c = new Condition();
                    c.attribute = attribute;
                    c.operator = "between";
                    c.values = new Array(low, high);
                    this._addCondition(c);
                    return c;
                };
                Filter.prototype._addFilter = function (op) {
                    if (!this.filters) {
                        this.filters = new Array();
                    }
                    var f = new Filter();
                    f.operator = op;
                    this.filters.push(f);
                    return f;
                };
                Filter.prototype.and = function () {
                    return this._addFilter("and");
                };
                Filter.prototype.or = function () {
                    return this._addFilter("or");
                };
                Filter.prototype.applySearchText = function (text) {
                    var result = false;
                    if (this.conditions) {
                        this.conditions.forEach(function (c) {
                            if (c.value && (c.operator == "like" || c.operator == "not-like")) {
                                if (c.value.indexOf(Filter.searchFilterPlaceholder) >= 0) {
                                    c.value = c.value.replace(Filter.searchFilterPlaceholder, text ? text : "");
                                    result = true;
                                }
                            }
                        }, this);
                    }
                    if (this.filters) {
                        this.filters.forEach(function (f) {
                            result = result || f.applySearchText(text);
                        }, this);
                    }
                    return result;
                };
                /*static deserializeJSON(jsonFilter: any): Filter {
                    var f = new Filter();
        
                    if (jsonFilter.conditions) {
                        jsonFilter.conditions.forEach((jsonCondition: any) => {
                            f._addCondition(Condition.deserializeJSON(jsonCondition));
                        }, this);
                    }
                    if (jsonFilter.operator) {
                        f.operator = jsonFilter.operator;
                    }
                    if (jsonFilter.filters && jsonFilter.filters.length > 0) {
                        f.filters = new Array<Filter>()
                        jsonFilter.filters.forEach((jsonFilter: any) => {
                            f.filters.push(Filter.deserializeJSON(jsonFilter));
                        }, this);
                    }
        
                    return f;
                }
        
                public serializeJSON(): string {
                    var bFirstItem: boolean = true;
                    var result = "{\"operator\":\"" + this.operator + "\", \"conditions\":[";
                    if (this.conditions) {
                        this.conditions.forEach((cond) => {
                            if (!bFirstItem) {
                                result += ",";
                            }
                            else {
                                bFirstItem = false;
                            }
                            result += cond.serializeJSON();
                        }, this);
                    }
        
                    result += "], \"filters\":[";
                    if (this.filters) {
                        this.filters.forEach((filter) => {
                            if (!bFirstItem) {
                                result += ",";
                            }
                            else {
                                bFirstItem = false;
                            }
                            result += filter.serializeJSON();
                        }, this);
                    }
        
                    result += "]}";
                    return result;
                }*/
                Filter.prototype.serializeXML = function () {
                    var result = "<filter type=\"" + this.operator + "\">";
                    if (this.conditions) {
                        this.conditions.forEach(function (cond) {
                            result += cond.serializeXML();
                        });
                    }
                    if (this.filters) {
                        this.filters.forEach(function (filter) {
                            result += filter.serializeXML();
                        });
                    }
                    result += "</filter>";
                    return result;
                };
                Filter.deserializeXML = function ($filter) {
                    var filter = new Filter();
                    filter.operator = $filter.attr("type");
                    var condChildren = $filter.children("condition");
                    if (condChildren.length > 0) {
                        filter.conditions = new Array();
                        condChildren.each(function (index, elem) {
                            filter.conditions.push(Condition.deserializeXML($(elem)));
                        });
                    }
                    var filterChildren = $filter.children("filter");
                    if (filterChildren.length > 0) {
                        filter.filters = new Array();
                        filterChildren.each(function (index, elem) {
                            filter.filters.push(Filter.deserializeXML($(elem)));
                        });
                    }
                    return filter;
                };
                return Filter;
            }());
            Filter.searchFilterPlaceholder = "@@filter@@";
            Fetch_1.Filter = Filter;
            var Attribute = (function () {
                function Attribute(meta) {
                    if (meta) {
                        this.metaProperty = meta;
                        this.name = meta.name;
                        this.fullName = meta.name;
                    }
                }
                Attribute.prototype.getMetaProperty = function (parent) {
                    if (!this.metaProperty && parent.meta) {
                        this.metaProperty = parent.meta.findProperty(this.name);
                    }
                    return this.metaProperty;
                };
                Attribute.prototype.clone = function () {
                    var clone = new Attribute();
                    clone.name = this.name;
                    clone.aggregate = this.aggregate;
                    clone.groupBy = this.groupBy;
                    clone.alias = this.alias;
                    clone.dateGrouping = this.dateGrouping;
                    clone.fullName = this.fullName;
                    clone.lazyLookup = this.lazyLookup;
                    clone.metaProperty = this.metaProperty;
                    return clone;
                };
                /*static deserializeJSON(jsonAttr: any, attr: Attribute) {
                    attr.name = jsonAttr.name;
                    attr.aggregate = jsonAttr.aggregate;
                    attr.groupBy = jsonAttr.groupby == "1";
                    attr.alias = jsonAttr.alias;
                    attr.dateGrouping = jsonAttr.dategrouping;
                }
        
                public serializeJSON(): string {
                    var result = "{\"name\":\"" + this.name + "\"";
        
                    if (this.aggregate) {
                        result += ", \"aggregate\":\"" + this.aggregate + "\"";
                    }
                    if (this.groupBy) {
                        result += ", \"groupby\":\"" + (this.groupBy ? 1 : 0) + "\"";
                    }
                    if (this.alias) {
                        result += ", \"alias\":\"" + this.alias + "\"";
                    }
                    if (this.dateGrouping) {
                        result += ", \"dategrouping\":\"" + this.dateGrouping + "\"";
                    }
                    result += "}";
                    return result;
                }*/
                Attribute.prototype.serializeXML = function () {
                    var result = "<attribute name=\"" + this.name + "\" ";
                    if (this.aggregate) {
                        result += "aggregate=\"" + this.aggregate + "\" ";
                    }
                    if (this.groupBy) {
                        result += "groupby=\"" + (this.groupBy ? "true" : "false") + "\" ";
                    }
                    if (this.alias) {
                        result += "alias=\"" + this.alias + "\" ";
                    }
                    if (this.dateGrouping) {
                        result += "dategrouping=\"" + this.dateGrouping + "\" ";
                    }
                    result += "/>";
                    return result;
                };
                Attribute.deserializeXML = function ($attr) {
                    var attr = new Attribute();
                    attr.name = $attr.attr("name");
                    attr.alias = $attr.attr("alias");
                    attr.aggregate = $attr.attr("aggregate");
                    attr.groupBy = Fetch.deserializeBoolean($attr.attr("groupby"));
                    attr.dateGrouping = $attr.attr("dategrouping");
                    return attr;
                };
                return Attribute;
            }());
            Fetch_1.Attribute = Attribute;
            var Entity = (function () {
                function Entity() {
                }
                Object.defineProperty(Entity.prototype, "name", {
                    get: function () {
                        return this.m_name;
                    },
                    set: function (value) {
                        this.m_name = value;
                        if (this.m_meta && this.m_meta.name != value) {
                            this.m_meta = null;
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Object.defineProperty(Entity.prototype, "meta", {
                    get: function () {
                        if (!this.m_meta) {
                            this.m_meta = Data.MetaData.instance.tryGetEntity(this.name);
                        }
                        return this.m_meta;
                    },
                    set: function (value) {
                        this.m_meta = value;
                        if (this.m_meta) {
                            this.m_name = this.m_meta.name;
                        }
                    },
                    enumerable: true,
                    configurable: true
                });
                Entity.prototype._serializeStartEntityNode = function () {
                    return "<entity name=\"" + this.name + "\">";
                };
                Entity.prototype._serializeEndEntityNode = function () {
                    return "</entity>";
                };
                Entity.prototype.serializeXML = function () {
                    var result = this._serializeStartEntityNode();
                    if (this.attributes) {
                        this.attributes.forEach(function (attr) {
                            result += attr.serializeXML();
                        });
                    }
                    if (this.filter) {
                        result += this.filter.serializeXML();
                    }
                    if (this.links) {
                        this.links.forEach(function (link) {
                            result += link.serializeXML();
                        }, this);
                    }
                    if (this.orders) {
                        this.orders.forEach(function (order) {
                            result += order.serializeXML();
                        });
                    }
                    result += this._serializeEndEntityNode();
                    return result;
                };
                Entity.deserializeXML = function ($entity) {
                    var entity = new Entity();
                    entity._deserializeXML($entity);
                    return entity;
                };
                Entity.prototype._deserializeXML = function ($entity) {
                    var _this = this;
                    this.name = $entity.attr("name");
                    var attrChildren = $entity.children("attribute");
                    if (attrChildren.length > 0) {
                        this.attributes = new Array();
                        attrChildren.each(function (index, elem) {
                            _this.attributes.push(Attribute.deserializeXML($(elem)));
                        });
                    }
                    var linkChildren = $entity.children("link-entity");
                    if (linkChildren.length > 0) {
                        this.links = new Array();
                        linkChildren.each(function (index, elem) {
                            _this.links.push(LinkEntity.deserializeXML($(elem)));
                        });
                    }
                    var orderChildren = $entity.children("order");
                    if (orderChildren.length > 0) {
                        this.orders = new Array();
                        orderChildren.each(function (index, elem) {
                            _this.orders.push(Order.deserializeXML($(elem)));
                        });
                    }
                    var filterChildren = $entity.children("filter");
                    if (filterChildren.length > 0) {
                        this.filter = Filter.deserializeXML($(filterChildren[0]));
                    }
                };
                /*public serializeJSON(): string {
                    var result: string;
                    var bFirstItem: boolean = true;
        
                    result = "{\"name\":\"" + this.name + "\", \"attributes\":[";
                    if (this.attributes) {
                        this.attributes.forEach((attr) => {
                            if (!bFirstItem) {
                                result += ",";
                            }
                            else {
                                bFirstItem = false;
                            }
        
                            result += attr.serializeJSON();
                        }, this);
                        bFirstItem = true;
                    }
        
                    result += "], \"filters\":[";
                    if (this.filter) {
                        result += this.filter.serializeJSON();
                    }
        
                    result += "], \"orders\":[";
                    if (this.orders) {
                        this.orders.forEach((order) => {
                            if (!bFirstItem) {
                                result += ",";
                            }
                            else {
                                bFirstItem = false;
                            }
        
                            result += order.serializeJSON();
                        }, this);
                    }
        
                    result += "]}";
                    return result;
                }*/
                Entity.prototype.addAttribute = function (attribute, isLazy) {
                    if (!this.attributes) {
                        this.attributes = new Array();
                    }
                    var attr = new Attribute();
                    attr.name = attribute;
                    attr.lazyLookup = isLazy;
                    this.attributes.push(attr);
                    return attr;
                };
                Entity.prototype.addAttributes = function (meta, filter, isLazy) {
                    var _this = this;
                    if (meta === void 0) { meta = this.meta; }
                    if (filter === void 0) { filter = null; }
                    if (isLazy === void 0) { isLazy = true; }
                    if (!this.attributes) {
                        this.attributes = new Array();
                    }
                    meta.properties.getValues().forEach(function (prop) {
                        var attr = new Attribute();
                        attr.name = prop.name;
                        attr.metaProperty = prop;
                        attr.lazyLookup = isLazy;
                        _this.attributes.push(attr);
                    }, this);
                };
                Entity.prototype.setLookupLazy = function (lazy) {
                    var names = [];
                    for (var _i = 1; _i < arguments.length; _i++) {
                        names[_i - 1] = arguments[_i];
                    }
                    if (this.attributes) {
                        this.attributes.forEach(function (attr) {
                            var attrName = attr.name;
                            for (var i = 0; i < names.length; i++) {
                                if (attrName == names[i]) {
                                    attr.lazyLookup = lazy;
                                    break;
                                }
                            }
                        }, this);
                    }
                };
                Entity.prototype.orderBy = function (attribute, descending) {
                    if (!this.orders) {
                        this.orders = new Array();
                    }
                    var order = new Order();
                    order.attribute = attribute;
                    order.isDescending = descending;
                    this.orders.push(order);
                };
                Object.defineProperty(Entity.prototype, "filter", {
                    get: function () {
                        if (!this.m_filter) {
                            var f = new Filter();
                            f.operator = "and";
                            this.m_filter = f;
                        }
                        return this.m_filter;
                    },
                    set: function (value) {
                        this.m_filter = value;
                    },
                    enumerable: true,
                    configurable: true
                });
                Entity.prototype.addLink = function (target, from, to, linkType, reuse) {
                    if (reuse === void 0) { reuse = true; }
                    if (this.links) {
                        if (reuse) {
                            for (var i = 0; i < this.links.length; i++) {
                                var l = this.links[i];
                                if (l.name.toLowerCase() == target.toLowerCase() &&
                                    l.from.toLowerCase() == from.toLowerCase() &&
                                    l.to.toLowerCase() == to.toLowerCase()) {
                                    if (linkType === "inner" || linkType === "outer") {
                                        continue;
                                    }
                                    return l;
                                }
                            }
                        }
                    }
                    else {
                        this.links = new Array();
                    }
                    var link = new LinkEntity();
                    link.name = target;
                    link.from = from;
                    link.to = to;
                    link.linkType = linkType;
                    this.links.push(link);
                    return link;
                };
                Entity.prototype.copyTo = function (clone) {
                    clone.m_meta = this.m_meta;
                    clone.name = this.name;
                    if (this.attributes) {
                        clone.attributes = new Array();
                        this.attributes.forEach(function (attr) {
                            clone.attributes.push(attr.clone());
                        }, this);
                    }
                    clone.filter = this.filter.clone();
                    if (this.links) {
                        clone.links = new Array();
                        this.links.forEach(function (link) {
                            clone.links.push(link.clone());
                        }, this);
                    }
                    if (this.orders) {
                        clone.orders = new Array();
                        this.orders.forEach(function (order) {
                            clone.orders.push(order.clone());
                        }, this);
                    }
                };
                Entity.prototype.clone = function () {
                    var clone = new Entity();
                    this.copyTo(clone);
                    return clone;
                };
                Object.defineProperty(Entity.prototype, "isSubset", {
                    get: function () {
                        if (!this.filter.isEmpty) {
                            return true;
                        }
                        if (this.links) {
                            for (var i = 0; i < this.links.length; i++) {
                                if (this.links[i].linkType != "outer") {
                                    return true;
                                }
                            }
                        }
                        return false;
                    },
                    enumerable: true,
                    configurable: true
                });
                //public applyMacros(related: DynamicEntity, resolveMacro?: (s: string) => any): void {
                //    if (!resolveMacro) {
                //        resolveMacro = (propertyName: string) => {
                //            if (propertyName == "self") {
                //                return related.id;
                //            }
                //            return related.tryGetValue(propertyName).value;
                //        }
                //    }
                //    Entity._applyMacros(this.filter, resolveMacro);
                //    if (this.links) {
                //        this.links.forEach(l => l.applyMacros(related, resolveMacro));
                //    }
                //}
                Entity._applyMacros = function (filter, resolveMacro) {
                    if (filter.conditions) {
                        filter.conditions.forEach(function (c) { return Entity._updateValue(c, resolveMacro); });
                    }
                    if (filter.filters) {
                        filter.filters.forEach(function (f) { return Entity._applyMacros(f, resolveMacro); });
                    }
                };
                Entity._updateValue = function (c, resolveMacro) {
                    if (c.value) {
                        var v = Resco.asString(c.value);
                        if (Resco.notNull(v)) {
                            var b = v.indexOf("{{");
                            var e = v.indexOf("}}");
                            if (b >= 0 && e > b) {
                                var propertyName = v.substr(b + 2, e - b - 2);
                                var value = resolveMacro(propertyName);
                                if (value) {
                                    var r = value; // TODO: Reference.as(value);
                                    if (r) {
                                        value = r.id;
                                    }
                                    if (b > 0 || e + 2 != v.length) {
                                        value = v.substr(0, b) + value + v.substr(e); // TODO: check if correct
                                    }
                                }
                                c.value = value;
                                if (!value) {
                                    c.operator = "null";
                                }
                            }
                        }
                    }
                };
                Entity.prototype.applySearchText = function (text) {
                    var result = false;
                    if (this.m_filter) {
                        result = this.m_filter.applySearchText(text);
                    }
                    if (this.links) {
                        this.links.forEach(function (link) {
                            result = result || link.applySearchText(text);
                        }, this);
                    }
                    return result;
                };
                Entity.prototype.mergeFilter = function (e2) {
                    var _this = this;
                    var oldFilter = this.filter;
                    this.filter = new Filter();
                    this.filter.filters = [oldFilter, e2.filter];
                    if (e2.links) {
                        e2.links.forEach(function (link2) {
                            if (link2.linkType !== "outer") {
                                var link1 = _this.addLink(link2.name, link2.from, link2.to, link2.linkType, false);
                                link1.mergeFilter(link2);
                            }
                        }, this);
                    }
                };
                Entity.prototype.checkNeedsDistinct = function () {
                    if (this.links) {
                        var key = this._tryGetPrimaryKeyName();
                        for (var i = 0; i < this.links.length; i++) {
                            var link = this.links[i];
                            if (link.to == key || link.checkNeedsDistinct()) {
                                return true;
                            }
                        }
                    }
                    return false;
                };
                Entity.prototype._tryGetPrimaryKeyName = function () {
                    var meta = this.m_meta;
                    if (!meta) {
                        meta = Data.MetaData.instance.tryGetEntity(this.name);
                    }
                    return meta ? meta.primaryKeyName : "id";
                };
                return Entity;
            }());
            Fetch_1.Entity = Entity;
            var LinkEntity = (function (_super) {
                __extends(LinkEntity, _super);
                function LinkEntity() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                LinkEntity.prototype._serializeStartEntityNode = function () {
                    var result = "<link-entity name=\"" + this.name + "\" from=\"" + this.from + "\" to=\"" + this.to + "\" link-type=\"" + this.linkType + "\"";
                    if (this.alias) {
                        result += " alias=\"" + this.alias + "\"";
                    }
                    result += ">";
                    return result;
                };
                LinkEntity.prototype._serializeEndEntityNode = function () {
                    return "</link-entity>";
                };
                LinkEntity.deserializeXML = function ($linkEntity) {
                    var linkEntity = new LinkEntity();
                    linkEntity._deserializeXML($linkEntity);
                    return linkEntity;
                };
                LinkEntity.prototype._deserializeXML = function ($linkEntity) {
                    this.from = $linkEntity.attr("from");
                    this.to = $linkEntity.attr("to");
                    var linkType = $linkEntity.attr("link-type");
                    this.linkType = linkType ? linkType : "inner";
                    this.alias = $linkEntity.attr("alias");
                    _super.prototype._deserializeXML.call(this, $linkEntity);
                };
                LinkEntity.prototype.copyTo = function (clone) {
                    _super.prototype.copyTo.call(this, clone);
                    clone.from = this.from;
                    clone.to = this.to;
                    clone.linkType = this.linkType;
                    clone.alias = this.alias;
                };
                LinkEntity.prototype.clone = function () {
                    var clone = new LinkEntity();
                    this.copyTo(clone);
                    clone.from = this.from;
                    clone.to = this.to;
                    clone.linkType = this.linkType;
                    clone.alias = this.alias;
                    return clone;
                };
                return LinkEntity;
            }(Entity));
            Fetch_1.LinkEntity = LinkEntity;
            var Fetch = (function () {
                function Fetch(meta, entityName) {
                    if (meta || entityName) {
                        this.version = "1.0";
                        this.entity = new Entity();
                        this.entity.name = meta ? meta.name : entityName;
                        if (meta) {
                            this.entity.meta = meta;
                        }
                    }
                }
                Object.defineProperty(Fetch.prototype, "version", {
                    get: function () {
                        return "1.0";
                    },
                    set: function (value) {
                    },
                    enumerable: true,
                    configurable: true
                });
                Fetch.deserializeCollection = function (reader) {
                    return new Array();
                };
                Fetch.prototype.clone = function () {
                    var clone = new Fetch(null);
                    clone.isAggregate = this.isAggregate;
                    clone.entity = this.entity.clone();
                    clone.tag = this.tag;
                    return clone;
                };
                Fetch.prototype.checkNeedsDistinct = function () {
                    return this.entity && this.entity.checkNeedsDistinct();
                };
                Fetch.prototype.mergeFilter = function (source) {
                    this.entity.mergeFilter(source.entity);
                };
                Fetch.deserializeXML = function (xmlData) {
                    var f = new Fetch(null, "");
                    var xmlDoc = $.parseXML(xmlData);
                    var $fetch = $("fetch", xmlDoc);
                    f.count = Fetch.deserializeNumber($fetch.attr("count"));
                    f.page = Fetch.deserializeNumber($fetch.attr("page"));
                    f.page = Fetch.deserializeNumber($fetch.attr("min-active-row-version"));
                    var pagingCookie = $fetch.attr("paging-cookie");
                    if (pagingCookie) {
                        f.pagingCookie = pagingCookie.decodeXML();
                    }
                    f.isAggregate = Fetch.deserializeBoolean($fetch.attr("aggregate"));
                    f.version = $fetch.attr("version");
                    var children = $fetch.children("entity");
                    if (children.length == 1) {
                        f.entity = Entity.deserializeXML($(children[0]));
                    }
                    return f;
                };
                Fetch.deserializeNumber = function (strNumber) {
                    if (strNumber !== undefined && strNumber !== null) {
                        var result = Resco.strictParseInt(strNumber);
                        return isNaN(result) ? undefined : result;
                    }
                    return undefined;
                };
                Fetch.deserializeBoolean = function (strBoolean) {
                    if (strBoolean !== undefined && strBoolean !== null) {
                        return strBoolean === "true" || strBoolean === "1" || strBoolean === "True";
                    }
                    return undefined;
                };
                Fetch.deserializeJSON = function (data) {
                    if (data) {
                        return Fetch.deserializeXML(data);
                        /*var jsonFetch = JSON.parse(data);
                        var name = jsonFetch.entity.name;
                        var f = new Fetch(null, name);
        
                        if (jsonFetch.count) {
                            f.count = jsonFetch.count;
                        }
        
                        if (jsonFetch.entity.attributes) {
                            jsonFetch.entity.attributes.forEach((jsonAttr: any) => {
                                var attr = f.entity.addAttribute(jsonAttr.name, true);
                                Attribute.deserializeJSON(jsonAttr, attr);
                            }, this);
                        }
                        else {
                            // Add primaryName attribute
                            f.entity.addAttribute(f.entity.meta.primaryFieldName, true);
                        }
        
                        if (jsonFetch.entity.filters && jsonFetch.entity.filters.length > 0) {
                            f.entity.filter = Filter.deserializeJSON(jsonFetch.entity.filters[0]);
                        }
        
                        if (jsonFetch.entity.orders) {
                            f.entity.orders = new Array<Order>();
                            jsonFetch.entity.orders.forEach((jsonOrder: any) => {
                                f.entity.orders.push(Order.deserializeJSON(jsonOrder));
                            }, this);
                        }
                        return f;*/
                    }
                    return null;
                };
                Fetch.prototype.serializeJSON = function () {
                    return this.serializeXML();
                    /*var result = "{\"version\": \"" + this.version + "\", \"entity\":" + this.entity.serializeJSON();
                    if (this.count) {
                        result += ", \"count\":" + this.count;
                    }
                    result += "}";
                    return result;*/
                };
                Fetch.prototype.serializeXML = function () {
                    var result = "<fetch version=\"1.0\" page=\"" + (this.page ? this.page : 1) + "\" aggregate=\"" + (this.isAggregate ? "true" : "false") + "\" distinct=\"" + (this.isDistinct ? "1" : "0") + "\" ";
                    if (this.count != null && this.count != undefined && this.count >= 0) {
                        result += "count=\"" + this.count + "\" ";
                    }
                    if (this.pagingCookie) {
                        result += "paging-cookie=\"" + this.pagingCookie.encodeXML();
                        +"\" ";
                    }
                    if (this.minActiveRowVersion != null && this.minActiveRowVersion != undefined && this.minActiveRowVersion >= 0) {
                        result += "min-active-row-version=\"" + this.minActiveRowVersion + "\" ";
                    }
                    result += ">";
                    result += this.entity.serializeXML();
                    result += "</fetch>";
                    return result;
                };
                return Fetch;
            }());
            Fetch_1.Fetch = Fetch;
        })(Fetch = Data.Fetch || (Data.Fetch = {}));
    })(Data = MobileCrm.Data || (MobileCrm.Data = {}));
})(MobileCrm || (MobileCrm = {}));
