/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="Localization.ts" />
/// <reference path="MyRoute.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    /**
     * Implements the MyRoute item (one row of the MyRoute list).
     */
    var RouteItem = (function () {
        /**
         * Constructs the RouteItem object
         * @param entity A DynamicEntity (appointment?) associated with this item
         * @param prevEnd Observable end value of previous item (or start time)
         */
        function RouteItem(entity, prevEnd) {
            var _this = this;
            // Observables
            this.name = ko.observable();
            this.startDate = ko.observable();
            this.endDate = ko.observable();
            this.prevItemEndDate = null;
            this.routeDistance = ko.observable();
            this.routeTravelTime = ko.observable();
            this.isDirty = ko.observable();
            // Computed values
            this.travelTime = ko.computed(function () { return RoutePlanner.Localization.secondsToText(_this.routeTravelTime()); }, this);
            this.travelDistance = ko.computed(function () { return RoutePlanner.Localization.metersToText(_this.routeDistance()); }, this);
            this.startTime = ko.computed(function () { return RoutePlanner.Localization.formatDate(_this.startDate()); }, this);
            this.endTime = ko.computed(function () { return RoutePlanner.Localization.formatDate(_this.endDate()); }, this);
            this.arrivalTime = ko.computed(function () {
                var travelTime = _this.routeTravelTime();
                return _this.prevItemEndDate ? RoutePlanner.Localization.formatDate(new Date(_this.prevItemEndDate().getTime() + (travelTime + 59) * 1000)) : null;
            }, this);
            this.hasConflict = ko.computed(function () {
                var start = _this.startDate();
                var travelTime = _this.routeTravelTime();
                return _this.prevItemEndDate && (((start.getTime() - _this.prevItemEndDate().getTime()) / 1000) < travelTime);
            }, this);
            this.entity = entity;
            this.id = entity.id;
            this.name(entity.primaryName);
            this.prevItemEndDate = prevEnd;
            this.isDirty(entity.isNew);
            var props = entity.properties;
            this.startDate(props[RoutePlanner.Configuration.instance.startField]);
            var endDate = props[RoutePlanner.Configuration.instance.endField];
            this.endDate((typeof (this.endDate) == "number") ?
                new Date(this.startDate().getTime() + endDate * 60000) :
                endDate);
            this.name.subscribe(function (newVal) { return _this.updateField("", newVal); }, this);
            this.startDate.subscribe(function (newVal) { return _this.updateField(RoutePlanner.Configuration.instance.startField, RoutePlanner.Localization.formatDate(newVal, 24)); }, this);
            this.endDate.subscribe(function (newVal) { return _this.updateField(RoutePlanner.Configuration.instance.endField, RoutePlanner.Localization.formatDate(newVal, 24)); }, this);
        }
        RouteItem.prototype.delete = function () {
            MobileCRM.bridge.command("menuAction", "Delete:" + this.id);
        };
        RouteItem.prototype.save = function () {
            var _this = this;
            MobileCRM.bridge.command("menuAction", "Save:" + this.id, function (data) {
                RoutePlanner.MyRoute.instance.editor.close();
                _this.entity.isNew = false;
                _this.isDirty(false);
            });
        };
        RouteItem.prototype.changeStatus = function (status) {
            MobileCRM.bridge.command("menuAction", status + ":" + this.id);
        };
        RouteItem.prototype.showEntityForm = function () {
            MobileCRM.bridge.command("menuAction", "Edit:" + this.id);
        };
        RouteItem.prototype.updateField = function (field, value) {
            var data = [this.id, field, value];
            MobileCRM.bridge.command("updateEntity", JSON.stringify(data));
            this.isDirty(true);
        };
        /**
         * Click handler for RouteItem. Calls the native code to select the item on the map.
         */
        RouteItem.prototype.onClick = function () {
            MobileCRM.bridge.command("selectAnnotation", this.id);
            RoutePlanner.MyRoute.instance.editor.editItem(this);
        };
        RouteItem.prototype.dragEntity = function (dragStartIndex, id, dropIndex) {
            if (dragStartIndex != null && dropIndex != null) {
                var moveNum = dropIndex - dragStartIndex;
                MobileCRM.bridge.command('dragEntity', id + "," + moveNum);
            }
        };
        RouteItem.prototype.getId = function () {
            return this.id;
        };
        /**
         * Fix button click handler. Calls the native code to solve a time conflict with previous item (it moves item's start/end values).
         */
        RouteItem.prototype.onFixButtonClick = function () {
            if (RoutePlanner.Configuration.instance.viewingMode)
                return;
            var myRoute = RoutePlanner.MyRoute.instance;
            var index = myRoute.items().indexOf(this);
            MobileCRM.bridge.command("fixItemStart", index + ":" + myRoute.getStartTime(), function (data) {
                if (data) {
                    this.startDate(data[0]);
                    this.endDate(data[1]);
                }
            }, null, this);
        };
        return RouteItem;
    }());
    RoutePlanner.RouteItem = RouteItem;
})(RoutePlanner || (RoutePlanner = {}));
