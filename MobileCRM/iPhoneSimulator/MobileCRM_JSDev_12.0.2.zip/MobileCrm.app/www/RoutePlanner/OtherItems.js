/// <reference path="../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="../TypeScriptDefinitions/JSBridge.d.ts" />
/// <reference path="../TypeScriptDefinitions/knockout.d.ts" />
/// <reference path="Localization.ts" />
/// <reference path="ItemEditor.ts" />
var RoutePlanner;
(function (RoutePlanner) {
    /**
     * Helper class implementing the start/end location picker
     */
    var StartEndItem = (function () {
        function StartEndItem() {
            var _this = this;
            this.locationType = ko.observable(); // 0=CurrentLocation, 1=Home, 2=Work
            this.locationText = ko.computed(function () { return RoutePlanner.Localization.get(StartEndItem.keys[_this.locationType()]); }, this);
            this.routeStep = ko.observable(); // Only for end location
            // Computed values
            this.travelTime = ko.computed(function () { return (_this.routeStep() ? RoutePlanner.Localization.secondsToText(_this.routeStep().travelTime) : ""); }, this);
            this.travelDistance = ko.computed(function () { return (_this.routeStep() ? RoutePlanner.Localization.metersToText(_this.routeStep().distance) : ""); }, this);
        }
        /**
         * Initializes StartEndItem
         * @param type 0 for start location, 1 for end location
         * @param time Computable returning the start/end time
         */
        StartEndItem.prototype.init = function (type, time) {
            var _this = this;
            this.itemType = type;
            if (type == 0) {
                this.name = "Start";
                this.title = RoutePlanner.Localization.get("Msg.Start");
                this.listIconUrl = "images/icn-start.svg";
                this.iconBackground = '#92E699';
            }
            else {
                this.name = "End";
                this.title = RoutePlanner.Localization.get("Msg.End");
                this.listIconUrl = "images/icn-end.svg";
                this.iconBackground = '#B1D6FF';
            }
            this.time = time;
            this.timeText = ko.computed(function () { return RoutePlanner.Localization.formatDate(_this.time()); }, this);
        };
        StartEndItem.prototype.onClick = function () {
            RoutePlanner.MyRoute.instance.editor.editStartEnd(this);
        };
        return StartEndItem;
    }());
    StartEndItem.keys = ["Map.CurrentLocation", "RoutePlanner.Home", "RoutePlanner.Work"];
    RoutePlanner.StartEndItem = StartEndItem;
})(RoutePlanner || (RoutePlanner = {}));
