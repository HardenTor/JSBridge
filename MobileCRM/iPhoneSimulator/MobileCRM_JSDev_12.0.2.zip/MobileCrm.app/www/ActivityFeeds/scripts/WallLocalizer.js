Localizer = {
	resTable: {},
	entityTable: {},
	get: function (name) { return Localizer.resTable[name]; },
	getEntityName: function (name) {
		var texts = Localizer.entityTable[name];
		return texts ? texts[0] : null;
	},
	getEntityPlural: function (name) {
		var texts = Localizer.entityTable[name];
		return texts ? texts[1] : null;
	}
};
