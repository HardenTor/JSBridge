/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="stepCollection.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow_1) {
            var Workflow = (function (_super) {
                __extends(Workflow, _super);
                function Workflow() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                Workflow.prototype._getName = function () {
                    return "Workflow";
                };
                Workflow.prototype.decode = function () {
                    this.program = new Array();
                    _super.prototype.decode.call(this, this.program);
                };
                Workflow.deserializeXML = function ($workflow) {
                    var w = new Workflow();
                    w._deserializeXML($workflow);
                    return w;
                };
                Workflow.prototype._deserializeXML = function ($workflow) {
                    this.version = Resco.strictParseInt($workflow.attr("version"));
                    _super.prototype._deserializeXML.call(this, $workflow);
                };
                Workflow.as = function (obj) {
                    if (obj instanceof Workflow) {
                        return obj;
                    }
                    return null;
                };
                return Workflow;
            }(Workflow_1.StepCollection));
            Workflow_1.Workflow = Workflow;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
