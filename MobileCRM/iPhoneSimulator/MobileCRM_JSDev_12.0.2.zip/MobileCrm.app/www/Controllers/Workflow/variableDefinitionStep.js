/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="functionStep.ts" />
/// <reference path="variable.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var VariableDefinitionStep = (function (_super) {
                __extends(VariableDefinitionStep, _super);
                function VariableDefinitionStep() {
                    return _super !== null && _super.apply(this, arguments) || this;
                }
                VariableDefinitionStep.prototype._getName = function () {
                    return "VariableDefinitionStep";
                };
                VariableDefinitionStep.deserializeXML = function ($step) {
                    var s = new VariableDefinitionStep();
                    s._deserializeXML($step);
                    return s;
                };
                VariableDefinitionStep.prototype._deserializeXML = function ($step) {
                    this.type = MobileCrm.Data.CrmType[$step.children("type")[0].textContent];
                    _super.prototype._deserializeXML.call(this, $step);
                };
                VariableDefinitionStep.prototype.execute = function (context) {
                    if (this.type != MobileCrm.Data.CrmType.Entity) {
                        context.addTempVariable(this.serializedVariable, new Workflow.TemporaryVariable(this.serializedVariable, this.type));
                    }
                    return _super.prototype.execute.call(this, context);
                };
                return VariableDefinitionStep;
            }(Workflow.FunctionStep));
            Workflow.VariableDefinitionStep = VariableDefinitionStep;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
