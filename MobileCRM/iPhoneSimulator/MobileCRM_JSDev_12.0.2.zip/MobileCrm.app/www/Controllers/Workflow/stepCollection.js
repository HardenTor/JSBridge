/// <reference path="../../TypeScriptDefinitions/jquery.d.ts" />
/// <reference path="step.ts" />
/// <reference path="commandStep.ts" />
/// <reference path="conditionGroup.ts" />
/// <reference path="conditionStep.ts" />
/// <reference path="branchCollection.ts" />
/// <reference path="assignmentStep.ts" />
/// <reference path="variableDefinitionStep.ts" />
/// <reference path="functionStep.ts" />
/// <reference path="positionStep.ts" />
/// <reference path="sayTextStep.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var StepCollection = (function (_super) {
                __extends(StepCollection, _super);
                function StepCollection() {
                    var _this = _super.call(this) || this;
                    _this.steps = new Array();
                    return _this;
                }
                StepCollection.prototype._getName = function () {
                    return "StepCollection";
                };
                StepCollection.deserializeXML = function ($stepCol) {
                    var sc = new StepCollection();
                    sc._deserializeXML($stepCol);
                    return sc;
                };
                StepCollection.prototype._deserializeXML = function ($stepCol) {
                    var _this = this;
                    var children = $stepCol.children();
                    children.each(function (index, child) {
                        var step = null;
                        switch (child.nodeName) {
                            case "command_definition":
                                step = Workflow.CommandDefinitionStep.deserializeXML($(child));
                                break;
                            case "group":
                                step = Workflow.ConditionGroup.deserializeXML($(child));
                                break;
                            case "condition":
                                step = Workflow.ConditionStep.deserializeXML($(child));
                                break;
                            case "branch":
                                step = Workflow.BranchCollection.deserializeXML($(child));
                                break;
                            case "if":
                                step = Workflow.Branch.deserializeXML($(child));
                                break;
                            case "assign":
                                step = Workflow.AssignmentStep.deserializeXML($(child));
                                break;
                            case "definition":
                                step = Workflow.VariableDefinitionStep.deserializeXML($(child));
                                break;
                            case "function":
                                step = Workflow.FunctionStep.deserializeXML($(child));
                                break;
                            case "position":
                                step = Workflow.PositionStep.deserializeXML($(child));
                                break;
                            case "saytext":
                                step = Workflow.SayTextStep.deserializeXML($(child));
                                break;
                            case "steps":
                                step = StepCollection.deserializeXML($(child));
                                break;
                            case "step":
                                step = Workflow.Step.deserializeXML($(child));
                                break;
                        }
                        if (step) {
                            _this.steps.push(step);
                        }
                    });
                    _super.prototype._deserializeXML.call(this, $stepCol);
                };
                StepCollection.prototype.decode = function (steps) {
                    this.steps.forEach(function (step) { step.decode(steps); });
                };
                return StepCollection;
            }(Workflow.Step));
            Workflow.StepCollection = StepCollection;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
