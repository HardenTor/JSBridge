/// <reference path="../../Helpers/exception.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var ExternalActions = (function () {
                //private m_form: Resco.UI.IForm;
                function ExternalActions() {
                    //this.m_form = form;
                }
                ExternalActions.prototype.sayText = function (text) {
                    //this.m_form.sayText(text);
                };
                ExternalActions.prototype.sayError = function (ex) {
                    //this.m_form.sayError(ex);
                };
                ExternalActions.prototype.sayLocalizedText = function (msgId) {
                    //this.m_form.sayLocalizedText(msgId);
                };
                ExternalActions.prototype.messageBox = function (callback, callbackSource, titleId, defaultTextId, itemsId) {
                    //var title = Localization.instance.get(titleId);
                    //var defaultText = Localization.instance.get(defaultTextId);
                    //var items = itemsId.map(s => Localization.instance.get(s));
                    //this.m_form.messageBox(callback, callbackSource, title, false, defaultText, items);
                };
                ExternalActions.prototype.showLocalizedPleaseWait = function (msgId) {
                    //this.m_form.showPleaseWait(Localization.instance.get(msgId));
                };
                ExternalActions.prototype.invokeOnUIThread = function (action, actionSource, parameter) {
                    //this.m_form.invokeOnUIThread(action, actionSource, parameter, 0);
                };
                return ExternalActions;
            }());
            Workflow.ExternalActions = ExternalActions;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
