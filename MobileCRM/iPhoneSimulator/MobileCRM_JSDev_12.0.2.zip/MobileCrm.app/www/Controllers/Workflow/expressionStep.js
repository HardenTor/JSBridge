/// <reference path="step.ts" />
/// <reference path="executionContext.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var Workflow;
        (function (Workflow) {
            var ExpressionStep = (function (_super) {
                __extends(ExpressionStep, _super);
                function ExpressionStep() {
                    var _this = _super.call(this) || this;
                    _this.serializedArguments = new Array();
                    return _this;
                }
                ExpressionStep.prototype._getName = function () {
                    return "ExpressionStep";
                };
                ExpressionStep.prototype.getVariableValue = function (context) {
                    return context.getVariable(this.serializedVariable);
                };
                ExpressionStep.prototype.getVariableType = function (context) {
                    return context.getVariableType(this.serializedVariable);
                };
                ExpressionStep.prototype._getArgument = function (index) {
                    if (index >= this.serializedArguments.length) {
                        throw new Resco.Exception("Argument out of bounds " + index + "/" + this.serializedArguments.length);
                    }
                    if (!this.m_args) {
                        this.m_args = this.serializedArguments.map(function (s) { return new ExpArg(s); });
                    }
                    return this.m_args[index];
                };
                ExpressionStep.prototype.getArgumentValue = function (context, idx, arg) {
                    if (!arg) {
                        arg = this._getArgument(idx);
                    }
                    if (arg.isVariable) {
                        return context.getVariable(arg.value);
                    }
                    return arg.value;
                };
                ExpressionStep.prototype.getArgumentType = function (context, idx, arg) {
                    if (!arg) {
                        arg = this._getArgument(idx);
                    }
                    if (arg.isVariable) {
                        return context.getVariableType(arg.value);
                    }
                    return arg.constantType;
                };
                ExpressionStep.prototype.getArgumentValueAsText = function (context, idx) {
                    var value = this.getArgumentValue(context, idx);
                    var argType = this.getArgumentType(context, idx);
                    return this.getVariableOrArgumentAsText(context, value, argType, idx);
                };
                ExpressionStep.prototype.getVariableOrArgumentAsText = function (context, value, argType, varOrArg) {
                    if (argType == MobileCrm.Data.CrmType.Picklist || argType == MobileCrm.Data.CrmType.State || argType == MobileCrm.Data.CrmType.Status) {
                        var path = varOrArg < 0 ? this.serializedVariable : this.serializedArguments[varOrArg].substr(4); // cut 'var:'
                        try {
                            if (path.indexOf(".") > 0) {
                                var obj = context.getVariable(path + ".formatted");
                                return obj ? obj : "";
                            }
                        }
                        catch (ex) {
                        }
                        var argPath = path.replace(/Entity/g, context.entityName);
                        return argPath + "." + value; // TODO: Localize: Localization.instance.get(argPath + "." + value);
                    }
                    return value ? value.toString() : "";
                };
                ExpressionStep.prototype._getBroadestNumberType = function (argType1, argType2) {
                    if (argType1 == MobileCrm.Data.CrmType.Integer) {
                        return argType2;
                    }
                    else if (argType2 == MobileCrm.Data.CrmType.Integer) {
                        return argType1;
                    }
                    else if (argType1 == MobileCrm.Data.CrmType.Float) {
                        return argType2;
                    }
                    return MobileCrm.Data.CrmType.Decimal;
                };
                ExpressionStep.deserializeXML = function ($step) {
                    var s = new ExpressionStep();
                    s._deserializeXML($step);
                    return s;
                };
                ExpressionStep.prototype._deserializeXML = function ($step) {
                    var _this = this;
                    var $args = $step.children("arg");
                    this.serializedArguments.splice(0);
                    $args.each(function (index, child) {
                        _this.serializedArguments.push($(child).text());
                    });
                    this.serializedVariable = $step.children("var")[0].textContent;
                    _super.prototype._deserializeXML.call(this, $step);
                };
                return ExpressionStep;
            }(Workflow.Step));
            Workflow.ExpressionStep = ExpressionStep;
            var ExpArg = (function () {
                function ExpArg(path) {
                    if (path && path.startsWith("var:")) {
                        this.isVariable = true;
                        this.value = path.substr(4);
                    }
                    else {
                        var p = path.indexOf(":");
                        if (p <= 0) {
                            throw new Resco.Exception("Invalid constant path '" + path + "'");
                        }
                        var finalValue = null;
                        if (p + 1 < path.length) {
                            var type = path.substr(0, p);
                            var value = path.substr(p + 1);
                        }
                        switch (type) {
                            case "UniqueIdentifier":
                                finalValue = value;
                                this.constantType = MobileCrm.Data.CrmType.UniqueIdentifier;
                                break;
                            case "Money":
                                finalValue = Resco.strictParseFloat(value);
                                this.constantType = MobileCrm.Data.CrmType.Money;
                                break;
                            case "Decimal":
                                finalValue = Resco.strictParseFloat(value);
                                this.constantType = MobileCrm.Data.CrmType.Decimal;
                                break;
                            case "Float":
                                finalValue = Resco.strictParseFloat(value);
                                this.constantType = MobileCrm.Data.CrmType.Float;
                                break;
                            case "Boolean":
                                finalValue = (value == "1" || value == "true" || value == "True");
                                this.constantType = MobileCrm.Data.CrmType.Boolean;
                                break;
                            case "Picklist":
                                finalValue = Resco.strictParseInt(value);
                                this.constantType = MobileCrm.Data.CrmType.Picklist;
                                break;
                            case "Status":
                                finalValue = Resco.strictParseInt(value);
                                this.constantType = MobileCrm.Data.CrmType.Status;
                                break;
                            case "State":
                                finalValue = Resco.strictParseInt(value);
                                this.constantType = MobileCrm.Data.CrmType.State;
                                break;
                            case "Integer":
                                finalValue = Resco.strictParseInt(value);
                                this.constantType = MobileCrm.Data.CrmType.Integer;
                                break;
                            case "String":
                                finalValue = value;
                                this.constantType = MobileCrm.Data.CrmType.String;
                                break;
                            case "Memo":
                                finalValue = value;
                                this.constantType = MobileCrm.Data.CrmType.Memo;
                                break;
                            case "Fetch":
                                finalValue = value;
                                this.constantType = MobileCrm.Data.CrmType.Fetch;
                                break;
                            case "DateTime":
                                finalValue = new Date(value);
                                this.constantType = MobileCrm.Data.CrmType.DateTime;
                                break;
                            case "Lookup":
                                finalValue = this._parseReference(value);
                                this.constantType = MobileCrm.Data.CrmType.Lookup;
                                break;
                            case "Customer":
                                finalValue = this._parseReference(value);
                                this.constantType = MobileCrm.Data.CrmType.Customer;
                                break;
                            case "Owner":
                                finalValue = this._parseReference(value);
                                this.constantType = MobileCrm.Data.CrmType.Owner;
                                break;
                            case "PicklistArray":
                                finalValue = value.split(";").map(function (s) { return Resco.strictParseInt(s); });
                                this.constantType = MobileCrm.Data.CrmType.PicklistArray;
                                break;
                            default: throw new Resco.Exception("Unsupported constant type");
                        }
                        this.value = finalValue;
                    }
                }
                ExpArg.prototype._parseReference = function (x) {
                    if (!x)
                        return null;
                    var i1 = x.indexOf(",");
                    var i2 = x.indexOf(",", i1 + 1);
                    if (i1 < 0 || i2 < 0)
                        return null;
                    return new MobileCRM.Reference(x.substr(0, i1), x.substr(i1 + 1, i2 - i1 - 1), x.substr(i2 + 1));
                };
                return ExpArg;
            }());
            Workflow.ExpArg = ExpArg;
        })(Workflow = UI.Workflow || (UI.Workflow = {}));
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
