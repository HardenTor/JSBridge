/// <reference path="../Controls/advancedList-1.0.3.ts" />
/// <reference path="../Helpers/common.ts" />
/// <reference path="entityList.ts" />
var MobileCrm;
(function (MobileCrm) {
    /// <summary>
    /// This class provides high level controllers registration and creation methods.
    /// </summary>
    var ControllerFactory = (function () {
        function ControllerFactory() {
            this.m_register = new Resco.Dictionary();
        }
        Object.defineProperty(ControllerFactory, "instance", {
            get: function () {
                if (!ControllerFactory.s_instance) {
                    ControllerFactory.s_instance = new ControllerFactory();
                }
                return ControllerFactory.s_instance;
            },
            enumerable: true,
            configurable: true
        });
        ControllerFactory.prototype.clear = function () {
            this.m_register.clear();
        };
        ControllerFactory.prototype.hasController = function (entityName, kind) {
            if (this.m_register.containsKey(entityName)) {
                var r = this.m_register.getValue(entityName);
                return r.getType(kind) != null || r.getFile(kind) != null;
            }
            return false;
        };
        ControllerFactory.prototype.register = function (entityName, kind, registeredObject, isType) {
            if (kind < 0 || kind >= ControlType.Last) {
                throw new Resco.Exception("Unknown controller kind " + kind);
            }
            var r;
            if (this.m_register.containsKey(entityName)) {
                r = this.m_register.getValue(entityName);
            }
            else {
                r = new RegList();
                this.m_register.add(entityName, r);
            }
            if (isType) {
                r.addType(kind, registeredObject);
            }
            else {
                r.addFile(kind, registeredObject);
            }
        };
        ControllerFactory.prototype.hasList = function (entityName) {
            return this.hasController(entityName, ControlType.List);
        };
        ControllerFactory.prototype.getListController = function (entityName, entityListType) {
            var listType = null;
            var definitionFile = null;
            if (this.m_register.containsKey(entityName)) {
                var r = this.m_register.getValue(entityName);
                listType = r.getType(ControlType.List);
                if (listType) {
                    entityListType = listType;
                }
                definitionFile = r.getFile(ControlType.List);
            }
            return MobileCrm.UI.BaseEntityList.createInstance(entityName, entityListType, definitionFile);
        };
        //public detailStyles: Resco.Dictionary<string, Resco.UI.DetailViewItemStyle>;
        //      public initializeStyles() {
        //          var reader = Configuration.instance.openUIConfig("Controllers\\Styles");
        //          if (reader) {
        //              this._deserializeStyles(reader);
        //          }
        //	  }
        ControllerFactory.prototype.initializeStyles = function (lines) {
            this._deserializeStyles(new Resco.TextReader(lines));
        };
        ControllerFactory.prototype.addDefaultListStyle = function (name, foreColor, backColor, fontSize, vert, horz) {
            var styles = this.listStyles;
            if (!styles.containsKey(name)) {
                var style = new Resco.UI.ListCellStyle();
                style.name = name;
                style.foreColor = foreColor;
                style.backColor = backColor;
                style.fontSize = fontSize;
                style.verticalAlignment = vert;
                style.horizontalAlignment = horz;
                styles.set(name, style);
            }
        };
        ControllerFactory.prototype._deserializeStyles = function (reader) {
            var line = reader.readLine();
            if (line != "V1" && line != "V2") {
                throw new Resco.Exception("Invalid style format");
            }
            var listStyle = null;
            //var detailStyle: Resco.UI.DetailViewItemStyle = null;
            var styles = new Resco.Dictionary();
            this.listStyles = styles;
            //var dvStyles = new Resco.Dictionary<string, Resco.UI.DetailViewItemStyle>();
            //this.detailStyles = dvStyles;
            this.hasSelectedListStyle = false;
            while ((line = reader.readLine()) != null) {
                var chunks = line.split('=');
                if (line[0] == "#") {
                    //detailStyle = null;
                    if (chunks.length > 1) {
                        listStyle = styles.getValue(chunks[1]).clone();
                    }
                    else {
                        listStyle = new Resco.UI.ListCellStyle();
                        listStyle.fontSize = this._calculateFontSize(10);
                    }
                    listStyle.name = ControllerFactory.getStyleName(chunks[0].substring(1));
                    if (listStyle.name.endsWith("Selected")) {
                        this.hasSelectedListStyle = true;
                    }
                    styles.add(listStyle.name, listStyle);
                }
                else if (line[0] == "@") {
                    listStyle = null;
                    if (chunks.length > 1) {
                        //detailStyle = dvStyles.getValue(chunks[1]).clone();
                    }
                    else {
                        //detailStyle = new Resco.UI.DetailViewItemStyle();
                        //detailStyle.labelHorizontalAlignment = Resco.ContentAlignment.Far;
                    }
                    //detailStyle.name = ControllerFactory.getStyleName(chunks[0].substring(1));
                    //dvStyles.add(detailStyle.name, detailStyle);
                }
                else if (listStyle) {
                    var value = chunks[1];
                    if (!value) {
                        continue;
                    }
                    switch (chunks[0]) {
                        case "FontSize": {
                            listStyle.fontSize = this._calculateFontSize(parseFloat(value));
                            break;
                        }
                        case "FontWeight": {
                            listStyle.fontWeight = parseInt(value);
                            break;
                        }
                        case "ForeColor": {
                            listStyle.foreColor = ControllerFactory.strNumToStrColor(value);
                            break;
                        }
                        case "BackColor": {
                            listStyle.backColor = ControllerFactory.strNumToStrColor(value);
                            break;
                        }
                        case "HorizontalAlignment": {
                            listStyle.horizontalAlignment = parseInt(value);
                            break;
                        }
                        case "VerticalAlignment": {
                            listStyle.verticalAlignment = parseInt(value);
                            break;
                        }
                        case "Format":
                        case "FormatString": {
                            if (value && value[0] == '@') {
                                value = value.substring(1); // TODO: Localize: Localization.instance.get(value.substring(1));
                            }
                            listStyle.formatString = value;
                            break;
                        }
                        case "Folder": {
                            listStyle.folder = value;
                            break;
                        }
                        case "ImageQuery": {
                            listStyle.imageQuery = value;
                            break;
                        }
                        case "AutoHeight": {
                            listStyle.autoHeight = value[0] == '1';
                            break;
                        }
                    }
                }
                //else if (detailStyle) {
                //    var value = chunks[1];
                //    if (!value) {
                //        continue;
                //    }
                //    switch (chunks[0]) {
                //        case "IsMultiLine": {
                //            detailStyle.isMultiLine = value[0] == '1'; break;
                //        }
                //        case "LabelAutoHeight": {
                //            detailStyle.labelAutoHeight = value[0] == '1'; break;
                //        }
                //        case "LabelAutoWidth": {
                //            detailStyle.labelAutoWidth = value[0] == '1'; break;
                //        }
                //        case "LabelPosition": {
                //            var pos = parseInt(value);
                //            if (pos > 0) {
                //                detailStyle.labelPosition = pos - 1;
                //            }
                //            break;
                //        }
                //        case "LabelHorizontalAlignment": {
                //            var pos = parseInt(value);
                //            if (pos > 0) {
                //                detailStyle.labelHorizontalAlignment = pos - 1;
                //            }
                //            break;
                //        }
                //        case "EditorHorizontalAlignment": {
                //            detailStyle.editorHorizontalAlignment = parseInt(value); break;
                //        }
                //        case "RelativeLabelFontSize": {
                //            detailStyle.relativeLabelFontSize = parseInt(value); break;
                //        }
                //        case "RelativeTextFontSize": {
                //            detailStyle.relativeTextFontSize = parseInt(value); break;
                //        }
                //        case "ImageQuery": {
                //            detailStyle.imageQuery = value; break;
                //        }
                //    }
                //}
            }
            //if (!dvStyles.containsKey(ControllerFactory.DefaultItemStyleName)) {
            //    dvStyles.add(ControllerFactory.DefaultItemStyleName, new Resco.UI.DetailViewItemStyle());
            //}
            //if (!dvStyles.containsKey("MultiLine")) {
            //    var multiLineStyle = new Resco.UI.DetailViewItemStyle();
            //    multiLineStyle.isMultiLine = true;
            //    multiLineStyle.labelHorizontalAlignment = Resco.ContentAlignment.Center;
            //    multiLineStyle.labelPosition = Resco.LabelPosition.Top;
            //    dvStyles.add("MultiLine", multiLineStyle);
            //}
            // TODO: RightToLeft
        };
        //get defaultDetailItemStyle(): Resco.UI.DetailViewItemStyle {
        //    return this.detailStyles.getValue(ControllerFactory.DefaultItemStyleName);
        //}
        //static DefaultItemStyleName = "Normal";
        ControllerFactory.getStyleName = function (styleName) {
            var index = styleName.indexOf('.');
            if (index > 0) {
                var suffix = "html";
                if (styleName.length == index + suffix.length + 1 && styleName.substring(index + 1) == suffix) {
                    return styleName.substr(0, index);
                }
            }
            return styleName;
        };
        ControllerFactory.prototype._calculateFontSize = function (size) {
            return (4 / 3) * size;
        };
        ControllerFactory.strNumToStrColor = function (strNum) {
            var num = parseInt(strNum);
            if (num == NaN || (num >>> 24) == 0) {
                return "transparent";
            }
            var strHexa = (num & 0x00FFFFFF).toString(16);
            // pad with zeroes (width 6)
            var strHexa = strHexa.length >= 6 ? strHexa : new Array(6 - strHexa.length + 1).join('0') + strHexa;
            return "#" + strHexa;
        };
        //public deserializeAppStyle(): AppStyle {
        //    var style: AppStyle = null;
        //    var reader = Configuration.instance.openUIConfig("Controllers\\AppStyle");
        //    if (reader) {
        //        style = new AppStyle();
        //        this._deserializeAppStyle(reader, style);
        //    }
        //    return style;
        //}
        //private _deserializeAppStyle(reader: Resco.TextReader, style: AppStyle): void {
        //    if (reader.readLine() != "V1") {
        //        throw new Resco.Exception("Invalid AppStyle file format");
        //    }
        //    style.version = 2;
        //    var line: string;
        //    while ((line = reader.readLine()) != null) {
        //        var pp = line.split("=");
        //        var colorName = this._getStyleName(pp[0]);
        //        var colorNumber = Resco.strictParseInt(pp[1]);
        //        colorNumber = colorNumber >>> 0;
        //        var color = colorNumber.toString(16);
        //        color = "#" + color.substring(2);
        //        switch (colorName) {
        //            case "TitleForeground": style.titleForeground = color; break;
        //            case "TitleBackground": style.titleBackground = color; break;
        //            case "ListForeground": style.listForeground = color; break;
        //            case "ListBackground": style.listBackground = color; break;
        //            case "ListSelForeground": style.listSelForeground = color; break;
        //            case "ListSelBackground": style.listSelBackground = color; break;
        //            case "ListSeparator": style.listSeparator = color; break;
        //            case "FormBackground": style.formBackground = color; break;
        //            case "FormItemBackground": style.formItemBackground = color; break;
        //            case "FormItemForeground": style.formItemForeground = color; break;
        //            case "FormItemLabelForeground": style.formItemLabelForeground = color; break;
        //            case "FormItemDisabled": style.formItemDisabled = color; break;
        //            case "FormItemLink": style.formItemLink = color; break;
        //            case "SearchBackground": style.searchBackground = color; break;
        //            case "SearchForeground": style.searchForeground = color; break;
        //            case "SearchSelForeground": style.searchSelForeground = color; break;
        //            case "TabBackground": style.tabBackground = color; break;
        //            case "TabForeground": style.tabForeground = color; break;
        //            case "TabSelForeground": style.tabSelForeground = color; break;
        //        }
        //        style.appColorStart = style.titleBackground;
        //    }
        //}
        ControllerFactory.prototype._getStyleName = function (styleName) {
            var idx = styleName.indexOf(".");
            if (idx > 0) {
                if (styleName.length == idx + 4 && styleName.substr(idx + 1, 3) == "web")
                    return styleName.substr(0, idx);
            }
            return styleName;
        };
        return ControllerFactory;
    }());
    MobileCrm.ControllerFactory = ControllerFactory;
    var RegList = (function () {
        function RegList() {
            this.m_list = new Array(ControlType.Last * 2);
        }
        RegList.prototype.addType = function (kind, type) {
            this.m_list[kind] = type;
        };
        RegList.prototype.getType = function (kind) {
            return this.m_list[kind];
        };
        RegList.prototype.addFile = function (kind, type) {
            this.m_list[ControlType.Last + kind] = type;
        };
        RegList.prototype.getFile = function (kind) {
            return this.m_list[ControlType.Last + kind];
        };
        return RegList;
    }());
    var ControlType;
    (function (ControlType) {
        ControlType[ControlType["List"] = 0] = "List";
        ControlType[ControlType["Form"] = 1] = "Form";
        ControlType[ControlType["Detail"] = 2] = "Detail";
        ControlType[ControlType["Chart"] = 3] = "Chart";
        ControlType[ControlType["Last"] = 4] = "Last";
    })(ControlType = MobileCrm.ControlType || (MobileCrm.ControlType = {}));
})(MobileCrm || (MobileCrm = {}));
