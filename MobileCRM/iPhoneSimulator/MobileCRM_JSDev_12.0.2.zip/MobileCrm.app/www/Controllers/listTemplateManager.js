/// <reference path="../Controls/advancedList-1.0.3.ts" />
/// <reference path="controllerFactory.ts" />
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var ListTemplateManager = (function () {
            function ListTemplateManager() {
            }
            ListTemplateManager.Deserialize = function (list, reader, versionCheck) {
                if (versionCheck) {
                    if (reader.readLine() != "V1") {
                        throw new Resco.Exception("Invalid list templates file format");
                    }
                }
                var t = null;
                var designWidth = ListTemplateManager.RowDesignWidth;
                var designHeight = ListTemplateManager.RowDesignHeight;
                while (true) {
                    var line = reader.readLine();
                    if (!line) {
                        break;
                    }
                    var chunks = line.split(";");
                    var x = chunks[0][0];
                    if (x == 'T') {
                        designWidth = ListTemplateManager.RowDesignWidth;
                        designHeight = ListTemplateManager.RowDesignHeight;
                        if (chunks.length > 5) {
                            designWidth = parseInt(chunks[4]);
                            designHeight = parseInt(chunks[5]);
                        }
                        var t = new Resco.UI.RowTemplate();
                        t.name = chunks[1];
                        var tWidth = (parseInt(chunks[2]) * ListTemplateManager.RowDesiredWidth) / designWidth;
                        var tHeight = (parseInt(chunks[3]) * ListTemplateManager.RowDesiredHeight) / designHeight;
                        t.size = new Resco.Size(Math.floor(tWidth), Math.floor(tHeight));
                        if (chunks.length > 7) {
                            t.backgroundColor = MobileCrm.ControllerFactory.strNumToStrColor(chunks[6]);
                            t.selectedBackground = MobileCrm.ControllerFactory.strNumToStrColor(chunks[7]);
                        }
                        list.push(t);
                    }
                    else if (x == 'S' || x == 'I') {
                        var c = ListTemplateManager.parseCell(chunks);
                        c.kind = x == 'I' ? Resco.ListCellKind.Image : Resco.ListCellKind.Text;
                        var cx = (parseInt(chunks[4]) * ListTemplateManager.RowDesiredWidth) / designWidth;
                        var cy = (parseInt(chunks[5]) * ListTemplateManager.RowDesiredHeight) / designHeight;
                        var cw = (parseInt(chunks[6]) * ListTemplateManager.RowDesiredWidth) / designWidth;
                        var ch = (parseInt(chunks[7]) * ListTemplateManager.RowDesiredHeight) / designHeight;
                        c.position = new Resco.Position(Math.floor(cx), Math.floor(cy));
                        c.size = new Resco.Size(Math.floor(cw), Math.floor(ch));
                        t.cellTemplates.push(c);
                    }
                    else if (x == 'M') {
                        var c = ListTemplateManager.parseCell(chunks);
                        c.kind = Resco.ListCellKind.Image;
                        t.mapCell = c;
                    }
                }
                //TODO: handle RTL
            };
            ListTemplateManager.parseCell = function (chunks) {
                var c = new Resco.UI.CellTemplate();
                c.dataMember = chunks[1];
                c.constant = (chunks[2][0] == '1');
                if (c.constant) {
                    var text = c.dataMember;
                    if (text && text[0] == '@') {
                        text = text.substring(1); // TODO Localize: MobileCrm.Localization.instance.get(text.substring(1));
                    }
                    else {
                        text = text.replace("\\n", "\n");
                    }
                    c.dataMember = text;
                }
                c.styleName = chunks[3];
                c.anchor = parseInt(chunks[8]);
                return c;
            };
            ListTemplateManager.setTemplate = function (listView, styles, template, buttons, bSkipIndex) {
                var index = ListTemplateManager.addTemplate(listView, styles, template, buttons);
                var selIndex = ListTemplateManager.addSelectedTemplate(listView, styles, template, index, buttons);
                if (!bSkipIndex) {
                    listView.templateIndex(index);
                    listView.selectedTemplateIndex(selIndex);
                }
            };
            ListTemplateManager.addTemplate = function (listView, styles, template, buttons) {
                template = template.clone();
                // TODO: Platform
                if (!template.backgroundColor) {
                    template.backgroundColor = "#ffffff"; //MobileCrm.Platform.instance.appStyle.listBackground;
                }
                var index = listView.addTemplate(template, -1);
                ListTemplateManager.setCellStyle(listView, styles, template, false);
                return index;
            };
            ListTemplateManager.setCellStyle = function (listView, styles, template, selected) {
                template.cellTemplates.forEach(function (c) {
                    if (c.styleName) {
                        var cellStyle = styles.getValue(c.styleName);
                        if (!cellStyle) {
                            cellStyle = ListTemplateManager.GetDefaultListCellStyle();
                        }
                        if (selected) {
                            var sname = c.styleName + "Selected";
                            if (styles.containsKey(sname)) {
                                cellStyle = styles.getValue(sname);
                            }
                            else if (ListTemplateManager.ListSelForeground) {
                                cellStyle = cellStyle.clone();
                                cellStyle.foreColor = ListTemplateManager.ListSelForeground;
                                styles.add(sname, cellStyle);
                            }
                        }
                        c.style = cellStyle;
                    }
                }, this);
            };
            ListTemplateManager.GetDefaultListCellStyle = function () {
                if (!ListTemplateManager.DefaultListCellStyle) {
                    ListTemplateManager.DefaultListCellStyle = new Resco.UI.ListCellStyle();
                    ListTemplateManager.DefaultListCellStyle.autoHeight = false;
                    ListTemplateManager.DefaultListCellStyle.backColor = "transparent";
                    ListTemplateManager.DefaultListCellStyle.fontSize = 14;
                    ListTemplateManager.DefaultListCellStyle.foreColor = "black";
                }
                return ListTemplateManager.DefaultListCellStyle;
            };
            ListTemplateManager.addSelectedTemplate = function (listView, styles, template, index, buttons) {
                var selIndex = listView.addTemplate(template.clone(), index);
                template = listView.templates[selIndex];
                var bounds;
                var hasButtons = (buttons && buttons.length > 0);
                if (hasButtons) {
                    bounds = new Resco.Rectangle(8, template.size.height() + 5, 70, 20);
                    template.size.height(template.size.height() + 30);
                }
                if (!template.selectedBackground || template.selectedBackground == "transparent") {
                    // TODO: Platform
                    //if (MobileCrm.Platform.instance.appStyle.listSelBackground) {
                    template.backgroundColor = "#d3e9ff"; // MobileCrm.Platform.instance.appStyle.listSelBackground;
                    //}
                    //else if (MobileCrm.Platform.instance.appStyle.appColorStart) {
                    //	template.backgroundColor = "#0066CC";// MobileCrm.Platform.instance.appStyle.appColorStart;
                    //}
                }
                else {
                    template.backgroundColor = template.selectedBackground;
                }
                ListTemplateManager.setCellStyle(listView, styles, template, true);
                if (hasButtons) {
                    ListTemplateManager.addButtons(template, bounds, buttons);
                }
                return selIndex;
            };
            ListTemplateManager.addButtons = function (template, bounds, buttons) {
                var anchor = Resco.ListCellAnchor.Left | Resco.ListCellAnchor.Bottom;
                var dy = bounds.left() + bounds.width();
                buttons.forEach(function (button) {
                    if (button != "Call") {
                        var defaultLabel = button;
                        if (button.startsWith("Create.")) {
                            var pp = button.split(".");
                            if (pp.length > 1) {
                                defaultLabel = "+" + pp[1]; // TODO: Localize: Localization.instance.get(pp[1]);
                            }
                        }
                        else if (button.startsWith("Open.")) {
                            var pp = button.split(".");
                            if (pp.length > 2) {
                                defaultLabel = pp[2]; // TODO: Localize: Localization.instance.get(pp[1], pp[2]);
                            }
                        }
                        // TODO: Localize: 
                        //var label: string;
                        //if (Localization.instance.stringTable.containsKey("Button." + button)) {
                        //    label = Localization.instance.stringTable.getValue("Button." + button)
                        //}
                        //else if (Localization.instance.stringTable.containsKey("Cmd." + button)) {
                        //    label = Localization.instance.stringTable.getValue("Cmd." + button)
                        //}
                        //else {
                        //    label = defaultLabel;
                        //}
                        var label = defaultLabel;
                        var buttonCell = new Resco.UI.CellTemplate();
                        buttonCell.kind = Resco.ListCellKind.Button;
                        buttonCell.name = button;
                        buttonCell.constant = true;
                        buttonCell.dataMember = label;
                        buttonCell.position = new Resco.Position(bounds.left(), bounds.top());
                        buttonCell.size = new Resco.Size(bounds.width(), bounds.height());
                        buttonCell.anchor = anchor;
                        template.cellTemplates.push(buttonCell);
                        bounds.left(10 + dy);
                    }
                }, this);
            };
            return ListTemplateManager;
        }());
        ListTemplateManager.RowDesignWidth = 240;
        ListTemplateManager.RowDesignHeight = 40;
        ListTemplateManager.RowDesiredWidth = 320;
        ListTemplateManager.RowDesiredHeight = 48;
        ListTemplateManager.DefaultListForeground = "black";
        ListTemplateManager.DefaultListSelForeground = "#0066CC"; //"white"
        ListTemplateManager.DefaultListBackground = "transparent";
        ListTemplateManager.DefaultListSelBackground = "transparent";
        ListTemplateManager.ListForeground = ListTemplateManager.DefaultListForeground;
        ListTemplateManager.ListSelForeground = ListTemplateManager.DefaultListSelForeground;
        ListTemplateManager.ListBackground = ListTemplateManager.DefaultListBackground;
        ListTemplateManager.ListSelBackground = ListTemplateManager.DefaultListSelBackground;
        UI.ListTemplateManager = ListTemplateManager;
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
