/// <reference path="../Helpers/common.ts" />
/// <reference path="listController.ts" />
/// <reference path="dynamicEntityList.ts" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var MobileCrm;
(function (MobileCrm) {
    var UI;
    (function (UI) {
        var BaseEntityList = (function (_super) {
            __extends(BaseEntityList, _super);
            function BaseEntityList(nativeType) {
                var _this = _super.call(this) || this;
                _this.entityName = null;
                _this.uniqueName = null;
                _this.listButtons = new Array();
                _this.allowCreateNew = true;
                _this.hasMapViews = false;
                _this.nativeType = nativeType ? nativeType : BaseEntityList;
                return _this;
            }
            Object.defineProperty(BaseEntityList.prototype, "isDirty", {
                get: function () {
                    return this._getIsDirty();
                },
                set: function (value) {
                    this._setIsDirty(value);
                },
                enumerable: true,
                configurable: true
            });
            BaseEntityList.prototype._getIsDirty = function () {
                return this.m_isDirty;
            };
            BaseEntityList.prototype._setIsDirty = function (value) {
                this.m_isDirty = value;
            };
            Object.defineProperty(BaseEntityList.prototype, "selectedIndex", {
                //get selected(): MobileCrm.Data.AbstractEntity {
                //    var index = this.m_listView.selectedIndex;
                //    if (index >= 0)
                //        return <MobileCrm.Data.AbstractEntity>this.m_listView.getItemValue(index);
                //    return null;
                //}
                set: function (index) {
                    this.m_listView.selectedIndex = index;
                },
                enumerable: true,
                configurable: true
            });
            BaseEntityList.prototype._setLoaded = function (value) {
                this._registerEntityChangedNotification(value);
                _super.prototype._setLoaded.call(this, value);
                if (value) {
                    this.setupCommand();
                }
            };
            BaseEntityList.prototype._registerEntityChangedNotification = function (register) {
                if (register) {
                    if (!this.m_notifyRegistered) {
                        //MobileCrm.Data.AbstractEntity.modified.add(this, this._onEntityModified);
                    }
                }
                else {
                    if (this.m_notifyRegistered) {
                        //MobileCrm.Data.AbstractEntity.modified.remove(this, this._onEntityModified);
                    }
                }
                this.m_notifyRegistered = register;
            };
            BaseEntityList.createInstance = function (entityName, entityListType, definitionFile) {
                var list;
                if (entityListType != null) {
                    list = new entityListType(entityListType);
                }
                else {
                    list = new UI.DynamicEntityList(UI.DynamicEntityList);
                }
                list.configPath = definitionFile;
                list.initialize(entityName);
                return list;
            };
            BaseEntityList.prototype.setView = function (listView, mode) {
                var buttons = this._getButtonsForViewMode(mode);
                this.setupView(listView, mode != UI.ViewMode.Lookup && mode != UI.ViewMode.Dashboard, buttons);
            };
            BaseEntityList.prototype.setupAllowedViews = function (configuration) {
                if (configuration) {
                    var initialView = null;
                    var entityName = this.entityName;
                    var views = new Resco.Dictionary();
                    var viewEntities = configuration.split(':');
                    for (var j = 0; j < viewEntities.length; j++) {
                        var vv = viewEntities[j].split(".");
                        for (var i = 0; i < vv.length - 1; i += 2) {
                            var ename = vv[i];
                            if (ename[0] == '@') {
                                ename = ename.substring(1);
                            }
                            var vname = vv[i + 1];
                            if (ename == entityName && vname) {
                                if (vname[0] == '@') {
                                    vname = vname.substring(1);
                                    initialView = vname;
                                }
                                views.add(vname, null);
                            }
                        }
                    }
                    this.allowedViews = views;
                    this.initialView = initialView;
                }
            };
            BaseEntityList.setupAllowedEntities = function (allowedViews, entityFilter) {
                var res = BaseEntityList.setupAllowedEntitiesDict(allowedViews);
                var entities = res.entities;
                var initialEntity = res.initialEntity;
                if (entities) {
                    for (var i = entityFilter.values.length - 1; i >= 0; i--) {
                        if (!entities.containsKey(entityFilter.values[i].value)) {
                            entityFilter.values.splice(i, 1);
                        }
                    }
                }
                if (initialEntity) {
                    entityFilter.selectedValue = initialEntity;
                }
            };
            BaseEntityList.setupAllowedEntitiesDict = function (allowedViews) {
                if (allowedViews && allowedViews[0] === '<') {
                    // XML format  -> TODO: extract allowedViews
                }
                var res = EntityList._splitMultiEntityViewConfig(allowedViews);
                var initialEntity = res.initialEntity;
                allowedViews = res.allowedViews;
                var entities = null;
                if (allowedViews) {
                    entities = new Resco.Dictionary();
                    var vv = allowedViews.split(':');
                    for (var i = 0; i < vv.length; i++) {
                        var values = vv[i].split('.');
                        var entityName = values[0];
                        if (entityName[0] === '@') {
                            entityName = entityName.substring(1);
                            initialEntity = entityName;
                        }
                        entities.set(entityName, null);
                    }
                }
                return { initialEntity: initialEntity, entities: entities };
            };
            BaseEntityList._splitMultiEntityViewConfig = function (av) {
                // result structure: { xxx: allowedViews, yyy: initialEntity}
                var ie;
                if (av && av.startsWith("@@")) {
                    var last = av.indexOf(":");
                    if (last > 0) {
                        ie = av.substr(2, last - 2);
                        av = av.substr(last + 1);
                    }
                    else {
                        ie = av.substr(2);
                        av = null;
                    }
                }
                return { initialEntity: ie, allowedViews: av };
            };
            BaseEntityList.prototype.setupCommand = function () {
                //if (this.allowCreateNew && this.relationship && this.relationship.intersectEntity) {
                //    this.command = CommandFactory.createLocalized(this, "Manage", f => f._onCommand());
                //}
                //else if ((this.hasPermission(MobileCrm.Data.EntityPermission.Create) && this.allowCreateNew) || (this.relationship && this.allowAddExisting && this.hasPermission(MobileCrm.Data.EntityPermission.Write))) {
                //    this.command = CommandFactory.createNewAction(this, this.internalName, f => f._onCommand());
                //}
            };
            BaseEntityList.prototype._onCommand = function () {
                //if (this.relationship && this.relationship.target && this.relationship.intersectEntity) {
                //    if (this.allowCreateNew) {
                //        var form = new ManageManyToManyForm(this);
                //        var data = new Array<Resco.KeyValuePair<string, any>>();
                //        data.push(new Resco.KeyValuePair<string, any>(Localization.instance.get(this.entityName), this.entityName));
                //        form.showModal(null, data, this.relationship, this.lookupViewsConfiguration);
                //    }
                //}
                //else if (this.allowAddExisting && this.hasPermission(MobileCrm.Data.EntityPermission.Write) && this.relationship && this.relationship.target) {
                //    if (!this.hasPermission(MobileCrm.Data.EntityPermission.Create) || !this.allowCreateNew) {
                //        // add existing
                //        this._addNewOrExisting(1);
                //    }
                //    else {
                //        var caption = MobileCrm.Localization.instance.get(this.entityName);
                //        var cancel = MobileCrm.Localization.instance.get("Cmd", "Cancel");
                //        var addNew = this.command.label;
                //        var addExisting = MobileCrm.Localization.instance.format("Cmd.FmtAddExisting", caption);
                //        this.listView.form.messageBox(this._addNewOrExisting, this, caption, false, cancel, [addNew, addExisting]);
                //    }
                //}
                //else {
                //    this._createNewEntity(this.entityName);
                //}
            };
            //public _createNewEntity(entityName: string, relationship?: MobileCrm.Data.Relationship, options?: Resco.Dictionary<string, any>) {
            //var form = MobileCrm.UI.FormManager.instance.showNewDialog(entityName, relationship ? relationship : this.relationship, options, this.listView.form);
            //if (form && form.entityInstance) {
            //    this.m_lastCreatedEntityId = form.entityInstance.id;
            //}
            //}
            //public _addExistingEntity(entity: MobileCrm.Data.IReference) {
            //    if (entity.id == this.relationship.target.id) {
            //        return;
            //    }
            //    var r = new MobileCrm.Data.Online.SetRelationshipRequest();
            //    r.entity = entity;
            //    r.relationship = this.relationship;
            //    MobileCrm.Data.Online.OnlineRepository.addRequest(r);
            //}
            //private _addNewOrExisting(action: number) {
            //    if (action == 0) {
            //        this._createNewEntity(this.entityName);
            //    }
            //    else if (action == 1) {
            //        LookupForm.selectEntityDialog(this.relationship, null, this._addExistingEntity, this, this.lookupViewsConfiguration, false, [this.entityName]);
            //    }
            //}
            BaseEntityList.prototype.initialize = function (entityName) {
                //var metaEntity = MobileCrm.Data.MetaData.instance.entities.getValue(entityName);
                //var createNewEnitytCmd: any = null;
                //if (!metaEntity.canCreate()) {
                //    createNewEnitytCmd = false;
                //}
                //if (metaEntity.canWrite()) {
                //    this.addPermission(MobileCrm.Data.EntityPermission.Write);
                //}
                this._initialize(entityName, entityName); //, createNewEnitytCmd);
            };
            BaseEntityList.prototype._initialize = function (internalName, entityName, createNewEntityCmd) {
                this.internalName = internalName;
                this.entityName = entityName;
                this.caption = entityName; // TODO: Localize: MobileCrm.Localization.instance.getPlural(entityName);
                //if (createNewEntityCmd || (createNewEntityCmd !== false && MobileCrm.ControllerFactory.instance.hasEditor(entityName))) {
                //    this.addPermission(MobileCrm.Data.EntityPermission.Create);
                //}
            };
            //private hasPermission(perm: MobileCrm.Data.EntityPermission): boolean {
            //    return (this.m_entityPermission & (1 << perm)) != 0;
            //}
            //private addPermission(perm: MobileCrm.Data.EntityPermission) {
            //    this.m_entityPermission |= (1 << perm);
            //}
            BaseEntityList.prototype._onRowClick = function (sender, args) {
            };
            BaseEntityList.prototype._getButtonsForViewMode = function (mode) {
                var buttons = this.listButtons;
                if (buttons.length == 1 && buttons[0] == "More") {
                    //if (!ControllerFactory.instance.hasDetail(this.entityName)) {
                    return null;
                    //}
                }
                if (mode == UI.ViewMode.Lookup) {
                    buttons = ["Select"];
                }
                else if (mode == UI.ViewMode.Dashboard) {
                    buttons = null;
                }
                return buttons;
            };
            BaseEntityList.prototype._getEmptyListText = function (sender) {
                var view = sender;
                var msgId = "No Match"; //TODO: Localize: "ListMsg.NoMatch";
                if (!view.filterText || view.filterText.length == 0) {
                    //if (this.relationship) {
                    //    msgId = "ListMsg.NoRelated";
                    //}
                    //else {
                    msgId = "No Items"; //TODO: Localize: "ListMsg.NoItems";
                    //}
                }
                return msgId; // TODO: Localize: MobileCrm.Localization.instance.get(msgId);
            };
            return BaseEntityList;
        }(MobileCrm.UI.ListController));
        UI.BaseEntityList = BaseEntityList;
        var EntityList = (function (_super) {
            __extends(EntityList, _super);
            function EntityList(nativeType) {
                return _super.call(this, nativeType ? nativeType : EntityList) || this;
            }
            EntityList.prototype._onRowClick = function (sender, args) {
                if (this.handleRowClick) {
                    //var entity = <TEntity>this.selected;
                    //if (entity && MobileCrm.ControllerFactory.instance.hasDetail(entity.entityName)) {
                    //    this.onButtonClick(this.listView, "More", entity, this.listView.selectedIndex);
                    //}
                }
            };
            EntityList.prototype._onButtonClick = function (sender, args) {
                var entity = this.listView.getItemValue(args.rowIndex);
                if (entity) {
                    this.onButtonClick(this.listView, args.name, entity, args.rowIndex);
                }
            };
            EntityList.prototype.onButtonClick = function (view, buttonName, entity, row) {
                if (buttonName == "More") {
                    //this._showEntityDialog(entity);
                }
            };
            return EntityList;
        }(BaseEntityList));
        //public _showEntityDialog(entity: MobileCrm.Data.IReference) {
        //    MobileCrm.UI.FormManager.instance.showEditDialog(entity, this.listView.form, this.relationship);
        //}
        EntityList.DefaultViewName = "Default";
        UI.EntityList = EntityList;
    })(UI = MobileCrm.UI || (MobileCrm.UI = {}));
})(MobileCrm || (MobileCrm = {}));
