var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasZoom = /** @class */ (function () {
            function CanvasZoom(canvasWrapperEl, viewCanvas, canvasProperties) {
                this.canvasWrapperEl = canvasWrapperEl;
                this.viewCanvas = viewCanvas;
                this.canvasProperties = canvasProperties;
                this.scale = 1;
                this.canvasScale = 1;
                this.x = 0;
                this.y = 0;
                this.lastX = 0;
                this.lastY = 0;
                this.pinchCenter = null;
                this.pinchCenterOffset = null;
                this.width = 0;
                this.height = 0;
            }
            CanvasZoom.prototype.updateLastPos = function (deltaX, deltaY) {
                if (deltaX === void 0) { deltaX = 0; }
                if (deltaY === void 0) { deltaY = 0; }
                this.lastX = this.x;
                this.lastY = this.y;
            };
            ;
            CanvasZoom.prototype.updateLastScale = function () {
                this.canvasScale = this.scale;
            };
            ;
            CanvasZoom.prototype.restrictScale = function (scale) {
                if (scale < CanvasZoom.MIN_SCALE)
                    this.scale = CanvasZoom.MIN_SCALE;
                else if (scale > CanvasZoom.MAX_SCALE)
                    this.scale = CanvasZoom.MAX_SCALE;
                return this.scale;
            };
            CanvasZoom.prototype.absolutePosition = function (el) {
                var x = 0;
                var y = 0;
                while (el !== null) {
                    x += el.offsetLeft;
                    y += el.offsetTop;
                    el = el.offsetParent;
                }
                return { x: x, y: y };
            };
            ;
            CanvasZoom.prototype.rawCenter = function (e) {
                var pos = this.absolutePosition(this.canvasWrapperEl);
                // We need to account for the scroll position
                var scrollLeft = window.pageXOffset ? window.pageXOffset : document.body.scrollLeft;
                var scrollTop = window.pageYOffset ? window.pageYOffset : document.body.scrollTop;
                var zoomX = -this.x + (e.center.x - pos.x + scrollLeft) / this.scale;
                var zoomY = -this.y + (e.center.y - pos.y + scrollTop) / this.scale;
                return { x: zoomX, y: zoomY };
            };
            ;
            CanvasZoom.prototype.restrictRawPos = function (pos, viewportDim, imgDim) {
                if (pos < viewportDim / this.scale - imgDim) {
                    pos = viewportDim / this.scale - imgDim;
                }
                else if (pos > 0) {
                    pos = 0;
                }
                return pos;
            };
            ;
            CanvasZoom.prototype.translate = function (deltaX, deltaY) {
                // We restrict to the min of the viewport width/height or current width/height as the
                // current width/height may be smaller than the viewport width/height
                var newX = this.restrictRawPos(this.lastX + deltaX / this.scale, Math.min(this.canvasProperties.ViewWidth, this.width), this.canvasProperties.ViewImageWidth);
                this.x = newX;
                var marginX = Math.ceil(newX * this.scale);
                var newY = this.restrictRawPos(this.lastY + deltaY / this.scale, Math.min(this.canvasProperties.ViewHeight, this.height), this.canvasProperties.ViewImageHeight);
                this.y = newY;
                var marginY = Math.ceil(newY * this.scale);
                if (this.canvasProperties.DimensionsFlipped) {
                    this.viewCanvas.style.marginTop = marginX + 'px';
                    this.viewCanvas.style.marginLeft = marginY + 'px';
                    if (this.width < this.canvasProperties.ViewWidth) {
                        this.viewCanvas.style.marginTop = marginX + Math.ceil((this.canvasProperties.ViewWidth - this.width) / 2) + 'px';
                    }
                    if (this.height < this.canvasProperties.ViewHeight) {
                        this.viewCanvas.style.marginLeft = marginY + Math.ceil((this.canvasProperties.ViewHeight - this.height) / 2) + 'px';
                    }
                }
                else {
                    this.viewCanvas.style.marginLeft = marginX + 'px';
                    this.viewCanvas.style.marginTop = marginY + 'px';
                    if (this.width < this.canvasProperties.ViewWidth) {
                        this.viewCanvas.style.marginLeft = marginX + Math.ceil((this.canvasProperties.ViewWidth - this.width) / 2) + 'px';
                    }
                    if (this.height < this.canvasProperties.ViewHeight) {
                        this.viewCanvas.style.marginTop = marginY + Math.ceil((this.canvasProperties.ViewHeight - this.height) / 2) + 'px';
                    }
                }
            };
            ;
            CanvasZoom.prototype.zoom = function (scaleBy) {
                this.width = Math.ceil(this.canvasProperties.ViewImageWidth * scaleBy);
                this.height = Math.ceil(this.canvasProperties.ViewImageHeight * scaleBy);
                this.scale = this.restrictScale(this.canvasScale * scaleBy);
                this.canvasProperties.ApplyZoom(this.scale);
                // Adjust margins to make sure that we aren't out of bounds
                this.translate(0, 0);
            };
            ;
            CanvasZoom.prototype.zoomAround = function (scaleBy, rawZoomX, rawZoomY, doNotUpdateLast) {
                if (doNotUpdateLast === void 0) { doNotUpdateLast = false; }
                // Zoom
                this.zoom(scaleBy);
                var rawCenterX, rawCenterY;
                if (this.canvasProperties.DimensionsFlipped) {
                    // New raw center of viewport
                    rawCenterX = -this.x + Math.min(this.canvasProperties.ViewHeight, this.height) / 2 / this.scale;
                    rawCenterY = -this.y + Math.min(this.canvasProperties.ViewWidth, this.width) / 2 / this.scale;
                }
                else {
                    // New raw center of viewport
                    rawCenterX = -this.x + Math.min(this.canvasProperties.ViewWidth, this.width) / 2 / this.scale;
                    rawCenterY = -this.y + Math.min(this.canvasProperties.ViewHeight, this.height) / 2 / this.scale;
                }
                // Delta
                var deltaX = (rawCenterX - rawZoomX) * this.scale;
                var deltaY = (rawCenterY - rawZoomY) * this.scale;
                // Translate back to zoom center
                this.translate(deltaX, deltaY);
                if (!doNotUpdateLast) {
                    this.updateLastScale();
                    this.updateLastPos();
                }
            };
            ;
            CanvasZoom.prototype.zoomCenter = function (scaleBy) {
                // Center of viewport
                var zoomX = -this.x + Math.min(this.canvasProperties.ViewWidth, this.width) / 2 / this.scale;
                var zoomY = -this.y + Math.min(this.canvasProperties.ViewHeight, this.height) / 2 / this.scale;
                this.zoomAround(scaleBy, zoomX, zoomY);
            };
            ;
            CanvasZoom.prototype.ExecuteZoom = function (e) {
                if (e === void 0) { e = null; }
                // We only calculate the pinch center on the first pinch event as we want the center to
                // stay consistent during the entire pinch
                if (this.pinchCenter === null) {
                    if (e)
                        this.pinchCenter = this.rawCenter(e);
                    else {
                        this.pinchCenter = { x: this.canvasProperties.ViewImageWidth / 2, y: this.canvasProperties.ViewImageHeight / 2 };
                    }
                    if (this.canvasProperties.DimensionsFlipped) {
                        var offsetX = this.pinchCenter.x * this.scale - (-this.x * this.scale + Math.min(this.canvasProperties.ViewWidth, this.height) / 2);
                        var offsetY = this.pinchCenter.y * this.scale - (-this.y * this.scale + Math.min(this.canvasProperties.ViewWidth, this.width) / 2);
                        this.pinchCenterOffset = { x: offsetX, y: offsetY };
                    }
                    else {
                        var offsetX = this.pinchCenter.x * this.scale - (-this.x * this.scale + Math.min(this.canvasProperties.ViewWidth, this.width) / 2);
                        var offsetY = this.pinchCenter.y * this.scale - (-this.y * this.scale + Math.min(this.canvasProperties.ViewHeight, this.height) / 2);
                        this.pinchCenterOffset = { x: offsetX, y: offsetY };
                    }
                }
                // When the user pinch zooms, she/he expects the pinch center to remain in the same
                // relative location of the screen. To achieve this, the raw zoom center is calculated by
                // first storing the pinch center and the this.scaled offset to the current center of the
                // image. The new this.scale is then used to calculate the zoom center. This has the effect of
                // actually translating the zoom center on each pinch zoom event.
                var newScale;
                if (e)
                    newScale = this.restrictScale(this.scale * e.scale);
                else
                    newScale = 1;
                var zoomCenter = null;
                var zoomX = this.pinchCenter.x * newScale - this.pinchCenterOffset.x;
                var zoomY = this.pinchCenter.y * newScale - this.pinchCenterOffset.y;
                zoomCenter = { x: zoomX / newScale, y: zoomY / newScale };
                if (e) {
                    this.zoomAround(e.scale, zoomCenter.x, zoomCenter.y, true);
                }
                else {
                    this.zoomAround(1, zoomCenter.x, zoomCenter.y);
                    this.pinchCenter = null;
                }
            };
            CanvasZoom.prototype.OnPinchStart = function (e) {
                if (e.scale >= 1.2 || e.scale <= 0.8) {
                    this.ExecuteZoom(e);
                }
                else {
                    if (this.canvasProperties.DimensionsFlipped)
                        this.translate(e.deltaY, e.deltaX);
                    else
                        this.translate(e.deltaX, e.deltaY);
                }
            };
            CanvasZoom.prototype.OnPinchEnd = function (e) {
                this.updateLastScale();
                this.updateLastPos();
                this.pinchCenter = null;
            };
            CanvasZoom.MIN_SCALE = 1;
            CanvasZoom.MAX_SCALE = 5;
            return CanvasZoom;
        }());
        ImageEditor.CanvasZoom = CanvasZoom;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasZoom.js.map