var imgEditor = null;
var waitingProps = null;
if (MobileCRM.bridge.platform == "iOS") {
    MobileCRM.bridge.command("setScrollBounce", false);
}
// Zoom is handled internally within canvas
MobileCRM.bridge.command("enableZoom", false);
var openImageFromUrl = function (canvasProperties) {
    if (imgEditor)
        imgEditor.openImageFromUrl(canvasProperties);
    else
        waitingProps = canvasProperties;
};
var saveImage = function () {
    if (imgEditor)
        imgEditor.exportEditedImage();
};
var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        // Initialize elements
        var canvasWrapper = document.querySelector('#canvas-wrapper');
        var viewCanvas = document.querySelector('#edit-photo-canvas');
        var bottomMenu = document.querySelector('#bottom-menu');
        var editMenuButton = document.querySelector('#edit-menu-button');
        var editMenuSVG = document.querySelector('#edit-menu-svg');
        var editMenuButtonPath = document.querySelector('#edit-menu-button-path');
        // const editMenu = <HTMLDivElement>document.querySelector('#edit-menu');
        var writingFontSize = document.querySelector('#writing-font-size');
        var writingFontSizeInput = document.querySelector('#writing-font-size-input');
        var colorPickerButton = document.querySelector('#toggle-color-picker');
        var colorPicker = document.querySelector('#color-picker');
        var colorPickerCircle = document.querySelector('#color-picker-circle');
        var sizePickerButton = document.querySelector('#toggle-size-picker');
        var sizePicker = document.querySelector('#size-picker');
        var sizePickerList = document.querySelector('#size-picker-list');
        // const opacityPickerButton = <HTMLButtonElement>document.querySelector('#toggle-opacity-picker');
        // const opacityPicker = <HTMLDivElement>document.querySelector('#opacity-picker');
        // const opacityPickerList = <HTMLUListElement>document.querySelector('#opacity-picker-list');
        var undoButton = document.querySelector('#undo-button');
        var redoButton = document.querySelector('#redo-button');
        var rotateButton = document.querySelector('#rotate-button');
        var cropButton = document.querySelector('#crop-button');
        var writeButton = document.querySelector('#write-button');
        var saveButton = document.querySelector('#save-button');
        var cancelButton = document.querySelector('#cancel-button');
        imgEditor = new ImageEditor.ImageEditor(canvasWrapper, viewCanvas, bottomMenu, editMenuButton, editMenuSVG, editMenuButtonPath, 
        // editMenu,
        writingFontSize, writingFontSizeInput, colorPickerButton, colorPicker, colorPickerCircle, sizePickerButton, sizePicker, sizePickerList, 
        /*opacityPickerButton,
        opacityPicker,
        opacityPickerList,*/
        undoButton, redoButton, rotateButton, cropButton, writeButton, saveButton, cancelButton);
        if (waitingProps !== null)
            imgEditor.openImageFromUrl(waitingProps);
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=index.js.map