var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var ColorPicker = /** @class */ (function () {
            /**
             * Creates container containing both color picker and opacity picker
             * @param colorsContainer div element where the color choices should be added
             * @param opacitiesContainer div element where the opacity choices should be added
             * @param colors hex strings with colors to allow the user to choose from
             * @param opacities number values between 0 and 1 to let user to choose from
             * @param colorDiameter width and height of the square that interprets the user the color or opacity
             * @param defaultColor defaultly chosen color that is used on startup
             */
            function ColorPicker(colorsContainer, 
                // private opacitiesContainer: HTMLDivElement,
                changeCallback, 
                // pastel colors: red, green, yellow, blue, violet, gray, white, black
                colors, opacities, colorDiameter, currentColor, currentOpacity) {
                // pastel colors: red, green, yellow, blue, violet, gray, white, black
                if (colors === void 0) { colors = ['#F45656', '#03C03C', '#FDFD96', '#779ECB', '#CB99C9', '#CFCFC4', '#FFFFFF', '#000000']; }
                if (opacities === void 0) { opacities = [1, 0.75, 0.5, 0.25]; }
                if (colorDiameter === void 0) { colorDiameter = '30px'; }
                if (currentColor === void 0) { currentColor = 0; }
                if (currentOpacity === void 0) { currentOpacity = 0; }
                this.colorsContainer = colorsContainer;
                this.changeCallback = changeCallback;
                this.opacities = opacities;
                this.colorDiameter = colorDiameter;
                this.currentColor = currentColor;
                this.currentOpacity = currentOpacity;
                this.colors = [];
                // Setup container for colors
                if (!colorsContainer)
                    throw "Container for colors cannot be empty";
                /* Setup container for opacities
                if (!opacitiesContainer)
                    throw "Container for opacities cannot be empty";*/
                // Setup colors
                if (!colors || colors.length === 0)
                    throw "Colors cannot be empty";
                for (var _i = 0, colors_1 = colors; _i < colors_1.length; _i++) {
                    var c = colors_1[_i];
                    this.colors.push(new Color(c));
                }
                this.createColoPickerMenu();
                this.createOpacityPickerMenu();
            }
            ColorPicker.prototype.createColoPickerMenu = function () {
                var _this = this;
                var colorPickerMenu = document.createElement('UL');
                colorPickerMenu.style.margin = "0";
                colorPickerMenu.className = "picker-list";
                var _loop_1 = function (color) {
                    var colorPickerMenuItem = document.createElement('LI');
                    colorPickerMenuItem.className = "picker-option";
                    if (this_1.currentColor === this_1.colors.indexOf(color))
                        colorPickerMenuItem.classList.add('selected');
                    colorPickerMenuItem.style.backgroundColor = color.getRGBAString();
                    colorPickerMenuItem.style.cursor = "pointer";
                    colorPickerMenuItem.id = 'picker_color_' + color.Hex;
                    colorPickerMenuItem.style.width = this_1.colorDiameter;
                    colorPickerMenuItem.style.height = this_1.colorDiameter;
                    colorPickerMenuItem.style.borderRadius = '50%';
                    colorPickerMenuItem.style["-ms-user-select"] = "none";
                    colorPickerMenuItem.style["user-select"] = "none";
                    colorPickerMenuItem.style.msUserSelect = "none";
                    colorPickerMenuItem.onclick = function (ev) {
                        document.getElementById('picker_color_' + _this.colors[_this.currentColor].Hex).classList.remove('selected');
                        document.getElementById('picker_color_' + color.Hex).classList.add('selected');
                        _this.currentColor = _this.colors.indexOf(color);
                        _this.changeCallback(color.getRGBAString(_this.opacities[_this.currentOpacity]));
                    };
                    colorPickerMenu.appendChild(colorPickerMenuItem);
                };
                var this_1 = this;
                // Add color pallete
                for (var _i = 0, _a = this.colors; _i < _a.length; _i++) {
                    var color = _a[_i];
                    _loop_1(color);
                }
                this.colorsContainer.appendChild(colorPickerMenu);
            };
            ColorPicker.prototype.createOpacityPickerMenu = function () {
                var _this = this;
                var opacityPickerMenu = document.createElement('UL');
                opacityPickerMenu.style.margin = "0";
                opacityPickerMenu.className = "picker-list";
                var _loop_2 = function (opacity) {
                    var placeholderColor = new Color('#000000');
                    placeholderColor.Opacity = opacity;
                    var opacityPickerMenuItem = document.createElement('LI');
                    opacityPickerMenuItem.className = "picker-option";
                    if (this_2.currentOpacity === this_2.opacities.indexOf(opacity))
                        opacityPickerMenuItem.classList.add('selected');
                    opacityPickerMenuItem.style.backgroundColor = placeholderColor.getRGBAString();
                    opacityPickerMenuItem.style.cursor = "pointer";
                    opacityPickerMenuItem.id = 'picker_opacity_' + opacity;
                    opacityPickerMenuItem.style.width = this_2.colorDiameter;
                    opacityPickerMenuItem.style.height = this_2.colorDiameter;
                    opacityPickerMenuItem.style.borderRadius = '50%';
                    opacityPickerMenuItem.style["-ms-user-select"] = "none";
                    opacityPickerMenuItem.style["user-select"] = "none";
                    opacityPickerMenuItem.style.msUserSelect = "none";
                    opacityPickerMenuItem.textContent = "α";
                    opacityPickerMenuItem.style.color = '#FFF';
                    opacityPickerMenuItem.style.display = 'flex';
                    opacityPickerMenuItem.style.alignItems = 'center';
                    opacityPickerMenuItem.style.justifyContent = 'center';
                    opacityPickerMenuItem.onclick = function (ev) {
                        document.getElementById('picker_opacity_' + _this.opacities[_this.currentOpacity]).classList.remove('selected');
                        document.getElementById('picker_opacity_' + opacity).classList.add('selected');
                        _this.currentOpacity = _this.opacities.indexOf(opacity);
                        _this.changeCallback(_this.colors[_this.currentColor].getRGBAString(opacity));
                    };
                    opacityPickerMenu.appendChild(opacityPickerMenuItem);
                };
                var this_2 = this;
                // Add opacity pallete
                for (var _i = 0, _a = this.opacities; _i < _a.length; _i++) {
                    var opacity = _a[_i];
                    _loop_2(opacity);
                }
                this.colorsContainer.appendChild(opacityPickerMenu);
            };
            return ColorPicker;
        }());
        ImageEditor.ColorPicker = ColorPicker;
        var Color = /** @class */ (function () {
            /**
             * Constructs color object in accordance to the passed in object
             * @param color Color in the HEX, RGB or RGBA format
             */
            function Color(color) {
                this.hex = '#000000';
                this.opacity = 1;
                this.r = 0;
                this.g = 0;
                this.b = 0;
                this.setColor(color);
            }
            Color.prototype.removeWhiteSpaces = function (str_array) {
                for (var i = 0; i < str_array.length; i++) {
                    // Trim the excess whitespace.
                    str_array[i] = str_array[i].replace(/^\s*/, "").replace(/\s*$/, "");
                }
                return str_array;
            };
            /**
             * Set properties of color object according to the color value
             * @param color Color in the HEX, RGB or RGBA format
             * @param opacity Opacity of the color as number in range 0..1
             */
            Color.prototype.setColor = function (color, opacity) {
                if (opacity === void 0) { opacity = 1; }
                if (color.substring(0, 3) === "rgb") {
                    var rgb = void 0;
                    if (color.substring(0, 4) === "rgba") {
                        rgb = this.removeWhiteSpaces(color.substring("rgba(".length, color.lastIndexOf(")")).split(","));
                        this.opacity = parseInt(rgb[3]);
                    }
                    else {
                        rgb = this.removeWhiteSpaces(color.substring("rgb(".length, color.lastIndexOf(")")).split(","));
                    }
                    this.r = parseInt(rgb[0]);
                    this.g = parseInt(rgb[1]);
                    this.b = parseInt(rgb[2]);
                    this.hex = '#' + this.r.toString(16) + this.g.toString(16) + this.b.toString(16);
                }
                else if (color.substr(0, 1) === "#") {
                    var rgb = void 0;
                    rgb = parseInt(color.substring(1), 16); // strip # and convert rrggbb to decimal
                    this.r = (rgb >> 16) & 0xff; // extract red
                    this.g = (rgb >> 8) & 0xff; // extract green
                    this.b = (rgb >> 0) & 0xff; // extract blue
                    this.hex = color;
                }
                if (!isNaN(opacity)) {
                    this.opacity = opacity;
                }
            };
            Object.defineProperty(Color.prototype, "Opacity", {
                /**
                 * @returns opacity of color in the range 0..1
                 */
                get: function () {
                    return this.opacity;
                },
                /**
                 * @argument value opacity in range 0..1
                 */
                set: function (value) {
                    this.opacity = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color.prototype, "Hex", {
                /**
                 * @returns Color in the format '#rrggbb'
                 */
                get: function () {
                    return this.hex;
                },
                enumerable: true,
                configurable: true
            });
            Color.prototype.getRGBAString = function (opacity) {
                if (opacity && !isNaN(opacity))
                    return "rgba(" + this.r + "," + this.g + "," + this.b + "," + opacity + ")";
                return "rgba(" + this.r + "," + this.g + "," + this.b + "," + this.opacity + ")";
            };
            Object.defineProperty(Color.prototype, "RGBA", {
                /**
                 * @returns RGBA object containing each color as separate property
                 */
                get: function () {
                    return {
                        R: this.r,
                        G: this.g,
                        B: this.b,
                        A: this.opacity
                    };
                },
                enumerable: true,
                configurable: true
            });
            return Color;
        }());
        ImageEditor.Color = Color;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=ColorPicker.js.map