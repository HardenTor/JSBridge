var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var SizePicker = /** @class */ (function () {
            function SizePicker(sizePickerListEl, changeCallback, brushSizes, currentSize) {
                if (brushSizes === void 0) { brushSizes = [3, 5, 10, 15]; }
                if (currentSize === void 0) { currentSize = 0; }
                var _this = this;
                this.changeCallback = changeCallback;
                this.brushSizes = brushSizes;
                this.currentSize = currentSize;
                var sizePickerCanvas = document.createElement('canvas');
                var sizePickerCtx = sizePickerCanvas.getContext('2d');
                sizePickerCtx.strokeStyle = '#000000';
                sizePickerCanvas.width = 60;
                sizePickerCanvas.height = 30;
                var _loop_1 = function (i) {
                    var brushSize = brushSizes[i];
                    sizePickerCtx.lineWidth = brushSize;
                    sizePickerCtx.moveTo(0, sizePickerCtx.canvas.height / 2);
                    sizePickerCtx.lineTo(sizePickerCtx.canvas.width, sizePickerCtx.canvas.height / 2);
                    sizePickerCtx.stroke();
                    var sizePickerMenuItem = document.createElement('LI');
                    sizePickerMenuItem.className = "size-picker-option";
                    if (this_1.currentSize === i)
                        sizePickerMenuItem.classList.add('selected');
                    sizePickerMenuItem.style.cursor = "pointer";
                    sizePickerMenuItem.id = 'picker_brush_size_' + brushSize;
                    sizePickerMenuItem.style["-ms-user-select"] = "none";
                    sizePickerMenuItem.style["user-select"] = "none";
                    sizePickerMenuItem.style.msUserSelect = "none";
                    sizePickerMenuItem.onclick = function (ev) {
                        document.getElementById('picker_brush_size_' + _this.brushSizes[_this.currentSize]).classList.remove('selected');
                        document.getElementById('picker_brush_size_' + brushSize).classList.add('selected');
                        _this.currentSize = _this.brushSizes.indexOf(brushSize);
                        _this.changeCallback(brushSize);
                    };
                    var imgExampleItem = document.createElement('IMG');
                    imgExampleItem.src = sizePickerCanvas.toDataURL("image/png", 1.0);
                    sizePickerMenuItem.appendChild(imgExampleItem);
                    sizePickerListEl.appendChild(sizePickerMenuItem);
                };
                var this_1 = this;
                for (var i = 0; i < brushSizes.length; i++) {
                    _loop_1(i);
                }
            }
            return SizePicker;
        }());
        ImageEditor.SizePicker = SizePicker;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=SizePicker.js.map