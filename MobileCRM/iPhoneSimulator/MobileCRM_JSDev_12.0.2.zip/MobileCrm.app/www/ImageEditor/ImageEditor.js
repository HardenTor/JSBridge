var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var Hammer;
var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor_1) {
        var ImageEditor = /** @class */ (function () {
            function ImageEditor(canvasWrapperEl, viewCanvasEl, bottomMenuEl, editMenuButtonEl, editMenuSVGEl, editMenuButtonPathEl, 
                // private editMenuEl: HTMLDivElement,
                writingFontSizeEl, writingFontSizeInputEl, colorPickerButtonEl, colorPickerEl, colorPickerCircleEl, sizePickerButtonEl, sizePickerEl, sizePickerListEl, 
                // private opacityPickerButtonEl: HTMLButtonElement,
                // private opacityPickerEl: HTMLDivElement,
                // private opacityPickerListEl: HTMLUListElement,
                undoButtonEl, redoButtonEl, rotateButtonEl, cropButtonEl, writeButtonEl, saveButtonEl, cancelButtonEl) {
                var _this = this;
                this.canvasWrapperEl = canvasWrapperEl;
                this.viewCanvasEl = viewCanvasEl;
                this.bottomMenuEl = bottomMenuEl;
                this.editMenuButtonEl = editMenuButtonEl;
                this.editMenuSVGEl = editMenuSVGEl;
                this.editMenuButtonPathEl = editMenuButtonPathEl;
                this.writingFontSizeEl = writingFontSizeEl;
                this.writingFontSizeInputEl = writingFontSizeInputEl;
                this.colorPickerButtonEl = colorPickerButtonEl;
                this.colorPickerEl = colorPickerEl;
                this.colorPickerCircleEl = colorPickerCircleEl;
                this.sizePickerButtonEl = sizePickerButtonEl;
                this.sizePickerEl = sizePickerEl;
                this.sizePickerListEl = sizePickerListEl;
                this.undoButtonEl = undoButtonEl;
                this.redoButtonEl = redoButtonEl;
                this.rotateButtonEl = rotateButtonEl;
                this.cropButtonEl = cropButtonEl;
                this.writeButtonEl = writeButtonEl;
                this.saveButtonEl = saveButtonEl;
                this.cancelButtonEl = cancelButtonEl;
                // default drawing styles
                this.drawingStyles = {
                    PenWidth: 5,
                    PenColor: '#f45656',
                    TextColor: '#f45656',
                    LineJoin: 'round',
                    LineCap: 'round'
                };
                this.state = ImageEditorState.INIT;
                this.editMenuVisible = false;
                this.isFormDirty = false;
                // Contexts
                this.canvas = document.createElement('canvas');
                this.ctx = this.canvas.getContext('2d');
                this.viewCtx = null;
                this.isVisibleSizePicker = false;
                this.isVisibleColorPicker = false;
                // private isVisibleOpacityPicker: boolean = false;
                // History of the drawing
                this.undoSteps = 0;
                this.redoSteps = 0;
                this.currentPathIndex = 0;
                this.paths = [];
                this.onMouseDownBinded = this.onMouseDown.bind(this);
                this.onTouchStartBinded = this.onTouchStart.bind(this);
                this.onMousemoveBinded = this.onMousemove.bind(this);
                this.onTouchMoveBinded = this.onTouchMove.bind(this);
                this.onMouseUpBinded = this.onMouseUp.bind(this);
                this.onTouchEndBinded = this.onTouchEnd.bind(this);
                this.onPinchBinded = this.onPinch.bind(this);
                this.onPinchEndBinded = this.onPinchEnd.bind(this);
                this.canvasProperties = new ImageEditor_1.CanvasImageProperties(viewCanvasEl);
                this.viewCtx = viewCanvasEl.getContext('2d');
                // Enable zooming by pinch
                // this.hammer = new Hammer(canvasWrapperEl, { domEvents: true });
                // this.hammer.get('pinch').set({ enable: true });
                this.canvasZoom = new ImageEditor_1.CanvasZoom(canvasWrapperEl, viewCanvasEl, this.canvasProperties);
                this.colorPicker = new ImageEditor_1.ColorPicker(colorPickerEl, function (RGBAColor) {
                    _this.colorPickerCircleEl.style.fill = RGBAColor;
                    _this.drawingStyles.PenColor = RGBAColor;
                    _this.loadStyles();
                    if (_this.writer)
                        _this.writer.ChangeColor(RGBAColor);
                });
                this.sizePicker = new ImageEditor_1.SizePicker(sizePickerListEl, function (lineSize) {
                    _this.drawingStyles.PenWidth = lineSize;
                    _this.loadStyles();
                });
                window.onresize = function (e) { return _this.onWindowResize(e); };
                canvasWrapperEl.addEventListener('click', function (e) { return _this.hidePickers(e); }, false);
                bottomMenuEl.addEventListener('click', function (e) { return _this.hidePickers(e); }, false);
                rotateButtonEl.addEventListener('click', function (e) { return _this.onRotateButtonClicked(e); }, false);
                undoButtonEl.addEventListener('click', function (e) { return _this.undoStep(e); }, false);
                redoButtonEl.addEventListener('click', function (e) { return _this.redoStep(e); }, false);
                colorPickerButtonEl.addEventListener('click', function (e) { return _this.toggleColorPicker(e); }, false);
                // opacityPickerButtonEl.addEventListener('click', (e) => this.toggleOpacityPicker(e), false);
                sizePickerButtonEl.addEventListener('click', function (e) { return _this.toggleSizePicker(e); }, false);
                canvasWrapperEl.addEventListener("mousewheel", function (e) { return _this.onCanvasMousewheel(e); });
                cropButtonEl.addEventListener('click', function (e) { return _this.enableCrop(e); }, false);
                writeButtonEl.addEventListener('click', function (e) { return _this.enableWriting(e); }, false);
                cancelButtonEl.addEventListener('click', function (e) { return _this.onCancelButtonClick(e); }, false);
                saveButtonEl.addEventListener('click', function (e) { return _this.onSaveButtonClick(e); });
                // editMenuButtonEl.addEventListener('click', (e) => this.toggleEditMenu(e), false);
                if (typeof MobileCRM === 'undefined' || !MobileCRM) {
                    this.canvasProperties.ImagePath = './test_image.jpg';
                    this.canvasProperties.MakeFormDirty();
                    this.canvasProperties.Rotation = 0;
                    this.canvasProperties.MimeType = null;
                    this.openImageFromUrl(this.canvasProperties);
                }
            }
            ImageEditor.prototype.setupSizes = function () {
                var isBottomMenuHidden = this.bottomMenuEl.style.display === "none";
                if (isBottomMenuHidden)
                    this.bottomMenuEl.style.display = "";
                var maxCanvasWidth = document.body.clientWidth;
                var maxCanvasHeight = document.body.clientHeight - this.bottomMenuEl.clientHeight;
                if (this.canvasProperties.DimensionsFlipped) {
                    maxCanvasWidth = document.body.clientHeight - this.bottomMenuEl.clientHeight;
                    maxCanvasHeight = document.body.clientWidth;
                }
                this.canvasWrapperEl.style.width = maxCanvasWidth + 'px';
                this.canvasWrapperEl.style.height = maxCanvasHeight + 'px';
                if (this.canvasProperties.DimensionsFlipped) {
                    this.canvasWrapperEl.style.width = maxCanvasHeight + 'px';
                    this.canvasWrapperEl.style.height = maxCanvasWidth + 'px';
                }
                this.canvasProperties.ViewWidth = maxCanvasWidth;
                this.canvasProperties.ViewHeight = maxCanvasHeight;
                this.updatePickersPositions();
                if (this.bottomMenuEl.style.display)
                    this.bottomMenuEl.style.display = "none";
            };
            ImageEditor.prototype.updatePickersPositions = function () {
                // Set pickers position
                this.sizePickerEl.style.bottom = -window.innerHeight + "px";
                this.colorPickerEl.style.bottom = -window.innerHeight + "px";
                // this.opacityPickerEl.style.bottom = -window.innerHeight + "px";
                this.sizePickerEl.style.left = (this.sizePickerButtonEl.offsetLeft + this.sizePickerButtonEl.clientWidth / 2 - this.sizePickerEl.clientWidth / 2) + "px";
                this.colorPickerEl.style.left = (this.colorPickerButtonEl.offsetLeft + this.colorPickerButtonEl.clientWidth / 2 - this.colorPickerEl.clientWidth / 2) + "px";
                // this.opacityPickerEl.style.left = (this.opacityPickerButtonEl.offsetLeft + this.opacityPickerButtonEl.clientWidth / 2 - this.opacityPickerEl.clientWidth / 2) + "px";
            };
            ImageEditor.prototype.loadStyles = function (styles, softUpdate) {
                if (styles === void 0) { styles = this.drawingStyles; }
                if (softUpdate === void 0) { softUpdate = false; }
                this.ctx.strokeStyle = styles.PenColor;
                this.ctx.fillStyle = styles.PenColor;
                this.ctx.lineJoin = styles.LineJoin;
                this.ctx.lineCap = styles.LineCap;
                this.ctx.lineWidth = styles.PenWidth * (this.ctx.canvas.width / this.canvasProperties.ViewImageWidth);
                if (!softUpdate) {
                    this.viewCtx.strokeStyle = styles.PenColor;
                    this.viewCtx.fillStyle = styles.PenColor;
                    if (this.canvasProperties.Scale == 1)
                        this.viewCtx.lineWidth = styles.PenWidth;
                    else
                        this.viewCtx.lineWidth = styles.PenWidth * this.canvasProperties.Scale;
                    this.viewCtx.lineJoin = styles.LineJoin;
                    this.viewCtx.lineCap = styles.LineCap;
                    this.colorPickerCircleEl.style.fill = styles.PenColor;
                }
            };
            ImageEditor.prototype.redrawViewCanvas = function () {
                this.viewCtx.clearRect(0, 0, this.viewCtx.canvas.width, this.viewCtx.canvas.height);
                this.viewCtx.save();
                this.viewCtx.setTransform(1, 0, 0, 1, 0, 0);
                this.viewCtx.translate(this.viewCtx.canvas.width / 2, this.viewCtx.canvas.height / 2);
                this.viewCtx.rotate(this.canvasProperties.Rotation * Math.PI / 180);
                if (this.canvasProperties.DimensionsFlipped)
                    this.viewCtx.translate(-this.viewCtx.canvas.height / 2, -this.viewCtx.canvas.width / 2);
                else
                    this.viewCtx.translate(-this.viewCtx.canvas.width / 2, -this.viewCtx.canvas.height / 2);
                this.viewCtx.scale(1 / this.canvasProperties.ImageRatio, 1 / this.canvasProperties.ImageRatio);
                this.viewCtx.drawImage(this.editedImage, 0, 0);
                this.viewCtx.drawImage(this.canvas, 0, 0);
                this.viewCtx.restore();
            };
            ImageEditor.prototype.loadImageRoutine = function (background) {
                return __awaiter(this, void 0, void 0, function () {
                    return __generator(this, function (_a) {
                        // Initiate margins to zero
                        this.viewCanvasEl.style.margin = '0px';
                        // Setup canvas size
                        this.setupSizes();
                        if (this.state === ImageEditorState.INIT) {
                            this.ctx.canvas.width = background.width;
                            this.ctx.canvas.height = background.height;
                        }
                        this.canvasProperties.ImageHeight = background.height;
                        this.canvasProperties.ImageWidth = background.width;
                        // set default canvas scale and zoom
                        this.canvasZoom.ExecuteZoom();
                        if (this.state === ImageEditorState.INIT) {
                            this.ChangeState(ImageEditorState.DRAW);
                            this.activateGestureHandling();
                        }
                        this.redrawViewCanvas();
                        this.loadStyles();
                        this.hidePickers();
                        return [2 /*return*/];
                    });
                });
            };
            ImageEditor.prototype.openImageFromUrl = function (canvasProperties) {
                return __awaiter(this, void 0, void 0, function () {
                    var _this = this;
                    var background;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                if (canvasProperties instanceof ImageEditor_1.CanvasImageProperties) {
                                    this.canvasProperties = canvasProperties;
                                }
                                else {
                                    this.canvasProperties.ImagePath = canvasProperties.imagePath;
                                    this.canvasProperties.MimeType = canvasProperties.mimeType;
                                    this.canvasProperties.Rotation = canvasProperties.rotation;
                                }
                                background = new Image();
                                this.canvasProperties.ImagePath = decodeURIComponent(this.canvasProperties.ImagePath);
                                MobileCRM.bridge.command("showLoad", null, null, null, null);
                                if (!(this.editedImage != null)) return [3 /*break*/, 2];
                                return [4 /*yield*/, this.loadImageRoutine(this.editedImage)];
                            case 1:
                                _a.sent();
                                MobileCRM.bridge.command("hideLoad", null, null, null, null);
                                return [3 /*break*/, 3];
                            case 2:
                                background.onload = function () { return __awaiter(_this, void 0, void 0, function () {
                                    return __generator(this, function (_a) {
                                        switch (_a.label) {
                                            case 0:
                                                this.editedImage = background;
                                                return [4 /*yield*/, this.loadImageRoutine(this.editedImage)];
                                            case 1:
                                                _a.sent();
                                                MobileCRM.bridge.command("hideLoad", null, null, null, null);
                                                return [2 /*return*/];
                                        }
                                    });
                                }); };
                                background.onerror = function (args) {
                                    MobileCRM.bridge.command("hideLoad", null, null, null, null);
                                    document.write("Image Loading Error");
                                };
                                background.src = this.canvasProperties.ImagePath;
                                _a.label = 3;
                            case 3: return [2 /*return*/];
                        }
                    });
                });
            };
            ImageEditor.prototype.onWindowResize = function (e) {
                return __awaiter(this, void 0, void 0, function () {
                    var obj;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0:
                                // Ignore resize on Android when keyboard is shown
                                if (document.activeElement && document.activeElement.tagName === 'INPUT') {
                                    return [2 /*return*/];
                                }
                                if (!(this.state !== ImageEditorState.INIT && this.canvasProperties)) return [3 /*break*/, 2];
                                // Redraw the drawing with new size
                                return [4 /*yield*/, this.openImageFromUrl(this.canvasProperties)];
                            case 1:
                                // Redraw the drawing with new size
                                _a.sent();
                                if (this.state === ImageEditorState.CROP) {
                                    this.selection.dispose();
                                    this.selection = new ImageEditor_1.CanvasCropper(this.viewCanvasEl, this.canvas, this.editedImage, this.canvasProperties);
                                }
                                if (this.state === ImageEditorState.TEXT) {
                                    obj = this.writer.dispose();
                                    this.writer = new ImageEditor_1.CanvasWriter(this.viewCanvasEl, this.canvas, this.editedImage, this.canvasProperties, this.writingFontSizeInputEl, this.drawingStyles.PenColor, obj.text, obj.input);
                                }
                                _a.label = 2;
                            case 2: return [2 /*return*/];
                        }
                    });
                });
            };
            ImageEditor.prototype.toggleColorPicker = function (e) {
                if (!this.isVisibleColorPicker) {
                    this.colorPickerEl.style.bottom = this.bottomMenuEl.clientHeight + "px";
                    this.isVisibleColorPicker = true;
                }
                else {
                    this.hidePickers();
                }
            };
            /* If the opacity picker is not visible toggle it from bottom of the page,
            // if it is already visible, hide it
            private toggleOpacityPicker(e) {
                if (!this.isVisibleOpacityPicker) {
                    this.opacityPickerEl.style.bottom = this.bottomMenuEl.clientHeight + "px";
                    this.isVisibleOpacityPicker = true;
                } else {
                    this.hidePickers();
                }
            }*/
            ImageEditor.prototype.toggleSizePicker = function (e) {
                if (!this.isVisibleSizePicker) {
                    this.sizePickerEl.style.bottom = this.bottomMenuEl.clientHeight + "px";
                    //sizePicker.style.left = (3 * (window.innerWidth / 8) - sizePicker.clientWidth / 2) + "px";
                    this.isVisibleSizePicker = true;
                }
                else {
                    this.hidePickers();
                }
            };
            ImageEditor.prototype.getMousePos = function (canvasDom, mouseEvent) {
                var rect = canvasDom.getBoundingClientRect();
                return {
                    x: mouseEvent.clientX - rect.left,
                    y: mouseEvent.clientY - rect.top
                };
            };
            ImageEditor.prototype.rotateCoordinates = function (e) {
                var tmp;
                switch (this.canvasProperties.Rotation) {
                    case 90:
                        tmp = e.x;
                        e.x = e.y;
                        e.y = this.viewCtx.canvas.width - tmp;
                        break;
                    case 180:
                        e.x = this.viewCtx.canvas.width - e.x;
                        e.y = this.viewCtx.canvas.height - e.y;
                        break;
                    case 270:
                        tmp = e.y;
                        e.y = e.x;
                        e.x = this.viewCtx.canvas.height - tmp;
                        break;
                    default:
                        break;
                }
                return e;
            };
            ImageEditor.prototype.makeEntityDirty = function () {
                // make the form dirty
                if (!this.isFormDirty) {
                    MobileCRM.bridge.command("makeEntityDirty", "", null, null, null);
                    this.isFormDirty = true;
                }
            };
            // Redrawds canvas with the size of the original image with the moves from the array of moves
            ImageEditor.prototype.redrawCanvas = function (startIndex, endIndex) {
                var beginning = 0;
                var end = this.paths.length;
                if (!startIndex) {
                    this.ctx.clearRect(0, 0, this.ctx.canvas.width, this.ctx.canvas.height);
                    this.ctx.save();
                }
                else {
                    beginning = startIndex - 1;
                }
                if (endIndex != undefined)
                    end = endIndex;
                for (var i = beginning; i < end; i++) {
                    var scale = this.paths[i][0].scale;
                    this.loadStyles(this.paths[i][0].styles, true);
                    this.ctx.beginPath();
                    this.ctx.moveTo(this.paths[i][0].x * scale, this.paths[i][0].y * scale);
                    if (this.paths[i][0].type == 'arc') {
                        this.ctx.arc(this.paths[i][0].x * scale, this.paths[i][0].y * scale, this.ctx.lineWidth / 2, 0, 2 * Math.PI);
                        this.ctx.fill();
                    }
                    else {
                        for (var j = 1; j < this.paths[i].length; j++)
                            this.ctx.lineTo(this.paths[i][j].x * scale, this.paths[i][j].y * scale);
                        this.ctx.stroke();
                    }
                }
                if (!startIndex) {
                    this.ctx.restore();
                }
            };
            ImageEditor.prototype.renderCanvas = function () {
                if (this.state === ImageEditorState.DRAWING) {
                    this.viewCtx.lineTo(this.mousePosition.x, this.mousePosition.y);
                    this.viewCtx.stroke();
                }
            };
            ImageEditor.prototype.onMouseDown = function (e) {
                // If the either of the pickers is visible close it
                this.hidePickers();
                if (this.state === ImageEditorState.DRAW) {
                    // Delete redo paths
                    this.redoSteps = 0;
                    this.undoSteps++;
                    this.makeEntityDirty();
                    this.ChangeState(ImageEditorState.DRAWING);
                    this.previousMousePosition = this.getMousePos(this.viewCanvasEl, e);
                    // at first draw a circle on the user's start point
                    this.viewCtx.save();
                    this.viewCtx.beginPath();
                    this.viewCtx.moveTo(this.previousMousePosition.x, this.previousMousePosition.y);
                    this.viewCtx.arc(this.previousMousePosition.x, this.previousMousePosition.y, this.viewCtx.lineWidth / 2, 0, 2 * Math.PI);
                    this.viewCtx.fill();
                    this.paths[this.currentPathIndex] = [];
                    this.paths[this.currentPathIndex++].push(this.rotateCoordinates({ x: this.previousMousePosition.x, y: this.previousMousePosition.y, styles: Object.assign({}, this.drawingStyles), scale: this.canvasProperties.ImageRatio, type: 'arc' }));
                    // continue with drawing the line
                    this.viewCtx.beginPath();
                    this.viewCtx.moveTo(this.previousMousePosition.x, this.previousMousePosition.y);
                    this.paths[this.currentPathIndex] = [];
                    this.paths[this.currentPathIndex].push(this.rotateCoordinates({ x: this.previousMousePosition.x, y: this.previousMousePosition.y, styles: Object.assign({}, this.drawingStyles), scale: this.canvasProperties.ImageRatio, type: 'stroke' }));
                }
            };
            ImageEditor.prototype.getTouchPos = function (canvasDom, touchEvent) {
                var rect = canvasDom.getBoundingClientRect();
                return {
                    x: touchEvent.touches[0].clientX - rect.left,
                    y: touchEvent.touches[0].clientY - rect.top
                };
            };
            ImageEditor.prototype.onTouchStart = function (e) {
                e.preventDefault();
                this.mousePosition = this.getTouchPos(this.viewCanvasEl, e);
                var touch = e.touches[0];
                var mouseEvent = new MouseEvent('mousedown', {
                    clientX: touch.clientX,
                    clientY: touch.clientY
                });
                this.viewCanvasEl.dispatchEvent(mouseEvent);
            };
            ImageEditor.prototype.onMousemove = function (e) {
                if (this.state === ImageEditorState.DRAWING) {
                    this.mousePosition = this.getMousePos(this.viewCanvasEl, e);
                    this.renderCanvas();
                    // save the path to memory
                    if (typeof this.paths[this.currentPathIndex] == 'undefined')
                        this.paths[this.currentPathIndex] = [];
                    if (this.paths[this.currentPathIndex].length == 0)
                        this.paths[this.currentPathIndex].push(this.rotateCoordinates({ x: this.mousePosition.x, y: this.mousePosition.y, styles: Object.assign({}, this.drawingStyles), scale: this.canvasProperties.ImageRatio, type: 'stroke' }));
                    this.paths[this.currentPathIndex].push(this.rotateCoordinates({ x: this.mousePosition.x, y: this.mousePosition.y }));
                }
            };
            ImageEditor.prototype.onTouchMove = function (e) {
                var touch = e.touches[0];
                var mouseEvent = new MouseEvent('mousemove', {
                    clientX: touch.clientX,
                    clientY: touch.clientY
                });
                this.viewCanvasEl.dispatchEvent(mouseEvent);
            };
            ImageEditor.prototype.onMouseUp = function (e) {
                if (this.state === ImageEditorState.DRAWING) {
                    this.currentPathIndex++;
                    this.redrawCanvas(0, this.currentPathIndex);
                    this.ChangeState(ImageEditorState.DRAW);
                    this.viewCtx.restore();
                    this.redrawViewCanvas();
                }
            };
            ImageEditor.prototype.onTouchEnd = function (e) {
                e.preventDefault();
                var mouseEvent = new MouseEvent('mouseup', {});
                this.viewCanvasEl.dispatchEvent(mouseEvent);
            };
            ImageEditor.prototype.onPinch = function (e) {
                if (this.state === ImageEditorState.DRAWING) {
                    this.viewCtx.restore();
                    // If the step is odd increase it
                    if (this.currentPathIndex % 2 != 0)
                        this.currentPathIndex--;
                    else
                        this.currentPathIndex -= 2;
                    this.redrawViewCanvas();
                }
                this.ChangeState(ImageEditorState.ZOOM);
                this.canvasZoom.OnPinchStart(e);
                this.redrawViewCanvas();
            };
            ImageEditor.prototype.onPinchEnd = function (e) {
                this.canvasZoom.OnPinchEnd(e);
                this.redrawViewCanvas();
                this.loadStyles(this.drawingStyles);
                this.ChangeState(ImageEditorState.DRAW);
            };
            // Turns on the event hadling of the functions in this file 
            // should be called at the end of the interaction with other modules that
            // listened to the events previously
            ImageEditor.prototype.activateGestureHandling = function () {
                this.viewCanvasEl.addEventListener('mousedown', this.onMouseDownBinded, false);
                this.viewCanvasEl.addEventListener('touchstart', this.onTouchStartBinded, false);
                this.viewCanvasEl.addEventListener('mousemove', this.onMousemoveBinded, false);
                this.viewCanvasEl.addEventListener('touchmove', this.onTouchMoveBinded, false);
                this.viewCanvasEl.addEventListener('mouseup', this.onMouseUpBinded, false);
                // Do not need to handle mouseleave when not drawing, we do not need to end the drawing action
                this.viewCanvasEl.addEventListener('mouseleave', this.onMouseUpBinded, false);
                this.viewCanvasEl.addEventListener('touchend', this.onTouchEndBinded, false);
                // this.hammer.on('pinch', this.onPinchBinded);
                // this.hammer.on('pinchend', this.onPinchEndBinded);
            };
            ImageEditor.prototype.disableGestureHandling = function () {
                this.viewCanvasEl.removeEventListener('mousedown', this.onMouseDownBinded, false);
                this.viewCanvasEl.removeEventListener('touchstart', this.onTouchStartBinded, false);
                this.viewCanvasEl.removeEventListener('mousemove', this.onMousemoveBinded, false);
                this.viewCanvasEl.removeEventListener('touchmove', this.onTouchMoveBinded, false);
                this.viewCanvasEl.removeEventListener('mouseup', this.onMouseUpBinded, false);
                // Do not need to handle mouseleave when not drawing, we do not need to end the drawing action
                this.viewCanvasEl.removeEventListener('mouseleave', this.onMouseUpBinded, false);
                this.viewCanvasEl.removeEventListener('touchend', this.onTouchEndBinded, false);
                // this.hammer.off('pinch', this.onPinchBinded);
                // this.hammer.off('pinchend', this.onPinchEndBinded);
            };
            ImageEditor.prototype.onRotateButtonClicked = function (e) {
                if (e === void 0) { e = null; }
                this.canvasProperties.Rotation += 90;
                // do resize and everything that is needed
                this.openImageFromUrl(this.canvasProperties);
                this.ChangeState(this.state);
                this.makeEntityDirty();
            };
            ;
            ImageEditor.prototype.onCanvasMousewheel = function (e) {
                this.hidePickers();
                if (this.state === ImageEditorState.DRAW
                    || this.state === ImageEditorState.DRAWING
                    || this.state === ImageEditorState.ZOOM) {
                    // Wheel delta is normally 120 so the zoom will be 1.2 on each turn
                    var ev = { scale: (e.wheelDelta > 0 ? 1.2 : 0.8), target: this, center: { x: e.x, y: e.y } };
                    // this.hammer.emit("pinch", ev);
                    // this.hammer.emit("pinchend", ev);
                }
            };
            // Crop Tool
            ImageEditor.prototype.enableCrop = function (e) {
                if (e === void 0) { e = null; }
                this.ChangeState(ImageEditorState.CROP);
                this.setupSizes();
                this.selection = new ImageEditor_1.CanvasCropper(this.viewCanvasEl, this.canvas, this.editedImage, this.canvasProperties);
            };
            ImageEditor.prototype.enableWriting = function (e) {
                if (e === void 0) { e = null; }
                this.ChangeState(ImageEditorState.TEXT);
                this.setupSizes();
                this.writer = new ImageEditor_1.CanvasWriter(this.viewCanvasEl, this.canvas, this.editedImage, this.canvasProperties, this.writingFontSizeInputEl, this.drawingStyles.PenColor);
            };
            // Exports image from the canvas with or without merging with background
            // doMergeLayers: true - to merge with background, false otherways
            ImageEditor.prototype.exportEditedImage = function () {
                var _this = this;
                // Show saving dialog
                MobileCRM.bridge.command("showLoad", null, null, null, null);
                var tmp_background = new Image();
                var tmp_drawing = new Image();
                // Rotate and redraw canvas before saving
                var exportRoutine = function (tmp_background, tmp_drawing) {
                    var temp_canvas = document.createElement("canvas");
                    var temp_ctx = temp_canvas.getContext("2d");
                    if (_this.canvasProperties.DimensionsFlipped) {
                        temp_ctx.canvas.width = tmp_background.height;
                        temp_ctx.canvas.height = tmp_background.width;
                    }
                    else {
                        temp_ctx.canvas.width = tmp_background.width;
                        temp_ctx.canvas.height = tmp_background.height;
                    }
                    temp_ctx.setTransform(1, 0, 0, 1, 0, 0);
                    temp_ctx.translate(temp_ctx.canvas.width / 2, temp_ctx.canvas.height / 2);
                    temp_ctx.rotate(_this.canvasProperties.Rotation * Math.PI / 180);
                    if (_this.canvasProperties.DimensionsFlipped)
                        temp_ctx.translate(-temp_ctx.canvas.height / 2, -temp_ctx.canvas.width / 2);
                    else
                        temp_ctx.translate(-temp_ctx.canvas.width / 2, -temp_ctx.canvas.height / 2);
                    temp_ctx.clearRect(0, 0, temp_ctx.canvas.width, temp_ctx.canvas.height);
                    temp_ctx.drawImage(tmp_drawing, 0, 0);
                    // Add background to the image
                    temp_ctx.globalCompositeOperation = 'destination-over';
                    temp_ctx.drawImage(tmp_background, 0, 0);
                    var imageDataUrl = temp_canvas.toDataURL(_this.canvasProperties.MimeType, 1.0);
                    MobileCRM.bridge.command("handleExportedImage", imageDataUrl, null, null, null);
                    // Hide saving dialog
                    MobileCRM.bridge.command("hideLoad", null, null, null, null);
                };
                // In case the image was cropped, do not load original image but load the edited image instead
                if (this.editedImage != null) {
                    tmp_drawing.onload = function () {
                        exportRoutine(_this.editedImage, tmp_drawing);
                    };
                    tmp_drawing.src = this.canvas.toDataURL("image/png", 1.0);
                }
                else {
                    // Needed to wait for image to load
                    tmp_background.onload = function () {
                        tmp_drawing.onload = function () {
                            exportRoutine(tmp_background, tmp_drawing);
                        };
                        tmp_drawing.src = _this.canvas.toDataURL("image/png", 1.0);
                    };
                    tmp_background.src = this.canvasProperties.ImagePath;
                }
            };
            ImageEditor.prototype.onSaveButtonClick = function (e) {
                if (e === void 0) { e = null; }
                switch (this.state) {
                    case ImageEditorState.CROP:
                        this.editedImage = this.selection.GetCroppedImageCanvas();
                        this.ChangeState(ImageEditorState.INIT);
                        this.undoSteps = 0;
                        this.redoSteps = 0;
                        this.currentPathIndex = 0;
                        this.paths = [];
                        this.openImageFromUrl(this.canvasProperties);
                        this.makeEntityDirty();
                        this.updatePickersPositions();
                        this.selection = null;
                        break;
                    case ImageEditorState.TEXT:
                        var newImage = this.writer.GetImageCanvasWithText();
                        if (newImage !== this.editedImage) {
                            this.editedImage = newImage;
                            this.ChangeState(ImageEditorState.INIT);
                            this.undoSteps = 0;
                            this.redoSteps = 0;
                            this.currentPathIndex = 0;
                            this.paths = [];
                            this.makeEntityDirty();
                            this.updatePickersPositions();
                        }
                        else {
                            this.ChangeState(ImageEditorState.DRAW);
                        }
                        this.openImageFromUrl(this.canvasProperties);
                        this.writer = null;
                        break;
                    default:
                        // DEPRECATED: This method should be called if the image should be saveable from ImageEditor toolbar
                        // this.exportEditedImage(true, null);
                        break;
                }
            };
            ImageEditor.prototype.onCancelButtonClick = function (e) {
                if (e === void 0) { e = null; }
                switch (this.state) {
                    case ImageEditorState.CROP:
                        this.ChangeState(ImageEditorState.DRAW);
                        this.selection.dispose();
                        this.openImageFromUrl(this.canvasProperties);
                        this.selection = null;
                        break;
                    case ImageEditorState.TEXT:
                        this.ChangeState(ImageEditorState.DRAW);
                        this.writer.dispose();
                        this.openImageFromUrl(this.canvasProperties);
                        this.writer = null;
                        break;
                }
            };
            /*private toggleEditMenu(e: MouseEvent = null) {
                let change = false;
    
                if (this.editMenuVisible || this.state === ImageEditorState.CROP) {
                    if (this.editMenuVisible)
                        change = true;
                    // this.editMenuEl.style.display = "none";
                    this.editMenuSVGEl.setAttribute("viewBox", "192 628 24 18");
                    this.editMenuButtonPathEl.setAttribute("transform", "translate(192 628)");
                    this.editMenuButtonPathEl.setAttribute("d", "M0,14v2H9V14H0M0,2V4H13V2H0M13,18V16H24V14H13V12H11v6h2M7,6V8H0v2H7v2H9V6H7m17,4V8H11v2H24M15,6h2V4h7V2H17V0H15Z");
                } else {
                    change = true;
                    // this.editMenuEl.style.display = "flex";
                    this.editMenuSVGEl.setAttribute("viewBox", "664 625 30 24");
                    this.editMenuButtonPathEl.setAttribute("transform", "translate(664 625)");
                    this.editMenuButtonPathEl.setAttribute("d", "M0,0V24H30V0ZM3,5H16V7H3Zm9,14H3V17h9Zm0-4H10V13H3V11h7V9h2Zm15,4H16v2H14V15h2v2H27Zm0-6H14V11H27Zm0-6H20V9H18V3h2V5h7Z");
                }
                if (change) {
                    this.editMenuVisible = !this.editMenuVisible;
                    this.openImageFromUrl(this.canvasProperties);
                    this.ChangeState(this.state);
                    this.updatePickersPositions();
                }
            }*/
            ImageEditor.prototype.isParent = function (childNode, parentNode) {
                var p = parentNode;
                var c = childNode;
                while (c !== null) {
                    if (c === p)
                        return true;
                    c = c.parentNode;
                }
                return false;
            };
            ImageEditor.prototype.hidePickers = function (e) {
                if (e === void 0) { e = null; }
                if ((e && this.isVisibleSizePicker && !this.isParent(e.target, this.sizePickerButtonEl)) || (!e && this.isVisibleSizePicker)) {
                    this.sizePickerEl.style.bottom = (-window.innerHeight) + "px";
                    this.isVisibleSizePicker = false;
                }
                if ((e && this.isVisibleColorPicker && !this.isParent(e.target, this.colorPickerButtonEl)) || (!e && this.isVisibleColorPicker)) {
                    this.colorPickerEl.style.bottom = (-window.innerHeight) + "px";
                    this.isVisibleColorPicker = false;
                }
                /*if ((e && this.isVisibleOpacityPicker && !this.isParent(e.target, this.opacityPickerButtonEl)) || (!e && this.isVisibleOpacityPicker)) {
                    this.opacityPickerEl.style.bottom = (-window.innerHeight) + "px";
                    this.isVisibleOpacityPicker = false;
                }*/
            };
            // removes any line or move previously done by user
            // adds information about it to the redo array so it can be reverted back if needed
            ImageEditor.prototype.undoStep = function (e) {
                if (this.undoSteps > 0) {
                    this.currentPathIndex -= 2;
                    this.undoSteps--;
                    this.redoSteps++;
                    this.redrawCanvas(0, this.currentPathIndex);
                    this.redrawViewCanvas();
                }
            };
            // If the user used undo but he/she wants the previous painting back it can be redone by this function
            ImageEditor.prototype.redoStep = function (e) {
                if (this.redoSteps > 0) {
                    this.redoSteps--;
                    this.undoSteps++;
                    this.currentPathIndex += 2;
                    this.redrawCanvas(0, this.currentPathIndex);
                    this.redrawViewCanvas();
                }
            };
            ImageEditor.prototype.ChangeState = function (state) {
                var prevState = this.state;
                this.state = state;
                if (state === ImageEditorState.INIT) {
                    this.bottomMenuEl.style.display = 'none';
                    this.sizePickerEl.style.display = 'none';
                    this.colorPickerEl.style.display = 'none';
                }
                else {
                    this.bottomMenuEl.style.display = '';
                    this.sizePickerEl.style.display = '';
                    this.colorPickerEl.style.display = '';
                }
                switch (state) {
                    case ImageEditorState.CROP:
                        this.undoButtonEl.hidden = true;
                        this.redoButtonEl.hidden = true;
                        this.saveButtonEl.hidden = false;
                        this.cancelButtonEl.hidden = false;
                        this.editMenuButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = true;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = true;
                        this.writingFontSizeEl.hidden = true;
                        this.cropButtonEl.hidden = true;
                        this.rotateButtonEl.hidden = true;
                        this.writeButtonEl.hidden = true;
                        this.disableGestureHandling();
                        break;
                    case ImageEditorState.DRAW:
                        /* if (!this.editMenuVisible) {
                            this.undoButtonEl.hidden = false;
                            this.redoButtonEl.hidden = false;
                            this.saveButtonEl.hidden = false;
                            this.cancelButtonEl.hidden = true;
                            if (prevState === ImageEditorState.CROP
                                || prevState === ImageEditorState.TEXT
                                || prevState === ImageEditorState.INIT)
                                this.activateGestureHandling();
                            this.editMenuButtonEl.hidden = false;
    
                            this.colorPickerButtonEl.hidden = true;
                            // this.opacityPickerButtonEl.hidden = false;
                            this.sizePickerButtonEl.hidden = true;
                            this.writingFontSizeEl.hidden = true;
                            this.cropButtonEl.hidden = true;
                            this.rotateButtonEl.hidden = true;
                            this.writeButtonEl.hidden = true;
                        } else { */
                        this.undoButtonEl.hidden = false;
                        this.redoButtonEl.hidden = false;
                        this.saveButtonEl.hidden = true;
                        this.cancelButtonEl.hidden = true;
                        if (prevState === ImageEditorState.CROP
                            || prevState === ImageEditorState.TEXT
                            || prevState === ImageEditorState.INIT)
                            this.activateGestureHandling();
                        this.editMenuButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = false;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = false;
                        this.writingFontSizeEl.hidden = true;
                        this.cropButtonEl.hidden = false;
                        this.rotateButtonEl.hidden = false;
                        this.writeButtonEl.hidden = false;
                        break;
                    case ImageEditorState.DRAWING:
                        /*if (!this.editMenuVisible) {
                            this.undoButtonEl.hidden = false;
                            this.redoButtonEl.hidden = false;
                            this.saveButtonEl.hidden = false;
                            this.cancelButtonEl.hidden = true;
                            this.editMenuButtonEl.hidden = false;
    
                            this.colorPickerButtonEl.hidden = true;
                            // this.opacityPickerButtonEl.hidden = false;
                            this.sizePickerButtonEl.hidden = true;
                            this.writingFontSizeEl.hidden = true;
                            this.cropButtonEl.hidden = true;
                            this.rotateButtonEl.hidden = true;
                            this.writeButtonEl.hidden = true;
                        } else {*/
                        this.undoButtonEl.hidden = false;
                        this.redoButtonEl.hidden = false;
                        this.saveButtonEl.hidden = true;
                        this.cancelButtonEl.hidden = true;
                        if (prevState === ImageEditorState.CROP
                            || prevState === ImageEditorState.TEXT
                            || prevState === ImageEditorState.INIT)
                            this.activateGestureHandling();
                        this.editMenuButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = false;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = false;
                        this.writingFontSizeEl.hidden = true;
                        this.cropButtonEl.hidden = false;
                        this.rotateButtonEl.hidden = false;
                        this.writeButtonEl.hidden = false;
                        break;
                    case ImageEditorState.ZOOM:
                        this.undoButtonEl.hidden = false;
                        this.redoButtonEl.hidden = false;
                        this.saveButtonEl.hidden = true;
                        this.cancelButtonEl.hidden = true;
                        this.editMenuButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = false;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = false;
                        this.writingFontSizeEl.hidden = true;
                        this.cropButtonEl.hidden = false;
                        this.rotateButtonEl.hidden = false;
                        this.writeButtonEl.hidden = false;
                        break;
                    case ImageEditorState.TEXT:
                        this.undoButtonEl.hidden = true;
                        this.redoButtonEl.hidden = true;
                        this.saveButtonEl.hidden = false;
                        this.cancelButtonEl.hidden = false;
                        this.editMenuButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = false;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = true;
                        this.writingFontSizeEl.hidden = false;
                        this.cropButtonEl.hidden = true;
                        this.rotateButtonEl.hidden = true;
                        this.writeButtonEl.hidden = true;
                        this.disableGestureHandling();
                        break;
                    case ImageEditorState.INIT:
                    default:
                        this.undoButtonEl.hidden = true;
                        this.redoButtonEl.hidden = true;
                        this.editMenuButtonEl.hidden = true;
                        this.saveButtonEl.hidden = true;
                        this.cancelButtonEl.hidden = true;
                        this.colorPickerButtonEl.hidden = true;
                        // this.opacityPickerButtonEl.hidden = false;
                        this.sizePickerButtonEl.hidden = true;
                        this.writingFontSizeEl.hidden = true;
                        this.cropButtonEl.hidden = true;
                        this.rotateButtonEl.hidden = true;
                        this.writeButtonEl.hidden = true;
                        this.disableGestureHandling();
                }
                this.updatePickersPositions();
            };
            return ImageEditor;
        }());
        ImageEditor_1.ImageEditor = ImageEditor;
        var ImageEditorState;
        (function (ImageEditorState) {
            ImageEditorState[ImageEditorState["INIT"] = 0] = "INIT";
            ImageEditorState[ImageEditorState["DRAW"] = 1] = "DRAW";
            ImageEditorState[ImageEditorState["DRAWING"] = 2] = "DRAWING";
            ImageEditorState[ImageEditorState["ZOOM"] = 3] = "ZOOM";
            ImageEditorState[ImageEditorState["CROP"] = 4] = "CROP";
            ImageEditorState[ImageEditorState["TEXT"] = 5] = "TEXT";
        })(ImageEditorState = ImageEditor_1.ImageEditorState || (ImageEditor_1.ImageEditorState = {}));
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=ImageEditor.js.map