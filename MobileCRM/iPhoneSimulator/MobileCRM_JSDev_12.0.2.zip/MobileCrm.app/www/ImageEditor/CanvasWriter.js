var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Resco;
(function (Resco) {
    var ImageEditor;
    (function (ImageEditor) {
        var CanvasWriter = /** @class */ (function (_super) {
            __extends(CanvasWriter, _super);
            function CanvasWriter(canvas, drawingImage, backgroundImage, canvasProperties, writingFontSizeEl, fontColor, txt, shouldToggleInput, x, y, w, h) {
                if (fontColor === void 0) { fontColor = '#f45656'; }
                if (txt === void 0) { txt = ''; }
                if (shouldToggleInput === void 0) { shouldToggleInput = true; }
                var _this = _super.call(this, canvas, drawingImage, backgroundImage, canvasProperties, x, y, canvasProperties.ViewImageWidth - 20, CanvasWriter.fontSize * 1.5) || this;
                _this.writingFontSizeEl = writingFontSizeEl;
                _this.fontColor = fontColor;
                _this.inputText = '';
                if (writingFontSizeEl === null || writingFontSizeEl === undefined || !(writingFontSizeEl instanceof HTMLInputElement))
                    throw "Writing font size input element is missing!";
                _this.writeCanvas = document.createElement('canvas');
                if (_this.canvasProperties.DimensionsFlipped) {
                    _this.writeCanvas.width = _this.ctx.canvas.height * _this.canvasProperties.ImageRatio;
                    _this.writeCanvas.height = _this.ctx.canvas.width * _this.canvasProperties.ImageRatio;
                }
                else {
                    _this.writeCanvas.width = _this.ctx.canvas.width * _this.canvasProperties.ImageRatio;
                    _this.writeCanvas.height = _this.ctx.canvas.height * _this.canvasProperties.ImageRatio;
                }
                _this.writeCtx = _this.writeCanvas.getContext('2d');
                _this.inputText = txt;
                _this.inputWrapperEl = document.createElement('div');
                _this.inputWrapperEl.style.position = 'fixed';
                _this.inputWrapperEl.style.display = 'none';
                _this.inputWrapperEl.style.flexWrap = 'wrap';
                _this.inputWrapperEl.style.top = '0px';
                _this.inputWrapperEl.style.left = '0px';
                _this.inputWrapperEl.style.right = '0px';
                _this.inputWrapperEl.style.bottom = '0px';
                _this.inputWrapperEl.style.padding = "0 25px";
                _this.inputWrapperEl.style.background = "rgba(0,0,0,0.5)";
                _this.inputWrapperEl.style.alignItems = 'center';
                _this.inputWrapperEl.style.justifyContent = 'center';
                _this.inputWrapperEl.style.zIndex = "999";
                _this.inputEl = document.createElement('input');
                _this.inputEl.type = "text";
                _this.inputEl.style.maxWidth = "100%";
                _this.inputEl.style.border = "none";
                _this.inputEl.style.background = "rgba(255,255,255,0.75)";
                _this.inputEl.style.fontSize = "30px";
                _this.inputEl.style.color = "#000";
                _this.inputEl.onkeyup = function (e) {
                    if (e.keyCode === 13) {
                        _this.drawScene();
                    }
                    else {
                        _this.inputText = _this.inputEl.value;
                    }
                };
                _this.inputEl.addEventListener("blur", function () {
                    if (_this.inputWrapperEl.style.display === 'flex')
                        setTimeout(function () { return _this.inputEl.focus(); }, 10);
                });
                _this.inputWrapperEl.appendChild(_this.inputEl);
                _this.inputSubmitEl = document.createElement('button');
                _this.inputSubmitEl.innerText = '✔';
                _this.inputSubmitEl.style.color = '#000';
                _this.inputSubmitEl.style.background = "rgba(255,255,255,0.75)";
                _this.inputSubmitEl.style.border = 'none';
                _this.inputSubmitEl.style.fontSize = '30px';
                _this.inputSubmitEl.onclick = function () {
                    _this.drawScene();
                };
                _this.inputWrapperEl.appendChild(_this.inputSubmitEl);
                document.getElementsByTagName('body')[0].appendChild(_this.inputWrapperEl);
                _this.writingFontSizeEl.value = CanvasWriter.fontSize + '';
                _this.writingFontSizeEl.oninput = function () {
                    _this.FontSize = parseInt(_this.writingFontSizeEl.value);
                };
                _this.drawScene();
                if (shouldToggleInput)
                    _this.toggleUserInput();
                return _this;
            }
            // define helper functions
            // define Selection draw method
            CanvasWriter.prototype.drawText = function () {
                if (typeof this.writeCtx === 'undefined')
                    return;
                if (this.inputWrapperEl.style.display === 'flex')
                    this.toggleUserInput();
                var scaledFontSize = CanvasWriter.fontSize * this.canvasProperties.ImageRatio;
                this.writeCtx.clearRect(0, 0, this.writeCtx.canvas.width, this.writeCtx.canvas.height);
                this.writeCtx.font = scaledFontSize + "px Arial";
                this.writeCtx.fillStyle = this.fontColor;
                this.writeCtx.save();
                this.writeCtx.setTransform(1, 0, 0, 1, 0, 0);
                this.writeCtx.translate(this.writeCtx.canvas.width / 2, this.writeCtx.canvas.height / 2);
                this.writeCtx.rotate((360 - this.canvasProperties.Rotation) * Math.PI / 180);
                if (this.canvasProperties.DimensionsFlipped)
                    this.writeCtx.translate(-this.writeCtx.canvas.height / 2, -this.writeCtx.canvas.width / 2);
                else
                    this.writeCtx.translate(-this.writeCtx.canvas.width / 2, -this.writeCtx.canvas.height / 2);
                var top, left, width, height;
                if (this.canvasProperties.DimensionsFlipped) {
                    width = this.h;
                    height = this.w;
                }
                else {
                    width = this.w;
                    height = this.h;
                }
                if (this.canvasProperties.Rotation === 90) {
                    top = this.x;
                    left = this.canvas.clientWidth - this.y - this.h;
                }
                else if (this.canvasProperties.Rotation === 180) {
                    top = this.canvas.clientHeight - this.y - this.h;
                    left = this.canvas.clientWidth - this.x - this.w;
                }
                else if (this.canvasProperties.Rotation === 270) {
                    top = this.canvas.clientHeight - this.x - this.w;
                    left = this.y;
                }
                else {
                    top = this.y;
                    left = this.x;
                }
                var parts = [];
                var currText = "";
                var cnt = 1;
                for (var _i = 0, _a = this.InputText; _i < _a.length; _i++) {
                    var l = _a[_i];
                    if (this.writeCtx.measureText(currText + l).width > width * this.canvasProperties.ImageRatio) {
                        if (cnt * scaledFontSize < height * this.canvasProperties.ImageRatio)
                            this.writeCtx.fillText(currText, left * this.canvasProperties.ImageRatio, top * this.canvasProperties.ImageRatio + cnt * scaledFontSize);
                        currText = l;
                        cnt++;
                    }
                    else {
                        currText += l;
                    }
                }
                if ((!this.canvasProperties.DimensionsFlipped && currText && cnt * scaledFontSize < this.h * this.canvasProperties.ImageRatio)
                    || (this.canvasProperties.DimensionsFlipped && currText && cnt * scaledFontSize < this.w * this.canvasProperties.ImageRatio)) {
                    this.writeCtx.fillText(currText, left * this.canvasProperties.ImageRatio, top * this.canvasProperties.ImageRatio + cnt * scaledFontSize);
                }
                this.writeCtx.restore();
                this.ctx.save();
                this.ctx.scale(1 / this.canvasProperties.ImageRatio, 1 / this.canvasProperties.ImageRatio);
                this.ctx.drawImage(this.writeCanvas, 0, 0);
                this.ctx.restore();
            };
            CanvasWriter.prototype.afterSelectionDrawn = function () {
                this.drawText();
            };
            Object.defineProperty(CanvasWriter.prototype, "InputText", {
                get: function () {
                    return this.inputText;
                },
                set: function (value) {
                    this.inputText = value;
                    this.drawScene();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(CanvasWriter.prototype, "FontSize", {
                set: function (value) {
                    CanvasWriter.fontSize = value;
                    this.drawScene();
                },
                enumerable: true,
                configurable: true
            });
            CanvasWriter.prototype.ChangeColor = function (rgbaColor) {
                this.fontColor = rgbaColor;
                this.drawScene();
            };
            CanvasWriter.prototype.OnMouseDown = function (e) {
                this.prevX = e.clientX;
                this.prevY = e.clientY;
            };
            CanvasWriter.prototype.OnMouseUp = function (e) {
                if (Math.abs(this.prevX - e.clientX) < 5
                    && Math.abs(this.prevY - e.clientY) < 5) {
                    this.toggleUserInput();
                }
            };
            CanvasWriter.prototype.AfterDispose = function () {
                document.getElementsByTagName('body')[0].removeChild(this.inputWrapperEl);
                return {
                    text: this.InputText, input: this.inputWrapperEl.style.display === 'flex'
                };
            };
            CanvasWriter.prototype.toggleUserInput = function () {
                var _this = this;
                if (this.inputWrapperEl.style.display === 'flex') {
                    this.inputWrapperEl.style.display = 'none';
                    this.activateGestureHandling();
                }
                else {
                    this.disableGestureHandling();
                    this.inputWrapperEl.style.display = 'flex';
                    this.inputEl.value = this.inputText;
                    setTimeout(function () { return _this.inputEl.focus(); }, 10);
                }
            };
            CanvasWriter.prototype.GetImageCanvasWithText = function () {
                if (this.InputText && this.InputText.length > 0) {
                    var temp_canvas = document.createElement('canvas');
                    var temp_ctx = temp_canvas.getContext('2d');
                    temp_ctx.canvas.width = this.backgroundImage.width;
                    temp_ctx.canvas.height = this.backgroundImage.height;
                    temp_ctx.drawImage(this.backgroundImage, 0, 0);
                    temp_ctx.drawImage(this.drawingImage, 0, 0);
                    temp_ctx.drawImage(this.writeCanvas, 0, 0);
                    this.dispose();
                    return temp_canvas;
                }
                else {
                    this.dispose();
                    return this.backgroundImage;
                }
            };
            // variables
            CanvasWriter.fontSize = 72;
            return CanvasWriter;
        }(ImageEditor.CanvasSelector));
        ImageEditor.CanvasWriter = CanvasWriter;
    })(ImageEditor = Resco.ImageEditor || (Resco.ImageEditor = {}));
})(Resco || (Resco = {}));
//# sourceMappingURL=CanvasWriter.js.map