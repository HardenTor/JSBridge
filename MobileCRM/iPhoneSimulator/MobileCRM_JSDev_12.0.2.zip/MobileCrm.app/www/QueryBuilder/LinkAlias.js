var FetchQueryBuilder;
(function (FetchQueryBuilder) {
    var LinkAlias = (function () {
        /**
         * Initialized the LinkAlias
         * @param fetch object representing the fetch
         */
        function LinkAlias(fetch) {
            if (!fetch)
                throw "The passed in fetch is not valid!";
            var links = fetch.entity.linkentities;
            this._usedAliases = [];
            this._ensureAliases(links);
        }
        /**
         * Assigns the alias for the link if it is missing or new link was created
         * @param links
         */
        LinkAlias.prototype._ensureAliases = function (links) {
            for (var l in links) {
                if (!links[l]["alias"] || this._usedAliases.indexOf(links[l]["alias"]) != -1) {
                    links[l]["alias"] = this.generateNew();
                }
                else {
                    this._usedAliases.push(links[l]["alias"]);
                }
                if (links[l].linkentities)
                    this._ensureAliases(links[l].linkentities);
            }
        };
        /**
         * Creates new alias
         */
        LinkAlias.prototype.generateNew = function () {
            var cnt = 0;
            var alias = "CL" + cnt;
            while (this._usedAliases.indexOf(alias) != -1 && cnt < 1000) {
                cnt++;
                alias = "CL" + cnt;
            }
            if (cnt == 1000)
                throw "Too many linked entities!";
            this._usedAliases.push(alias);
            return alias;
        };
        return LinkAlias;
    }());
    FetchQueryBuilder.LinkAlias = LinkAlias;
})(FetchQueryBuilder || (FetchQueryBuilder = {}));
//# sourceMappingURL=LinkAlias.js.map